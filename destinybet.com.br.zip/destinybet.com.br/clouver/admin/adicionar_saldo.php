<?php
include('conexao.php');

$id = $_POST['id'];
$balance = $_POST['balance'];

$sql = "UPDATE users SET balance = balance + $balance WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: user.php");
} else {
    echo "Erro ao adicionar saldo: " . $conn->error;
}

$conn->close();
?>
