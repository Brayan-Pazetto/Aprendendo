<?php
include('conexao.php');

$id = $_POST['id'];

$sql = "DELETE FROM users WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: user.php");
} 

$conn->close();
?>
