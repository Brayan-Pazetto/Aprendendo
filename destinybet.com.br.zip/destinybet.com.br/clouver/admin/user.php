<?php
include('conexao.php');

$sql = "SELECT * FROM users";
$result = $conn->query($sql);


// Calcular o total de usuários
$sqlTotalUsuarios = "SELECT COUNT(*) AS total_usuarios FROM users";
$resultTotalUsuarios = $conn->query($sqlTotalUsuarios);
$rowTotalUsuarios = $resultTotalUsuarios->fetch_assoc();
$totalUsuarios = $rowTotalUsuarios['total_usuarios'];

// Calcular o total do saldo de todos os usuários
$sqlTotalBalance = "SELECT SUM(balance) AS total_balance FROM users";
$resultTotalBalance = $conn->query($sqlTotalBalance);
$rowTotalBalance = $resultTotalBalance->fetch_assoc();
$totalBalance = $rowTotalBalance['total_balance'];




?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clouver BRL Dashboard | Dashboard</title>
  <!-- Favicon -->
  <link rel="shortcut icon" href="./img/svg/logo.svg" type="image/x-icon">
  <!-- Custom styles -->
  <link rel="stylesheet" href="./css/style.css">
</head>

<body>
  <div class="layer"></div>
<!-- ! Body -->
<a class="skip-link sr-only" href="#skip-target">Skip to content</a>
<div class="page-flex">
  <!-- ! Sidebar -->
  <aside class="sidebar">
    <div class="sidebar-start">
        <div class="sidebar-head">
            <a href="/" class="logo-wrapper" title="Home">
                <span class="sr-only">Home</span>
                <div class="logo-text">
                    <span class="logo-title">Clouver BRL</span>
                    <span class="logo-subtitle">Dashboard</span>
                </div>

            </a>
            <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                <span class="sr-only">Toggle menu</span>
                <span class="icon menu-toggle" aria-hidden="true"></span>
            </button>
        </div>
        <div class="sidebar-body">
            <ul class="sidebar-body-menu">
                <li>
                    <a  href="index.php"><span class="icon home" aria-hidden="true"></span>Dashboard</a>
                </li>
              
                <li>
                    <a class="show-cat-btn" href="##">
                        <span class="icon folder" aria-hidden="true"></span>Jogos Da Casa
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Open list</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a href="categories.html">Double</a>
                        </li>
                        <li>
                          <a href="categories.html">Crash</a>
                      </li>
                      <li>
                        <a href="categories.html">Mines</a>
                    </li>
                    </ul>
                </li>
               
                
            </ul>
            <span class="system-menu__title">system</span>
            <ul class="sidebar-body-menu">
            
                <li>
                    <a class="active" href="/"><span class="icon user-3" aria-hidden="true"></span>Usuarios</a>
                </li>
                <li>
                    <a href="##"><span class="icon setting" aria-hidden="true"></span>Configurações</a>
                </li>
            </ul>
        </div>
    </div>
    
</aside>
  <div class="main-wrapper">
    <!-- ! Main nav -->
    <nav class="main-nav--bg">
  <div class="container main-nav">
    <div class="main-nav-start">
    </div>
    <div class="main-nav-end">
      <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
        <span class="sr-only">Toggle menu</span>
        <span class="icon menu-toggle--gray" aria-hidden="true"></span>
      </button>
      
      <button class="theme-switcher gray-circle-btn" type="button" title="Switch theme">
        <span class="sr-only">Switch theme</span>
        <i class="sun-icon" data-feather="sun" aria-hidden="true"></i>
        <i class="moon-icon" data-feather="moon" aria-hidden="true"></i>
      </button>
     
      
    </div>
  </div>
</nav>
    <!-- ! Main -->
    <main class="main users chart-page" id="skip-target">
        <div class="container">
          <h2 class="main-title">Usuarios</h2>
          <div class="row stat-cards">
            <div class="col-md-6 col-xl-3">
              <article class="stat-cards-item">
                <div class="stat-cards-icon primary">
                  <i data-feather="bar-chart-2" aria-hidden="true"></i>
                </div>
                <div class="stat-cards-info">
                  <p class="stat-cards-info__num"><?php echo $totalUsuarios; ?></p>
                  <p class="stat-cards-info__title">Usuarios Cadastrados</p>
                </div>
              </article>
            </div>
            <div class="col-md-6 col-xl-3">
              <article class="stat-cards-item">
                <div class="stat-cards-icon warning">
                  <i data-feather="file" aria-hidden="true"></i>
                </div>
                <div class="stat-cards-info">
                  <p class="stat-cards-info__num"><?php echo $totalUsuarios; ?></p>
                  <p class="stat-cards-info__title">Total De Contas</p>
                </div>
              </article>
            </div>
            <div class="col-md-6 col-xl-3">
              <article class="stat-cards-item">
                <div class="stat-cards-icon purple">
                  <i data-feather="file" aria-hidden="true"></i>
                </div>
                <div class="stat-cards-info">
                  <p class="stat-cards-info__num">R$ <?php echo $totalBalance; ?>,00</p>
                  <p class="stat-cards-info__title">Total Depositado</p>
                  <p class="stat-cards-info__progress">
                    <span class="stat-cards-info__profit danger">
                      <i data-feather="trending-down" aria-hidden="true"></i>1.64%
                    </span>
                    Este Ano
                  </p>
                </div>
              </article>
            </div>
            <div class="col-md-6 col-xl-3">
              <article class="stat-cards-item">
                <div class="stat-cards-icon success">
                  <i data-feather="feather" aria-hidden="true"></i>
                </div>
                <div class="stat-cards-info">
                  <p class="stat-cards-info__num">R$ 0,00</p>
                  <p class="stat-cards-info__title">Total retirado</p>
                  <p class="stat-cards-info__progress">
                    <span class="stat-cards-info__profit warning">
                      <i data-feather="trending-up" aria-hidden="true"></i>0.00%
                    </span>
                    Este Ano
                  </p>
                </div>
              </article>
            </div>
          </div>
          <article class="stat-cards-item2">
            <table class="tabela-user">
                <tr>
                    <th class="id-user">ID</th>
                    <th class="email-user">Email</th>
                    <th class="saldo-user">Saldo</th>
                    <th class="acao-user">Ação</th>
                </tr>
            </table>
            <div class="user-tabela">
              <table class="tabela-user2">
                <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr class='tebela-2'>
                        <td class=''>{$row['id']}</td>
                        <td class=''>{$row['email']}</td>
                        <td class='saldo-user'>{$row['balance']}</td>
                        <td class='acoes'>
                            <form action='adicionar_saldo.php' method='post'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                
                                <input class='input-balance' type='number' name='balance' placeholder='Adicionar Saldo'>
                                <button type='submit' class='adicionar-saldo-btn'>
                                <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 12 12' fill='none'>
                                    <path d='M6 0C7.5913 0 9.11742 0.632141 10.2426 1.75736C11.3679 2.88258 12 4.4087 12 6C12 7.5913 11.3679 9.11742 10.2426 10.2426C9.11742 11.3679 7.5913 12 6 12C4.4087 12 2.88258 11.3679 1.75736 10.2426C0.632141 9.11742 0 7.5913 0 6C0 4.4087 0.632141 2.88258 1.75736 1.75736C2.88258 0.632141 4.4087 0 6 0ZM5.25257 7.18371L3.91971 5.85C3.87193 5.80222 3.81521 5.76431 3.75278 5.73845C3.69034 5.7126 3.62343 5.69929 3.55586 5.69929C3.48828 5.69929 3.42137 5.7126 3.35894 5.73845C3.29651 5.76431 3.23978 5.80222 3.192 5.85C3.0955 5.9465 3.04129 6.07738 3.04129 6.21386C3.04129 6.35033 3.0955 6.48121 3.192 6.57771L4.88914 8.27486C4.93679 8.32288 4.99347 8.36099 5.05592 8.387C5.11837 8.41302 5.18535 8.42641 5.253 8.42641C5.32065 8.42641 5.38763 8.41302 5.45008 8.387C5.51253 8.36099 5.56921 8.32288 5.61686 8.27486L9.13114 4.75971C9.17956 4.71213 9.21808 4.65543 9.24448 4.59288C9.27088 4.53034 9.28463 4.46318 9.28495 4.3953C9.28527 4.32741 9.27214 4.26013 9.24632 4.19734C9.22051 4.13455 9.18252 4.0775 9.13454 4.02946C9.08656 3.98143 9.02955 3.94337 8.96679 3.91748C8.90404 3.89159 8.83677 3.87839 8.76888 3.87862C8.701 3.87886 8.63383 3.89253 8.57125 3.91886C8.50867 3.94518 8.45193 3.98364 8.40429 4.032L5.25257 7.18371Z' fill='white'/>
                                </svg>
                            </button>
                            </form>
                            <form action='excluir_conta.php' method='post'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <button type='submit' class='excluir-btn'>
                                <svg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none'>
                                    <path d='M19 4H15.5L14.5 3H9.5L8.5 4H5V6H19M6 19C6 19.5304 6.21071 20.0391 6.58579 20.4142C6.96086 20.7893 7.46957 21 8 21H16C16.5304 21 17.0391 20.7893 17.4142 20.4142C17.7893 20.0391 18 19.5304 18 19V7H6V19Z' fill='white'/>
                                </svg>
                            </button>
                            </form>
                        </td>
                      </tr>";
            }
        } 
        ?>
            </table>
            </div>
            
          </article>
        </div>
      </main>
    <!-- ! Footer -->
    <footer class="footer">
  <div class="container footer--flex">
    <div class="footer-start">
      <p>2023 © Clouver BRL Dashboard - <a href="Clouver BRL-dashboard.com" target="_blank"
          rel="noopener noreferrer">Clouver BRL-dashboard.com</a></p>
    </div>
    <ul class="footer-end">
      <li><a href="##">About</a></li>
      <li><a href="##">Support</a></li>
      <li><a href="##">Puchase</a></li>
    </ul>
  </div>
</footer>
  </div>
</div>
<!-- Chart library -->
<script src="./plugins/chart.min.js"></script>
<!-- Icons library -->
<script src="plugins/feather.min.js"></script>
<!-- Custom scripts -->
<script src="js/script.js"></script>
</body>

</html>