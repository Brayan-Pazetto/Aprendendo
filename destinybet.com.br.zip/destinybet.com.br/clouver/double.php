<?php

include('conexao.php');
include('php/login/fuctions.php');

require __DIR__ . '/vendor/autoload.php';
include('infos_pag.php');
?>


<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>ClouverBET | Online</title>
    
	<link rel="stylesheet" href="css/newmenu.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <meta property="og:type" content="website" />
    <meta property="og:url" content="/" />
    <meta name="description" content="Jogue com seus amigos e ganhe dinheiro!">
	<meta name="keywords" content="cassino, site de apostas, crash, foguetinho, double">
	<link rel="icon" type="image/ico" href="favicon.ico" />


    <meta name="csrf-token" content="63rWLQI6W2YMswWrBZLCww00RRFrqaq8AjeJtALm" />
    <meta name="language" content="en" />
    <meta name="logged" content="0" />
    <meta name="email" content="" />
    <meta name="id" content="" />
    <meta name="username" content=""/>
    <meta name="avatar" content=""/>
    <meta name="token" content=""/>
    <meta name="time" content="1696977633"/>
	
	<link rel="icon" type="image/ico" href="favicon.ico" />
	<link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/custon.css">
    <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <script src="../ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="../cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script src="../cdn.jsdelivr.net/npm/bootstrap%405.1.3/dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

		<style>
		
	    <div class="footer">


		
	</style>
</head>

<body>

<div class="navbar2">
    <style>
 
  


.modal-dash-content {
  position: absolute;
  width: 375px;
  box-sizing: border-box;
  padding: 0;
  animation: all 0 .25s;
  border-radius: 0 0 2px 2px;
  background-color: #e4e4e4;
  z-index: 70;
}

.modal-dash-top {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  padding: 20px 15px;
  background: #f8f9fa;
}

.modal-dash-top > div {
  display: flex;
  color: #404040;
}

.modal-dash-top > div:first-of-type {
  display: flex;
  justify-content: space-between;
  padding-bottom: 20px;
}

.modal-dash-top > div:first-of-type span p {
  font-size: 12px;
}

.modal-dash-top > div:first-of-type span strong {
  font-size: 20px;
}

.modal-dash-top > div:first-of-type a {
  display: flex;
  align-items: center;
  vertical-align: middle;
  padding: 0 12px;
  border: 1px solid #c3c3c3;
  color: #404040;
  border-radius: 2px;
  height: 44px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 700;
  line-height: 14px;
  min-width: 120px;
  align-items: center;
  justify-content: center;
  background-color: #fafbfc;
}

.modal-dash-top > div:first-of-type a:hover {
  background: #FFF;
}

.modal-dash-top > div:first-of-type a:before {
  position: relative;
  top: 2px;
  content: "";
  width: 12px;
  height: 13px;
  margin-right: 10px;
  background-repeat: no-repeat;
  background-position: 50%;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 13'%3E%3Cpath fill='%23404040' d='M4.586 7.802L6 9.212l1.414-1.41-.003-.003 3.271-3.278-1.414-1.41L7 5.383V0H5l.002 5.385-2.27-2.274-1.414 1.41L4.588 7.8l-.002.003zM12 13v-1.995H0V13h12z'/%3E%3C/svg%3E");
}

.modal-dash-top > div:last-of-type > span:first-of-type {
  margin-right: 48px;
}


.modal-dash-top > div:last-of-type span p {
  font-size: 11px;
}

.modal-dash-top > div:last-of-type span strong {
  font-size: 15px;
}




.modal-dash-options {
  border-top: 1px solid #d4d4d4;
}

.um-GeneralTab_AccountContainer {
  display: flex;
  flex-wrap: wrap;
  background-color: #f3f5f4;
  box-sizing: border-box;
  padding: 20px 0 10px 5px;
  justify-content: space-around;
  width: 100%;
}

.ul-MembersLinkButton {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 11px;
  font-weight: 700;
  color: #505050;
  line-height: 17px;
  margin-right: 5px;
  padding-bottom: 20px;
  min-width: 100px;
  cursor: pointer;
  text-align: center;
  flex: 1 0 31%;
  max-width: 31%;
}

.ul-MembersLinkButton:hover {
  opacity: 0.8;
}

.ul-MembersLinkButton_Icon {
  height: 39px;
  margin-bottom: 8px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton {
  cursor: pointer;
}

.um-MessagesButton:hover {
  opacity: 0.8;
}

.um-MessagesButton_Icon {
  position: relative;
  height: 39px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton_MessagesCount {
  font-size: 10px;
  border-radius: 999px;
  color: #3b3b3b;
  background-color: #58d7af;
  line-height: 17px;
  height: 17px;
  width: 17px;
  top: 6px;
  right: 0;
  text-align: center;
  position: absolute;
  font-weight: 700;
}

.um-MessagesButton_Text {
  font-size: 11px;
  color: #505050;
  font-weight: 700;
  line-height: 17px;
  padding-top: 8px;
}

.modal-dash-footer {
  display: flex;
  flex-direction: column;
}

.modal-dash-footer > a {
  background-color: #f8f9fa;
  display: flex;
  align-items: center;
  width: 100%;
  height: 50px;
  font-size: 15px;
  color: #404040;
  box-sizing: border-box;
  padding: 0 15px;
  border-top: 1px solid #d4d4d4;
  transition: none;
}

.modal-dash-footer > a:hover {
  background:#fff;
  opacity: 1;
}

@media  screen and (max-width: 768px) {


.modal-dash-content {
  position: relative;
     left: -260px;
	 top: -15px;
  width: 375px;
  box-sizing: border-box;
 
  animation: all 0 .25s;
  border-radius: 0 0 2px 2px;
  background-color: #e4e4e4;
  z-index: 99;
}

.modal-dash-top {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  padding: 20px 15px;
  background: #f8f9fa;
}

.modal-dash-top > div {
  display: flex;
  color: #404040;
}

.modal-dash-top > div:first-of-type {
  display: flex;
  justify-content: space-between;
  padding-bottom: 20px;
}

.modal-dash-top > div:first-of-type span p {
  font-size: 12px;
}

.modal-dash-top > div:first-of-type span strong {
  font-size: 20px;
}

.modal-dash-top > div:first-of-type a {
  display: flex;
  align-items: center;
  vertical-align: middle;
  padding: 0 12px;
  border: 1px solid #c3c3c3;
  color: #404040;
  border-radius: 2px;
  height: 44px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 700;
  line-height: 14px;
  min-width: 120px;
  align-items: center;
  justify-content: center;
  background-color: #fafbfc;
}

.modal-dash-top > div:first-of-type a:hover {
  background: #FFF;
}

.modal-dash-top > div:first-of-type a:before {
  position: relative;
  top: 2px;
  content: "";
  width: 12px;
  height: 13px;
  margin-right: 10px;
  background-repeat: no-repeat;
  background-position: 50%;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 13'%3E%3Cpath fill='%23404040' d='M4.586 7.802L6 9.212l1.414-1.41-.003-.003 3.271-3.278-1.414-1.41L7 5.383V0H5l.002 5.385-2.27-2.274-1.414 1.41L4.588 7.8l-.002.003zM12 13v-1.995H0V13h12z'/%3E%3C/svg%3E");
}

.modal-dash-top > div:last-of-type > span:first-of-type {
  margin-right: 48px;
}


.modal-dash-top > div:last-of-type span p {
  font-size: 11px;
}

.modal-dash-top > div:last-of-type span strong {
  font-size: 15px;
}




.modal-dash-options {
  border-top: 1px solid #d4d4d4;
}

.um-GeneralTab_AccountContainer {
  display: flex;
  flex-wrap: wrap;
  background-color: #f3f5f4;
  box-sizing: border-box;
  padding: 20px 0 10px 5px;
  justify-content: space-around;
  width: 100%;
}

.ul-MembersLinkButton {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 11px;
  font-weight: 700;
  color: #505050;
  line-height: 17px;
  margin-right: 5px;
  padding-bottom: 20px;
  min-width: 100px;
  cursor: pointer;
  text-align: center;
  flex: 1 0 31%;
  max-width: 31%;
}

.ul-MembersLinkButton:hover {
  opacity: 0.8;
}

.ul-MembersLinkButton_Icon {
  height: 39px;
  margin-bottom: 8px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton {
  cursor: pointer;
}

.um-MessagesButton:hover {
  opacity: 0.8;
}

.um-MessagesButton_Icon {
  position: relative;
  height: 39px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton_MessagesCount {
  font-size: 10px;
  border-radius: 999px;
  color: #3b3b3b;
  background-color: #58d7af;
  line-height: 17px;
  height: 17px;
  width: 17px;
  top: 6px;
  right: 0;
  text-align: center;
  position: absolute;
  font-weight: 700;
}

.um-MessagesButton_Text {
  font-size: 11px;
  color: #505050;
  font-weight: 700;
  line-height: 17px;
  padding-top: 8px;
}

.modal-dash-footer {
  display: flex;
  flex-direction: column;
}

.modal-dash-footer > a {
  background-color: #f8f9fa;
  display: flex;
  align-items: center;
  width: 100%;
  height: 50px;
  font-size: 15px;
  color: #404040;
  box-sizing: border-box;
  padding: 0 15px;
  border-top: 1px solid #d4d4d4;
  transition: none;
}

.modal-dash-footer > a:hover {
  background:#fff;
  opacity: 1;
}
}




    </style>
    
    <?php
    include('header_pag.php');
    ?>

    <div class="mobile-menu">        

        <div class="icon-menu click-open-menu">
            <i class="fa-solid fa-bars"></i>
            <span>Menu</span>
        </div>
        <div class="icon-roulette">
            <a href="casino/providers/evoplay.html">
               <i class="fa-solid fa-gamepad"></i>
                <span>Cassino</span>
            </a>
        </div>
       

        <div class="icon-help">
            <a href="casino/providers/evolution.html">
               <i class="fa-solid fa-circle-play"></i>
                <span>Ao Vivo</span>
            </a>
        </div>
		
		 <div class="icon-chat">
            <i class="fa-solid fa-message"></i>
            <span>Chat</span>
        </div>

    </div>
	<nav class="right mobile-show">
        			<div  class="btnDespositar register-modal " >Ganhe R$ 100,00 gratis 💥</div>
				 
            <div class="games">
				
                <details class="collapse show" open>
                    <summary class="title">
					<i  style="font-size: 16px; margin-left: 5px; margin-right:7px; color: #8c9099;"></i>
					<a style="color:white;">EXCLUSIVOS</a>
					</summary>
                    <div class="btnGames">
                        <a href="crash.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-rocket"  style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Crash</div>
                            </div>
                        </a>
                        <a href="dice.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fas fa-dice" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Dice</div>
                            </div>
                        </a>
                        <a href="double.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-dharmachakra" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Double</div>
                            </div>
                        </a>
                        <a href="x-double.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-circle-notch" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">X-Double</div>
                            </div>
                        </a>
                        <a href="tower.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-chess-rook" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Tower</div>
                            </div>
                        </a>
                        <div class="line" style="margin-bottom: 20px;"></div>
                    </div>
                </details>

                <details class="collapse show" open style="border-bottom: 1px solid #040615;">
                    <summary class="title"><i  style="font-size: 16px; margin-left: 5px; margin-right:7px; color:white;"></i>
					<a style="color:white;">CASSINO</a>
					</summary>
                    <div class="btnGames">
                        <a href="casino/providers/evoplay.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path d="M19.9999 0.499977C19.9708 0.361296 19.8957 0.236509 19.7868 0.145782C19.6779 0.0550541 19.5416 0.00368564 19.3999 -2.31452e-05C13.6099 -0.320023 9.12995 1.56998 6.50995 5.30998C6.1892 5.17425 5.85354 5.07691 5.50995 5.01998C4.8823 4.92689 4.24241 4.95944 3.62744 5.11572C3.01247 5.27201 2.43468 5.54892 1.92763 5.93037C1.42058 6.31182 0.994362 6.79022 0.673742 7.33777C0.353122 7.88532 0.144485 8.49112 0.0599479 9.11998C-0.0427691 9.74656 -0.0206725 10.3873 0.124968 11.0053C0.270609 11.6233 0.536924 12.2065 0.908614 12.7213C1.2803 13.2361 1.75004 13.6723 2.29085 14.005C2.83165 14.3377 3.43287 14.5603 4.05995 14.66C4.75316 14.764 5.46096 14.7093 6.12995 14.5C6.10857 14.0454 6.13202 13.5899 6.19995 13.14C6.34078 12.1773 6.69144 11.2573 7.22713 10.4451C7.76282 9.63296 8.47045 8.94843 9.29995 8.43998C9.00199 7.47688 8.41987 6.62635 7.62995 5.99998C9.75995 3.06998 13.1899 1.42998 17.6299 1.32998C15.1621 3.45539 13.334 6.22526 12.3499 9.32998C11.1663 9.42377 10.057 9.94413 9.22827 10.7943C8.39949 11.6445 7.9076 12.7667 7.84404 13.9524C7.78048 15.138 8.14957 16.3063 8.88271 17.2403C9.61585 18.1742 10.6631 18.8102 11.8299 19.03C13.107 19.266 14.4254 18.9851 15.4953 18.249C16.5652 17.5129 17.2989 16.382 17.5349 15.105C17.771 13.828 17.4901 12.5095 16.754 11.4396C16.0179 10.3697 14.887 9.63602 13.6099 9.39998C14.7492 6.09481 16.8923 3.228 19.7399 1.19998C19.8523 1.12626 19.9381 1.01858 19.9848 0.892649C20.0316 0.766717 20.0369 0.629131 19.9999 0.499977ZM3.17995 7.49998C2.48995 8.01998 1.71995 8.14998 1.45995 7.79998C1.19995 7.44998 1.55995 6.79998 2.25995 6.23998C2.95995 5.67998 3.71995 5.58998 3.96995 5.93998C4.21995 6.28998 3.83995 6.99998 3.14995 7.47998L3.17995 7.49998ZM11.1099 11.89C10.4199 12.4 9.64995 12.53 9.39995 12.18C9.14995 11.83 9.49995 11.13 10.1899 10.62C10.8799 10.11 11.6499 9.97998 11.9099 10.33C12.1699 10.68 11.7799 11.35 11.0799 11.87L11.1099 11.89Z" fill="#8C9099"></path><path d="M15.1299 10.3699C15.693 11.1313 15.9978 12.0529 15.9999 12.9999C16.0013 13.5912 15.8858 14.1769 15.6601 14.7235C15.4344 15.2701 15.103 15.7667 14.6849 16.1848C14.2667 16.6029 13.7701 16.9343 13.2236 17.16C12.677 17.3857 12.0913 17.5012 11.4999 17.4999C10.5529 17.4978 9.63138 17.1929 8.86993 16.6299C9.24794 17.1627 9.73768 17.6067 10.305 17.9307C10.8723 18.2548 11.5034 18.4511 12.1545 18.5061C12.8055 18.561 13.4606 18.4732 14.0742 18.2489C14.6878 18.0245 15.245 17.6689 15.707 17.2069C16.1689 16.7449 16.5245 16.1877 16.7489 15.5741C16.9733 14.9606 17.0611 14.3054 17.0061 13.6544C16.9512 13.0034 16.7549 12.3722 16.4308 11.8049C16.1067 11.2376 15.6628 10.7479 15.1299 10.3699Z" fill="#414952"></path><path d="M17.5899 1.28998C15.1221 3.41539 13.294 6.18526 12.3099 9.28998C12.7484 9.27272 13.1869 9.32332 13.6099 9.43998C14.7492 6.13481 16.8923 3.268 19.7399 1.23998C19.8606 1.16419 19.9519 1.04977 19.9992 0.915373C20.0464 0.78098 20.0467 0.63455 19.9999 0.499977C19.9708 0.361296 19.8957 0.236509 19.7868 0.145782C19.6779 0.0550541 19.5416 0.00368564 19.3999 -2.31452e-05C13.6099 -0.320023 9.12995 1.56998 6.50995 5.30998C6.92419 5.46579 7.30448 5.70007 7.62995 5.99998C9.75995 2.99998 13.1899 1.38998 17.5899 1.28998Z" fill="#414952"></path></g><defs><clipPath id="clip0"><rect width="20" height="19" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Jogos slots</div>
                            </div>
                        </a>
                        <a href="casino/providers/evolution.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path d="M18.75 5H1.25C0.918479 5 0.600537 5.1317 0.366117 5.36612C0.131696 5.60054 0 5.91848 0 6.25L0 18.75C0 19.0815 0.131696 19.3995 0.366117 19.6339C0.600537 19.8683 0.918479 20 1.25 20H18.75C19.0815 20 19.3995 19.8683 19.6339 19.6339C19.8683 19.3995 20 19.0815 20 18.75V6.25C20 5.91848 19.8683 5.60054 19.6339 5.36612C19.3995 5.1317 19.0815 5 18.75 5ZM15 18.12C15 18.2854 14.935 18.4441 14.819 18.562C14.703 18.6798 14.5453 18.7474 14.38 18.75H1.88C1.71291 18.75 1.55267 18.6836 1.43452 18.5655C1.31637 18.4473 1.25 18.2871 1.25 18.12V6.88C1.25 6.71291 1.31637 6.55267 1.43452 6.43452C1.55267 6.31637 1.71291 6.25 1.88 6.25H14.38C14.5453 6.25262 14.703 6.32016 14.819 6.43802C14.935 6.55589 15 6.71463 15 6.88V18.12ZM17.5 15C17.2528 15 17.0111 14.9267 16.8055 14.7893C16.6 14.652 16.4398 14.4568 16.3451 14.2284C16.2505 13.9999 16.2258 13.7486 16.274 13.5061C16.3223 13.2637 16.4413 13.0409 16.6161 12.8661C16.7909 12.6913 17.0137 12.5722 17.2561 12.524C17.4986 12.4758 17.7499 12.5005 17.9784 12.5952C18.2068 12.6898 18.402 12.85 18.5393 13.0555C18.6767 13.2611 18.75 13.5028 18.75 13.75C18.75 14.0815 18.6183 14.3995 18.3839 14.6339C18.1495 14.8683 17.8315 15 17.5 15ZM17.5 10C17.2528 10 17.0111 9.92669 16.8055 9.78934C16.6 9.65199 16.4398 9.45676 16.3451 9.22835C16.2505 8.99995 16.2258 8.74861 16.274 8.50614C16.3223 8.26366 16.4413 8.04093 16.6161 7.86612C16.7909 7.6913 17.0137 7.57225 17.2561 7.52402C17.4986 7.47579 17.7499 7.50054 17.9784 7.59515C18.2068 7.68976 18.402 7.84998 18.5393 8.05554C18.6767 8.2611 18.75 8.50277 18.75 8.75C18.75 9.08152 18.6183 9.39946 18.3839 9.63388C18.1495 9.8683 17.8315 10 17.5 10Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7.64995 14.8C7.28311 14.9624 6.87832 15.0194 6.48091 14.9646C6.08351 14.9099 5.70921 14.7455 5.39995 14.49C3.87995 13 7.09995 9.39 8.12995 8.75C9.12995 9.39 12.3699 12.97 10.8499 14.49C10.5407 14.7455 10.1664 14.9099 9.76898 14.9646C9.37158 15.0194 8.96678 14.9624 8.59995 14.8L9.33995 16.25H6.90995L7.64995 14.8Z" fill="#414952"></path><path d="M10.62 6.25003C10.4561 6.24677 10.2992 6.1826 10.18 6.07003L5.18003 1.07003C5.06455 0.95067 5 0.7911 5 0.625027C5 0.458955 5.06455 0.299385 5.18003 0.180027C5.29938 0.0645548 5.45895 0 5.62503 0C5.7911 0 5.95067 0.0645548 6.07003 0.180027L11.07 5.18003C11.1855 5.29938 11.2501 5.45895 11.2501 5.62503C11.2501 5.7911 11.1855 5.95067 11.07 6.07003C10.9483 6.18492 10.7874 6.24927 10.62 6.25003Z" fill="#8C9099"></path><path d="M10.62 6.25001C10.4561 6.24675 10.2992 6.18258 10.18 6.07001C10.0646 5.95065 10 5.79108 10 5.62501C10 5.45894 10.0646 5.29937 10.18 5.18001L13.93 1.43001C14.0498 1.32086 14.207 1.26204 14.369 1.26579C14.531 1.26954 14.6853 1.33557 14.7999 1.45015C14.9145 1.56473 14.9805 1.71905 14.9842 1.88104C14.988 2.04304 14.9292 2.20025 14.82 2.32001L11.07 6.07001C10.9483 6.18491 10.7874 6.24925 10.62 6.25001Z" fill="#8C9099"></path></g><defs><clipPath id="clip0"><rect width="20" height="20" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Cassino ao vivo</div>
                            </div>
                        </a>
                        <a href="casino/providers.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path d="M17.5 10.93H2.5L5 8.5H15L17.5 10.93Z" fill="#414952"></path><path d="M19.91 14C19.7632 13.4745 19.4478 13.0117 19.0124 12.6829C18.577 12.3541 18.0456 12.1774 17.5 12.18H2.49997C1.95434 12.1774 1.42297 12.3541 0.987552 12.6829C0.552134 13.0117 0.236776 13.4745 0.0899658 14H19.91Z" fill="#8C9099"></path><path d="M20 15.1799H0V16.9999H20V15.1799Z" fill="#414952"></path><path d="M13.75 -6.53708e-05H6.25C5.44103 -0.011971 4.63765 0.135599 3.88572 0.434218C3.13379 0.732836 2.44806 1.17665 1.86767 1.74032C1.28729 2.30399 0.823627 2.97647 0.503169 3.71935C0.182711 4.46223 0.011733 5.26097 0 6.06993H20C19.9883 5.26097 19.8173 4.46223 19.4968 3.71935C19.1764 2.97647 18.7127 2.30399 18.1323 1.74032C17.5519 1.17665 16.8662 0.732836 16.1143 0.434218C15.3624 0.135599 14.559 -0.011971 13.75 -6.53708e-05ZM4 3.65993C3.31 4.33993 2.45 4.59994 2.1 4.25993C1.75 3.91993 2 3.07993 2.69 2.40993C3.38 1.73993 4.23 1.46993 4.59 1.81993C4.95 2.16993 4.67 2.99993 4 3.65993Z" fill="#8C9099"></path></g><defs><clipPath id="clip0"><rect width="20" height="17" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Provedores</div>
                            </div>
                        </a>
                      <a href="index.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 0H8C7.72386 0 7.5 0.223858 7.5 0.5V4.5C7.5 4.77614 7.72386 5 8 5H12C12.2761 5 12.5 4.77614 12.5 4.5V0.5C12.5 0.223858 12.2761 0 12 0Z" fill="#8C9099"></path><path d="M4.5 0H0.5C0.223858 0 0 0.223858 0 0.5V4.5C0 4.77614 0.223858 5 0.5 5H4.5C4.77614 5 5 4.77614 5 4.5V0.5C5 0.223858 4.77614 0 4.5 0Z" fill="#8C9099"></path><path d="M19.5 7.5H15.5C15.2239 7.5 15 7.72386 15 8V12C15 12.2761 15.2239 12.5 15.5 12.5H19.5C19.7761 12.5 20 12.2761 20 12V8C20 7.72386 19.7761 7.5 19.5 7.5Z" fill="#8C9099"></path><path d="M19.5 15H15.5C15.2239 15 15 15.2239 15 15.5V19.5C15 19.7761 15.2239 20 15.5 20H19.5C19.7761 20 20 19.7761 20 19.5V15.5C20 15.2239 19.7761 15 19.5 15Z" fill="#8C9099"></path><path d="M19.5 0H15.5C15.3674 0 15.2402 0.0526784 15.1464 0.146447C15.0527 0.240215 15 0.367392 15 0.5V4.5C15 4.63261 15.0527 4.75979 15.1464 4.85355C15.2402 4.94732 15.3674 5 15.5 5H19.5C19.6326 5 19.7598 4.94732 19.8536 4.85355C19.9473 4.75979 20 4.63261 20 4.5V0.5C20 0.367392 19.9473 0.240215 19.8536 0.146447C19.7598 0.0526784 19.6326 0 19.5 0V0ZM17.5 3.75C17.2528 3.75 17.0111 3.67669 16.8055 3.53934C16.6 3.40199 16.4398 3.20676 16.3451 2.97835C16.2505 2.74995 16.2258 2.49861 16.274 2.25614C16.3223 2.01366 16.4413 1.79093 16.6161 1.61612C16.7909 1.4413 17.0137 1.32225 17.2561 1.27402C17.4986 1.22579 17.7499 1.25054 17.9784 1.34515C18.2068 1.43976 18.402 1.59998 18.5393 1.80554C18.6767 2.0111 18.75 2.25277 18.75 2.5C18.75 2.83152 18.6183 3.14946 18.3839 3.38388C18.1495 3.6183 17.8315 3.75 17.5 3.75Z" fill="#414952"></path><path d="M12 7.5H8C7.86739 7.5 7.74021 7.55268 7.64645 7.64645C7.55268 7.74021 7.5 7.86739 7.5 8V12C7.5 12.1326 7.55268 12.2598 7.64645 12.3536C7.74021 12.4473 7.86739 12.5 8 12.5H12C12.1326 12.5 12.2598 12.4473 12.3536 12.3536C12.4473 12.2598 12.5 12.1326 12.5 12V8C12.5 7.86739 12.4473 7.74021 12.3536 7.64645C12.2598 7.55268 12.1326 7.5 12 7.5ZM10 11.25C9.75277 11.25 9.5111 11.1767 9.30554 11.0393C9.09998 10.902 8.93976 10.7068 8.84515 10.4784C8.75054 10.2499 8.72579 9.99861 8.77402 9.75614C8.82225 9.51366 8.9413 9.29093 9.11612 9.11612C9.29093 8.9413 9.51366 8.82225 9.75614 8.77402C9.99861 8.72579 10.2499 8.75054 10.4784 8.84515C10.7068 8.93976 10.902 9.09998 11.0393 9.30554C11.1767 9.5111 11.25 9.75277 11.25 10C11.25 10.3315 11.1183 10.6495 10.8839 10.8839C10.6495 11.1183 10.3315 11.25 10 11.25Z" fill="#414952"></path><path d="M10 18.75C10.6904 18.75 11.25 18.1904 11.25 17.5C11.25 16.8096 10.6904 16.25 10 16.25C9.30964 16.25 8.75 16.8096 8.75 17.5C8.75 18.1904 9.30964 18.75 10 18.75Z" fill="#8C9099"></path><path d="M2.5 11.25C3.19036 11.25 3.75 10.6904 3.75 10C3.75 9.30964 3.19036 8.75 2.5 8.75C1.80964 8.75 1.25 9.30964 1.25 10C1.25 10.6904 1.80964 11.25 2.5 11.25Z" fill="#8C9099"></path><path d="M4.5 15H0.5C0.367392 15 0.240215 15.0527 0.146447 15.1464C0.0526784 15.2402 0 15.3674 0 15.5L0 19.5C0 19.6326 0.0526784 19.7598 0.146447 19.8536C0.240215 19.9473 0.367392 20 0.5 20H4.5C4.63261 20 4.75979 19.9473 4.85355 19.8536C4.94732 19.7598 5 19.6326 5 19.5V15.5C5 15.3674 4.94732 15.2402 4.85355 15.1464C4.75979 15.0527 4.63261 15 4.5 15ZM2.5 18.75C2.25277 18.75 2.0111 18.6767 1.80554 18.5393C1.59998 18.402 1.43976 18.2068 1.34515 17.9784C1.25054 17.7499 1.22579 17.4986 1.27402 17.2561C1.32225 17.0137 1.4413 16.7909 1.61612 16.6161C1.79093 16.4413 2.01366 16.3223 2.25614 16.274C2.49861 16.2258 2.74995 16.2505 2.97835 16.3451C3.20676 16.4398 3.40199 16.6 3.53934 16.8055C3.67669 17.0111 3.75 17.2528 3.75 17.5C3.75 17.8315 3.6183 18.1495 3.38388 18.3839C3.14946 18.6183 2.83152 18.75 2.5 18.75Z" fill="#414952"></path></svg>
                                </div>
                                <div class="btnGameName">Mines</div>
                            </div>
                        </a>
                         <a href="index.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path fill-rule="evenodd" clip-rule="evenodd" d="M19.29 13.8499H16.72C16.2274 15.4328 15.3355 16.862 14.13 17.9999H19.29C19.3819 18.0012 19.4732 17.9844 19.5587 17.9505C19.6441 17.9165 19.722 17.8661 19.7879 17.802C19.8539 17.7379 19.9065 17.6615 19.9429 17.5771C19.9793 17.4926 19.9987 17.4019 20 17.3099V14.5399C19.9987 14.448 19.9793 14.3572 19.9429 14.2728C19.9065 14.1884 19.8539 14.1119 19.7879 14.0479C19.722 13.9838 19.6441 13.9333 19.5587 13.8994C19.4732 13.8654 19.3819 13.8486 19.29 13.8499Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7.14 4.15005C6.2149 4.1315 5.29529 4.29655 4.43437 4.63564C3.57346 4.97473 2.78831 5.48114 2.12434 6.12558C1.46037 6.77002 0.930748 7.53971 0.566115 8.39012C0.201481 9.24054 0.00906694 10.1548 0 11.0801C0.0103792 12.0045 0.20376 12.9176 0.568979 13.7669C0.934198 14.6162 1.46402 15.3847 2.12786 16.028C2.7917 16.6714 3.5764 17.1769 4.43667 17.5154C5.29694 17.8539 6.21573 18.0186 7.14 18.0001C8.0651 18.0199 8.98497 17.8562 9.8464 17.5183C10.7078 17.1805 11.4937 16.6752 12.1586 16.0317C12.8235 15.3881 13.3542 14.6192 13.7201 13.7693C14.0859 12.9193 14.2796 12.0053 14.29 11.0801C14.281 10.1539 14.0882 9.23884 13.723 8.38776C13.3577 7.53668 12.8272 6.76654 12.1621 6.12196C11.4971 5.47739 10.7108 4.97119 9.84869 4.6327C8.98662 4.29421 8.06594 4.13016 7.14 4.15005ZM7.14 15.5001C6.53984 15.5093 5.94373 15.4003 5.38573 15.1791C4.82772 14.958 4.31874 14.6291 3.88786 14.2112C3.45699 13.7933 3.11265 13.2946 2.87452 12.7437C2.63638 12.1927 2.50912 11.6002 2.5 11.0001C2.50912 10.3999 2.63638 9.8074 2.87452 9.25643C3.11265 8.70546 3.45699 8.20679 3.88786 7.78892C4.31874 7.37104 4.82772 7.04214 5.38573 6.82099C5.94373 6.59984 6.53984 6.49079 7.14 6.50005C7.74099 6.48946 8.33817 6.59753 8.89734 6.81808C9.4565 7.03863 9.96666 7.36732 10.3986 7.78533C10.8305 8.20334 11.1758 8.70245 11.4145 9.25409C11.6533 9.80572 11.7809 10.399 11.79 11.0001C11.7809 11.6011 11.6533 12.1944 11.4145 12.746C11.1758 13.2977 10.8305 13.7968 10.3986 14.2148C9.96666 14.6328 9.4565 14.9615 8.89734 15.182C8.33817 15.4026 7.74099 15.5106 7.14 15.5001Z" fill="#414952"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M19.29 7.24469e-05H3.56999C3.47806 -0.00125019 3.38677 0.015549 3.30134 0.0495107C3.2159 0.0834723 3.13799 0.133931 3.07206 0.198005C3.00613 0.26208 2.95347 0.338514 2.91708 0.422944C2.88069 0.507374 2.86129 0.598144 2.85999 0.690072V2.33007C4.70496 1.47094 6.76527 1.18513 8.77444 1.50959C10.7836 1.83405 12.6492 2.75387 14.13 4.15007H19.29C19.3819 4.1514 19.4732 4.1346 19.5586 4.10063C19.6441 4.06667 19.722 4.01621 19.7879 3.95214C19.8538 3.88807 19.9065 3.81163 19.9429 3.7272C19.9793 3.64277 19.9987 3.552 20 3.46007V0.690072C19.9987 0.598144 19.9793 0.507374 19.9429 0.422944C19.9065 0.338514 19.8538 0.26208 19.7879 0.198005C19.722 0.133931 19.6441 0.0834723 19.5586 0.0495107C19.4732 0.015549 19.3819 -0.00125019 19.29 7.24469e-05Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M19.29 6.91999H16.16C16.8131 8.20971 17.1556 9.63432 17.16 11.08H19.31C19.4027 11.0813 19.4948 11.0642 19.5809 11.0296C19.667 10.995 19.7454 10.9437 19.8114 10.8785C19.8775 10.8134 19.9299 10.7358 19.9657 10.6502C20.0015 10.5646 20.02 10.4728 20.02 10.38V7.61999C20.02 7.52722 20.0015 7.43537 19.9657 7.34978C19.9299 7.2642 19.8775 7.18658 19.8114 7.12145C19.7454 7.05632 19.667 7.00496 19.5809 6.97038C19.4948 6.9358 19.4027 6.91867 19.31 6.91999" fill="#8C9099"></path><path d="M7.61002 7.5V8.35C8.07547 8.38455 8.52691 8.52477 8.93002 8.76L8.39002 9.76C8.13205 9.55018 7.81238 9.43074 7.48002 9.42C7.3099 9.40748 7.14058 9.45334 7.00002 9.55C6.94854 9.57733 6.90494 9.61743 6.87342 9.66647C6.84189 9.7155 6.82351 9.77181 6.82002 9.83C6.82365 9.88077 6.83801 9.9302 6.86214 9.97502C6.88627 10.0198 6.91963 10.059 6.96002 10.09C7.06194 10.1872 7.18525 10.2591 7.32002 10.3L7.75002 10.44C8.12485 10.5508 8.46773 10.7497 8.75002 11.02C8.96681 11.2726 9.08099 11.5973 9.07002 11.93C9.07151 12.1295 9.04458 12.3281 8.99002 12.52C8.95816 12.6907 8.89364 12.8537 8.80002 13C8.66033 13.1449 8.49826 13.2665 8.32002 13.36C8.09158 13.473 7.85408 13.5666 7.61002 13.64V14.51H6.94002V13.67C6.77862 13.6722 6.61751 13.6554 6.46002 13.62C6.28976 13.5873 6.12251 13.5405 5.96002 13.48L5.50002 13.28C5.37124 13.2029 5.2535 13.1087 5.15002 13L5.74002 12C6.09377 12.3505 6.56297 12.5602 7.06002 12.59C7.2273 12.5924 7.39131 12.5435 7.53002 12.45C7.59098 12.4093 7.64106 12.3543 7.67591 12.2898C7.71077 12.2253 7.72934 12.1533 7.73002 12.08C7.73002 11.87 7.57002 11.72 7.26002 11.62L6.85002 11.5C6.63064 11.4331 6.41669 11.3495 6.21002 11.25C6.0533 11.1715 5.91123 11.0666 5.79002 10.94C5.67924 10.8259 5.59402 10.6896 5.54002 10.54C5.48099 10.3663 5.45389 10.1834 5.46002 10C5.4598 9.80317 5.49016 9.6075 5.55002 9.42C5.60707 9.23546 5.70249 9.06506 5.83002 8.92C5.95574 8.7658 6.11246 8.63975 6.29002 8.55C6.49065 8.44102 6.71228 8.37623 6.94002 8.36V7.5H7.61002Z" fill="#8C9099"></path></g><defs><clipPath id="clip0"><rect width="20" height="18" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Fortune Tiger</div>
                            </div>
                        </a>
                        <a href="index.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path fill-rule="evenodd" clip-rule="evenodd" d="M10 15.69L0 11.97V14.45L10 18.17L20 14.45V11.97L10 15.69Z" fill="#414952"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M10.82 6.28003V9.93003H9.18005V6.28003L0.180046 9.69003C0.129444 9.708 0.0856492 9.74121 0.0546784 9.78508C0.0237076 9.82895 0.00708008 9.88133 0.00708008 9.93503C0.00708008 9.98873 0.0237076 10.0411 0.0546784 10.085C0.0856492 10.1288 0.129444 10.1621 0.180046 10.18L9.83005 13.77C9.94665 13.8104 10.0734 13.8104 10.19 13.77L19.84 10.18C19.8906 10.1621 19.9344 10.1288 19.9654 10.085C19.9964 10.0411 20.013 9.98873 20.013 9.93503C20.013 9.88133 19.9964 9.82895 19.9654 9.78508C19.9344 9.74121 19.8906 9.708 19.84 9.69003L10.82 6.28003Z" fill="#8C9099"></path><path d="M10 4.58C11.2648 4.58 12.29 3.55473 12.29 2.29C12.29 1.02527 11.2648 0 10 0C8.73529 0 7.71002 1.02527 7.71002 2.29C7.71002 3.55473 8.73529 4.58 10 4.58Z" fill="#414952"></path></g><defs><clipPath id="clip0"><rect width="20" height="18.17" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Fortune Panda</div>
                            </div>
                        </a>
                        <a href="index.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10 1C8.21997 1 6.47991 1.52784 4.99987 2.51677C3.51983 3.50571 2.36628 4.91131 1.68509 6.55585C1.0039 8.20038 0.82567 10.01 1.17294 11.7558C1.5202 13.5016 2.37737 15.1053 3.63604 16.364C4.89472 17.6226 6.49836 18.4798 8.24419 18.8271C9.99002 19.1743 11.7996 18.9961 13.4442 18.3149C15.0887 17.6337 16.4943 16.4802 17.4832 15.0001C18.4722 13.5201 19 11.78 19 10C19 7.61305 18.0518 5.32387 16.364 3.63604C14.6761 1.94821 12.387 1 10 1ZM10 16C8.81332 16 7.65328 15.6481 6.66658 14.9888C5.67989 14.3295 4.91085 13.3925 4.45673 12.2961C4.0026 11.1997 3.88378 9.99334 4.11529 8.82946C4.3468 7.66557 4.91825 6.59647 5.75736 5.75736C6.59648 4.91824 7.66558 4.3468 8.82946 4.11529C9.99335 3.88378 11.1997 4.0026 12.2961 4.45672C13.3925 4.91085 14.3295 5.67988 14.9888 6.66658C15.6481 7.65327 16 8.81331 16 10C16 11.5913 15.3679 13.1174 14.2426 14.2426C13.1174 15.3679 11.5913 16 10 16Z" fill="#414952"></path><path d="M10 0C8.02219 0 6.08879 0.58649 4.4443 1.6853C2.79981 2.78412 1.51809 4.3459 0.761209 6.17317C0.00433284 8.00043 -0.193701 10.0111 0.192152 11.9509C0.578004 13.8907 1.53041 15.6725 2.92894 17.0711C4.32746 18.4696 6.10929 19.422 8.0491 19.8079C9.98891 20.1937 11.9996 19.9957 13.8268 19.2388C15.6541 18.4819 17.2159 17.2002 18.3147 15.5557C19.4135 13.9112 20 11.9778 20 10C20 7.34784 18.9464 4.8043 17.0711 2.92893C15.1957 1.05357 12.6522 0 10 0V0ZM10 18.75C8.26942 18.75 6.57769 18.2368 5.13876 17.2754C3.69983 16.3139 2.57833 14.9473 1.91606 13.3485C1.25379 11.7496 1.08051 9.99029 1.41813 8.29296C1.75575 6.59563 2.58911 5.03653 3.81282 3.81282C5.03653 2.58911 6.59563 1.75575 8.29296 1.41813C9.9903 1.08051 11.7496 1.25379 13.3485 1.91605C14.9473 2.57832 16.3139 3.69983 17.2754 5.13876C18.2368 6.57769 18.75 8.26941 18.75 10C18.75 12.3206 17.8281 14.5462 16.1872 16.1872C14.5462 17.8281 12.3206 18.75 10 18.75Z" fill="#8C9099"></path><path d="M13.3416 8.28051L6.41248 11.1506L6.65357 11.7327L13.5827 8.86255L13.3416 8.28051Z" fill="#8C9099"></path><path d="M8.84698 6.41874L8.27417 6.65601L11.1443 13.5851L11.7171 13.3478L8.84698 6.41874Z" fill="#8C9099"></path><path d="M8.57 7.18993C8.91794 7.18993 9.2 6.90787 9.2 6.55993C9.2 6.21199 8.91794 5.92993 8.57 5.92993C8.22206 5.92993 7.94 6.21199 7.94 6.55993C7.94 6.90787 8.22206 7.18993 8.57 7.18993Z" fill="#8C9099"></path><path d="M11.43 14.0601C11.7724 14.0601 12.05 13.7825 12.05 13.4401C12.05 13.0977 11.7724 12.8201 11.43 12.8201C11.0876 12.8201 10.81 13.0977 10.81 13.4401C10.81 13.7825 11.0876 14.0601 11.43 14.0601Z" fill="#8C9099"></path><path d="M13.44 9.19994C13.7879 9.19994 14.07 8.91788 14.07 8.56994C14.07 8.222 13.7879 7.93994 13.44 7.93994C13.0921 7.93994 12.81 8.222 12.81 8.56994C12.81 8.91788 13.0921 9.19994 13.44 9.19994Z" fill="#8C9099"></path><path d="M6.56005 12.06C6.90799 12.06 7.19005 11.778 7.19005 11.43C7.19005 11.0821 6.90799 10.8 6.56005 10.8C6.21211 10.8 5.93005 11.0821 5.93005 11.43C5.93005 11.778 6.21211 12.06 6.56005 12.06Z" fill="#8C9099"></path><path d="M10 11.25C10.6904 11.25 11.25 10.6904 11.25 10C11.25 9.30964 10.6904 8.75 10 8.75C9.30964 8.75 8.75 9.30964 8.75 10C8.75 10.6904 9.30964 11.25 10 11.25Z" fill="#414952"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M10 3.75C8.76387 3.75 7.5555 4.11656 6.52769 4.80331C5.49988 5.49007 4.6988 6.46619 4.22576 7.60823C3.75271 8.75027 3.62894 10.0069 3.87009 11.2193C4.11125 12.4317 4.70651 13.5453 5.58059 14.4194C6.45466 15.2935 7.56831 15.8888 8.78069 16.1299C9.99307 16.3711 11.2497 16.2473 12.3918 15.7742C13.5338 15.3012 14.5099 14.5001 15.1967 13.4723C15.8834 12.4445 16.25 11.2361 16.25 10C16.25 8.3424 15.5915 6.75269 14.4194 5.58058C13.2473 4.40848 11.6576 3.75 10 3.75ZM10 15C9.0111 15 8.0444 14.7068 7.22215 14.1573C6.39991 13.6079 5.75904 12.827 5.38061 11.9134C5.00217 10.9998 4.90315 9.99445 5.09608 9.02455C5.289 8.05464 5.76521 7.16373 6.46447 6.46447C7.16373 5.7652 8.05465 5.289 9.02455 5.09607C9.99446 4.90315 10.9998 5.00216 11.9134 5.3806C12.8271 5.75904 13.6079 6.3999 14.1574 7.22215C14.7068 8.04439 15 9.01109 15 10C15 11.3261 14.4732 12.5979 13.5355 13.5355C12.5979 14.4732 11.3261 15 10 15Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14.89 8.99995L18.71 8.19995C18.4767 7.13305 18.0533 6.11684 17.46 5.19995L14.18 7.26995C14.5271 7.79486 14.7683 8.38254 14.89 8.99995Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14.89 11C14.7646 11.607 14.5235 12.1841 14.18 12.7L17.46 14.83C18.163 13.9749 18.5979 12.9313 18.71 11.83L14.89 11Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M11 14.8899L11.8 18.7099C12.8801 18.5201 13.9047 18.0932 14.8 17.4599L12.67 14.1799C12.1632 14.52 11.5965 14.7609 11 14.8899Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7.27001 14.1799L5.14001 17.4599C5.96286 18.2149 7.02452 18.6573 8.14002 18.7099L9.00001 14.8899C8.3826 14.7682 7.79492 14.527 7.27001 14.1799Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.11004 11L1.29004 11.8C1.38683 12.9051 1.8235 13.9531 2.54004 14.8L5.82004 12.67C5.47999 12.1632 5.23907 11.5965 5.11004 11Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.82004 7.26989L2.54004 5.13989C1.85532 6.00585 1.42278 7.04394 1.29004 8.13989L5.11004 8.99989C5.23175 8.38248 5.47293 7.7948 5.82004 7.26989Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M8.99995 5.11004L8.19995 1.29004L5.19995 2.54004L7.26995 5.82004C7.79486 5.47293 8.38254 5.23175 8.99995 5.11004Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12.73 5.82004L14.86 2.54004L11.86 1.29004L11 5.11004C11.6174 5.23175 12.2051 5.47293 12.73 5.82004Z" fill="#8C9099"></path></svg></div>
                                <div class="btnGameName">Crazy Time</div>
                            </div>
                        </a> 
						<a href="index.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M10 1C8.21997 1 6.47991 1.52784 4.99987 2.51677C3.51983 3.50571 2.36628 4.91131 1.68509 6.55585C1.0039 8.20038 0.82567 10.01 1.17294 11.7558C1.5202 13.5016 2.37737 15.1053 3.63604 16.364C4.89472 17.6226 6.49836 18.4798 8.24419 18.8271C9.99002 19.1743 11.7996 18.9961 13.4442 18.3149C15.0887 17.6337 16.4943 16.4802 17.4832 15.0001C18.4722 13.5201 19 11.78 19 10C19 7.61305 18.0518 5.32387 16.364 3.63604C14.6761 1.94821 12.387 1 10 1ZM10 16C8.81332 16 7.65328 15.6481 6.66658 14.9888C5.67989 14.3295 4.91085 13.3925 4.45673 12.2961C4.0026 11.1997 3.88378 9.99334 4.11529 8.82946C4.3468 7.66557 4.91825 6.59647 5.75736 5.75736C6.59648 4.91824 7.66558 4.3468 8.82946 4.11529C9.99335 3.88378 11.1997 4.0026 12.2961 4.45672C13.3925 4.91085 14.3295 5.67988 14.9888 6.66658C15.6481 7.65327 16 8.81331 16 10C16 11.5913 15.3679 13.1174 14.2426 14.2426C13.1174 15.3679 11.5913 16 10 16Z" fill="#414952"></path><path d="M10 0C8.02219 0 6.08879 0.58649 4.4443 1.6853C2.79981 2.78412 1.51809 4.3459 0.761209 6.17317C0.00433284 8.00043 -0.193701 10.0111 0.192152 11.9509C0.578004 13.8907 1.53041 15.6725 2.92894 17.0711C4.32746 18.4696 6.10929 19.422 8.0491 19.8079C9.98891 20.1937 11.9996 19.9957 13.8268 19.2388C15.6541 18.4819 17.2159 17.2002 18.3147 15.5557C19.4135 13.9112 20 11.9778 20 10C20 7.34784 18.9464 4.8043 17.0711 2.92893C15.1957 1.05357 12.6522 0 10 0V0ZM10 18.75C8.26942 18.75 6.57769 18.2368 5.13876 17.2754C3.69983 16.3139 2.57833 14.9473 1.91606 13.3485C1.25379 11.7496 1.08051 9.99029 1.41813 8.29296C1.75575 6.59563 2.58911 5.03653 3.81282 3.81282C5.03653 2.58911 6.59563 1.75575 8.29296 1.41813C9.9903 1.08051 11.7496 1.25379 13.3485 1.91605C14.9473 2.57832 16.3139 3.69983 17.2754 5.13876C18.2368 6.57769 18.75 8.26941 18.75 10C18.75 12.3206 17.8281 14.5462 16.1872 16.1872C14.5462 17.8281 12.3206 18.75 10 18.75Z" fill="#8C9099"></path><path d="M13.3416 8.28051L6.41248 11.1506L6.65357 11.7327L13.5827 8.86255L13.3416 8.28051Z" fill="#8C9099"></path><path d="M8.84698 6.41874L8.27417 6.65601L11.1443 13.5851L11.7171 13.3478L8.84698 6.41874Z" fill="#8C9099"></path><path d="M8.57 7.18993C8.91794 7.18993 9.2 6.90787 9.2 6.55993C9.2 6.21199 8.91794 5.92993 8.57 5.92993C8.22206 5.92993 7.94 6.21199 7.94 6.55993C7.94 6.90787 8.22206 7.18993 8.57 7.18993Z" fill="#8C9099"></path><path d="M11.43 14.0601C11.7724 14.0601 12.05 13.7825 12.05 13.4401C12.05 13.0977 11.7724 12.8201 11.43 12.8201C11.0876 12.8201 10.81 13.0977 10.81 13.4401C10.81 13.7825 11.0876 14.0601 11.43 14.0601Z" fill="#8C9099"></path><path d="M13.44 9.19994C13.7879 9.19994 14.07 8.91788 14.07 8.56994C14.07 8.222 13.7879 7.93994 13.44 7.93994C13.0921 7.93994 12.81 8.222 12.81 8.56994C12.81 8.91788 13.0921 9.19994 13.44 9.19994Z" fill="#8C9099"></path><path d="M6.56005 12.06C6.90799 12.06 7.19005 11.778 7.19005 11.43C7.19005 11.0821 6.90799 10.8 6.56005 10.8C6.21211 10.8 5.93005 11.0821 5.93005 11.43C5.93005 11.778 6.21211 12.06 6.56005 12.06Z" fill="#8C9099"></path><path d="M10 11.25C10.6904 11.25 11.25 10.6904 11.25 10C11.25 9.30964 10.6904 8.75 10 8.75C9.30964 8.75 8.75 9.30964 8.75 10C8.75 10.6904 9.30964 11.25 10 11.25Z" fill="#414952"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M10 3.75C8.76387 3.75 7.5555 4.11656 6.52769 4.80331C5.49988 5.49007 4.6988 6.46619 4.22576 7.60823C3.75271 8.75027 3.62894 10.0069 3.87009 11.2193C4.11125 12.4317 4.70651 13.5453 5.58059 14.4194C6.45466 15.2935 7.56831 15.8888 8.78069 16.1299C9.99307 16.3711 11.2497 16.2473 12.3918 15.7742C13.5338 15.3012 14.5099 14.5001 15.1967 13.4723C15.8834 12.4445 16.25 11.2361 16.25 10C16.25 8.3424 15.5915 6.75269 14.4194 5.58058C13.2473 4.40848 11.6576 3.75 10 3.75ZM10 15C9.0111 15 8.0444 14.7068 7.22215 14.1573C6.39991 13.6079 5.75904 12.827 5.38061 11.9134C5.00217 10.9998 4.90315 9.99445 5.09608 9.02455C5.289 8.05464 5.76521 7.16373 6.46447 6.46447C7.16373 5.7652 8.05465 5.289 9.02455 5.09607C9.99446 4.90315 10.9998 5.00216 11.9134 5.3806C12.8271 5.75904 13.6079 6.3999 14.1574 7.22215C14.7068 8.04439 15 9.01109 15 10C15 11.3261 14.4732 12.5979 13.5355 13.5355C12.5979 14.4732 11.3261 15 10 15Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14.89 8.99995L18.71 8.19995C18.4767 7.13305 18.0533 6.11684 17.46 5.19995L14.18 7.26995C14.5271 7.79486 14.7683 8.38254 14.89 8.99995Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M14.89 11C14.7646 11.607 14.5235 12.1841 14.18 12.7L17.46 14.83C18.163 13.9749 18.5979 12.9313 18.71 11.83L14.89 11Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M11 14.8899L11.8 18.7099C12.8801 18.5201 13.9047 18.0932 14.8 17.4599L12.67 14.1799C12.1632 14.52 11.5965 14.7609 11 14.8899Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7.27001 14.1799L5.14001 17.4599C5.96286 18.2149 7.02452 18.6573 8.14002 18.7099L9.00001 14.8899C8.3826 14.7682 7.79492 14.527 7.27001 14.1799Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.11004 11L1.29004 11.8C1.38683 12.9051 1.8235 13.9531 2.54004 14.8L5.82004 12.67C5.47999 12.1632 5.23907 11.5965 5.11004 11Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M5.82004 7.26989L2.54004 5.13989C1.85532 6.00585 1.42278 7.04394 1.29004 8.13989L5.11004 8.99989C5.23175 8.38248 5.47293 7.7948 5.82004 7.26989Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M8.99995 5.11004L8.19995 1.29004L5.19995 2.54004L7.26995 5.82004C7.79486 5.47293 8.38254 5.23175 8.99995 5.11004Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12.73 5.82004L14.86 2.54004L11.86 1.29004L11 5.11004C11.6174 5.23175 12.2051 5.47293 12.73 5.82004Z" fill="#8C9099"></path></svg></div>
                                <div class="btnGameName">Roleta ao vivo</div>
                            </div>
                        </a> 
                        <div class="line" style="margin-bottom: 20px;"></div>
                    </div>
                </details>
				
				 <details class="collapse show" open style="border-bottom: 1px solid #040615;">
                    <summary class="title"><i  style="font-size: 16px; margin-left: 5px; margin-right:7px; color:white;"></i>
				
					</summary>
                    <div class="btnGames">
                        <a href="support.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.2 13.6V14.024C15.1937 14.3381 15.0645 14.6372 14.8402 14.857C14.6158 15.0769 14.3141 15.2001 14 15.2H10V16H14C14.5304 16 15.0391 15.7893 15.4142 15.4142C15.7893 15.0391 16 14.5304 16 14V12.8C15.7748 13.1052 15.5052 13.3748 15.2 13.6Z" fill="#414952"></path><path d="M0 10.5839C0.049109 9.80103 0.327312 9.04988 0.8 8.42389V8.30389C0.289133 8.88313 0.00499042 9.62758 0 10.3999C0 10.4639 0 10.5199 0 10.5839Z" fill="#414952"></path><path d="M8 0C5.87827 0 3.84344 0.842855 2.34315 2.34315C0.842855 3.84344 0 5.87827 0 8H0C0.244633 7.6957 0.529976 7.42651 0.848 7.2C1.05156 5.44594 1.89262 3.82784 3.21126 2.65338C4.5299 1.47892 6.23417 0.829998 8 0.829998C9.76583 0.829998 11.4701 1.47892 12.7887 2.65338C14.1074 3.82784 14.9484 5.44594 15.152 7.2C15.47 7.42651 15.7554 7.6957 16 8C16 5.87827 15.1571 3.84344 13.6569 2.34315C12.1566 0.842855 10.1217 0 8 0V0Z" fill="#414952"></path><path d="M3.2 7.20001C2.35131 7.20001 1.53737 7.53715 0.937258 8.13727C0.337142 8.73739 0 9.55132 0 10.4C0 11.2487 0.337142 12.0626 0.937258 12.6628C1.53737 13.2629 2.35131 13.6 3.2 13.6V7.20001Z" fill="#8C9099"></path><path d="M12.8 13.6C13.6487 13.6 14.4626 13.2629 15.0627 12.6628C15.6628 12.0626 16 11.2487 16 10.4C16 9.55132 15.6628 8.73739 15.0627 8.13727C14.4626 7.53715 13.6487 7.20001 12.8 7.20001V13.6Z" fill="#8C9099"></path><path d="M3.20001 7.20001H4.00001C4.21219 7.20001 4.41567 7.2843 4.5657 7.43433C4.71573 7.58436 4.80001 7.78784 4.80001 8.00001V12.8C4.80001 13.0122 4.71573 13.2157 4.5657 13.3657C4.41567 13.5157 4.21219 13.6 4.00001 13.6H3.20001V7.20001Z" fill="#414952"></path><path d="M12 7.20001H12.8V13.6H12C11.7878 13.6 11.5844 13.5157 11.4343 13.3657C11.2843 13.2157 11.2 13.0122 11.2 12.8V8.00001C11.2 7.78784 11.2843 7.58436 11.4343 7.43433C11.5844 7.2843 11.7878 7.20001 12 7.20001Z" fill="#414952"></path><path d="M6.8 14H9.2C9.41217 14 9.61566 14.0843 9.76569 14.2343C9.91571 14.3843 10 14.5878 10 14.8V16H6.8C6.58783 16 6.38434 15.9157 6.23431 15.7657C6.08429 15.6157 6 15.4122 6 15.2V14.8C6 14.5878 6.08429 14.3843 6.23431 14.2343C6.38434 14.0843 6.58783 14 6.8 14Z" fill="#8C9099"></path></svg>
                                </div>
                                <div class="btnGameName">Suporte ao Vivo</div>
                            </div>
                        </a>
												
                        <a href="recompensas.html" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path d="M17.5 10.93H2.5L5 8.5H15L17.5 10.93Z" fill="#414952"></path><path d="M19.91 14C19.7632 13.4745 19.4478 13.0117 19.0124 12.6829C18.577 12.3541 18.0456 12.1774 17.5 12.18H2.49997C1.95434 12.1774 1.42297 12.3541 0.987552 12.6829C0.552134 13.0117 0.236776 13.4745 0.0899658 14H19.91Z" fill="#8C9099"></path><path d="M20 15.1799H0V16.9999H20V15.1799Z" fill="#414952"></path><path d="M13.75 -6.53708e-05H6.25C5.44103 -0.011971 4.63765 0.135599 3.88572 0.434218C3.13379 0.732836 2.44806 1.17665 1.86767 1.74032C1.28729 2.30399 0.823627 2.97647 0.503169 3.71935C0.182711 4.46223 0.011733 5.26097 0 6.06993H20C19.9883 5.26097 19.8173 4.46223 19.4968 3.71935C19.1764 2.97647 18.7127 2.30399 18.1323 1.74032C17.5519 1.17665 16.8662 0.732836 16.1143 0.434218C15.3624 0.135599 14.559 -0.011971 13.75 -6.53708e-05ZM4 3.65993C3.31 4.33993 2.45 4.59994 2.1 4.25993C1.75 3.91993 2 3.07993 2.69 2.40993C3.38 1.73993 4.23 1.46993 4.59 1.81993C4.95 2.16993 4.67 2.99993 4 3.65993Z" fill="#8C9099"></path></g><defs><clipPath id="clip0"><rect width="20" height="17" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Resgatar bônus</div>
                            </div>
                        </a>
                    
                       
                    </div>
                </details>




                <div class="footerMenu">
				
				
					
					
					
					
					
                </div>
            </div>
        </div>
		
    </nav>
	<div class="chat hidden">
        <div class="chat-header">
            <div class="text">
                <span style="font-size:80%; display: flex;flex-direction: row;"><svg width="10px" style="margin-right: 5px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 122.88 122.88" xml:space="preserve"><style type="text/css">.st0{fill-rule:evenodd;clip-rule:evenodd;fill:#1fff20;}</style><g><path class="st0" d="M61.44,0c33.93,0,61.44,27.51,61.44,61.44c0,33.93-27.51,61.44-61.44,61.44C27.51,122.88,0,95.37,0,61.44 C0,27.51,27.51,0,61.44,0L61.44,0z"></path></g></svg> Online: <span class="players-online" style="margin-left: 3px">517</span></span> <svg class="chat-toggle-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" id="Layer_1" style="enable-background:new 0 0 512 512;" version="1.1" viewBox="0 0 512 512" width="20px" xml:space="preserve"><path d="M443.6,387.1L312.4,255.4l131.5-130c5.4-5.4,5.4-14.2,0-19.6l-37.4-37.6c-2.6-2.6-6.1-4-9.8-4c-3.7,0-7.2,1.5-9.8,4  L256,197.8L124.9,68.3c-2.6-2.6-6.1-4-9.8-4c-3.7,0-7.2,1.5-9.8,4L68,105.9c-5.4,5.4-5.4,14.2,0,19.6l131.5,130L68.4,387.1  c-2.6,2.6-4.1,6.1-4.1,9.8c0,3.7,1.4,7.2,4.1,9.8l37.4,37.6c2.7,2.7,6.2,4.1,9.8,4.1c3.5,0,7.1-1.3,9.8-4.1L256,313.1l130.7,131.1  c2.7,2.7,6.2,4.1,9.8,4.1c3.5,0,7.1-1.3,9.8-4.1l37.4-37.6c2.6-2.6,4.1-6.1,4.1-9.8C447.7,393.2,446.2,389.7,443.6,387.1z"></path></svg>
            </div>
        </div>
        <div class="chat-messages">
        </div> 
                <div class="send-area">
            <a href="#" class="need-sign-in login-modal">
                Faça login para conversar
            </a>
        </div>
                <div class="footer">
        <div class="data">
            <div class="social">
            <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
            </div>

            <a href="#" style="color: white !important" target="_blank"><div class="copyright copyright0">&copy; #</div></a>
            
            <div class="legal">
            <a href="terms.html" target="_blank">TERMOS</a>
            <a class="chat-info" style="cursor: pointer;">REGRAS</a>
            </div>

        </div>


        </div>
    </div>
    
	<div class="main-wrapper">
        <main>
            <link rel="stylesheet" href="css/double.css">
<meta name="game" content="roulette" />
<div class="roulette">
    <div class="roulette-top">
        <div class="roulette-left">
            <div class="controls">
                <div class="inputs-area">
                    <label for="minesBet" class="label-input">Coloque um valor: </label>
                    <div class="amount flex flex-direction-row justify-content-space-between">
                        <input id="minesBet" type="number" class="value w70" min="1" max="100000" value="1" placeholder="Quantia"/>
                        <div class="button w12" data-action="1/2">1<span>/</span>2</div>
                        <div class="button w12" data-action="x2"><span>X</span>2</div>
                    </div>
                </div>
                <div class="color-select">
                    <span class="label-input">Selecione uma cor: </span>
                    <div class="buttons">
                        <button class="btn-multi active" data-value="red"> 
                            <div class="red-color"> <span>2X</span> </div>
                        </button>
                        <button class="btn-multi" data-value="green">
                            <div class="green-color"> <span style="color: #6407ff;">15X</span> </div>
                        </button>
                        <button class="btn-multi" data-value="black">
                            <div class="black-color"> <span>2X</span> </div>
                        </button>
                    </div>
                </div>
                <div class="play">
                    <button class="btn-play">Apostar</button>
                </div>

                <div class="rouletteButtons">
                    <div class="fa fa-volume-up" width="15px">

                    </div>
                </div>
            </div>
        </div>
        <div class="roulette-right">
        
            <div class="spinner">
            <div class="inner">
            <div class="roulette-wheel-outer">
                <div class="rolling">

                </div>
                <div class="roulette-wheel">
                <div class="fade-right"></div>
                <div class="fade-left"></div>
                    <div class="roulette-caret-down-left"><i class="fa fa-caret-down" aria-hidden="true"></i></div>
                    <div class="roulette-caret-up-right"><i class="fa fa-caret-up" aria-hidden="true"></i></div>
                </div>
            </div>
            </div>
            </div>
            <div class="balance-latest-divisoria">
                <div class="balance-latest-title">Giros anteriores</div>
                <div class="balance-latest-linha"></div>
            </div>
            <div class="balance-latest">
                <div class="latest"></div>
            </div>
            <!--<div class="crown-counter">Número do último giro: <span class="crown-counter-span">0</span></div>
            <div class="roulette-info">Round hash: ...</div>-->

        </div>
    </div>
    
<script src="js/roulette.js"></script>
        </main>
	    <div class="footer hide-mobile">

           
		   
		   
		   
	<link rel="stylesheet" href="css/footer.css">
		   
		   
		   
		   
		   
		   
		   
		   
		   
             <footer id="footer" class="">
                <?php include('footer_pag.php'); ?>
            </footer>
          	
	
	</div>

  <div class="popups">
        <div class="popup regras">
            <div class="popup-inner">
                <div class="popup-title">
                    REGRAS
                    <div class="popup-close">x</div>
                </div>
                <div class="content">
                    <p>- Coisas que vão te banir/silenciar:</p>
                    <ul>
                        <li>Spam</li>
                        <li>Implorando</li>
                        <li>Publicação de códigos de anúncio</li>
                        <li>Publicidade de outros sites</li>
                        <li>Usando um idioma diferente do português</li>
                        <li>Uso excessivo de capslock</li>
                        <li>Publicação de links para sites externos</li>
                    </ul>
                    <p>2 - Por favor, encaminhe todos os problemas para: <b style="color: #ffcc00;text-decoration: none !important;text-transform: none !important;"></b></p>
                    <p>3 - Por favor, encaminhe todas as dúvidas comerciais para: <b style="color: #ffcc00;text-decoration: none !important;text-transform: none !important;"></b></p>
                    <p>4 - Este site só atende clientes com 18 anos ou mais, Ao jogar, você concorda que atende ao requisito de idade legal.</p>
                    <p>5 - Mantenha o mínimo de palavrões, não chame outros usuários.</p>
                    <p>6 - BeyondOficial não assume nenhuma responsabilidade por apostas perdidas como resultado de latência de rede ou desconexões. Sempre garanta uma conexão estável antes de fazer apostas. Evite fazer apostas importantes no último segundo.</p>

                    <p><button class="popup-close">ENTENDO</button></p>
                </div>
            </div>
        </div>
        <form action="php/login/register.php" method="post">
          <div class="popup registerModal">
              <div class="popup-inner">
                  <div class="banner"><img src="img/Menu_imagem2.jpg" alt=""></div>
                  <div class="popup-register-double">
                      <div class="popup-title">
                          <h3>CADASTRE-SE</h3>
                          <div class="popup-close-register popup-close">X</div>
                      </div>
                      <div class="content">
            <br>
                          <div style="display:flex;flex-direction: column;margin-top: 30px;align-items:baseline">
                            
                
                <div class="relative" style="width: 100%;">
                                  <input class="inputRegister" style="width: 100%;padding-left: 28px" type="email" id="email" name="email" autocomplete="off" placeholder="Email" type="text" value="">
                                  <div style="font-size: 17px;top: 11px;" class="fa fa-envelope userIcon"></div>
                              </div>
                
                              <div class="relative" style="width: 100%;">
                                  <input class="inputRegister" style="width: 100%;padding-left: 28px" type="password" id="password" name="password" autocomplete="off" placeholder="Senha (6 a 22 caracteres)" type="text"  value="">
                                  <div style="font-size: 17px;top: 11px;" class="fa fa-lock userIcon"></div>
                              </div>
                
                              <div class="relative" style="width: 100%;">
                                  <input class="inputRegister" style="width: 100%;padding-left: 28px" type="password" id="confirmPassword" name="confirmPassword" autocomplete="off" placeholder="Confirmar Senha" type="text" value="">
                                  <div style="font-size: 17px;top: 11px;" class="fa fa-lock userIcon"></div>
                              </div>	
                
                          </div>		
              <br>
                          <div class="buttonBottom">
                <label for="" style="display:block;text-align: center;color: hsla(0, 0%, 100%, 0.5);font-size: 0.75rem;">Ao me cadastrar afirmo que tenho mais de 18 anos e aceito os termos de uso do site.</label>
                              <button class="register-button submit">Cadastrar</button>
                              <div class="flex flex-direction-row">Já tem conta aqui?<a class="login login-modal" style="margin-left:15px;">Fazer Login</a></div>
                          </div>

                          <script async>

                              $('#cpf1').mask('000.000.000-00', {reverse: true});

                              $('#phone1').mask('+55 (00) 00000-0009');
                              $('#phone1').blur(function (event) {
                                  if ($(this).val().length == 15) { // Celular com 9 dígitos + 2 dígitos DDD e 4 da máscara
                                      $(this).mask('+55 (00) 00000-0009');
                                  } else {
                                      $(this).mask('+55 (00) 00000-0009');
                                  }
                              });
                          </script>
                      </div>
                  </div>
              </div>
          </div>
        </form>  
        <form action="php/login/login.php" method="post">
          <div class="popup loginModal">
              <div class="popup-inner">
                  <div class="popup-title">
                      <h3>Login</h3>
                      <div class="popup-close-login popup-close">X</div>
                  </div>
                  <div class="content">
                      <div style="display:flex;flex-direction: column;margin-top: 30px;align-items:baseline;margin-bottom:20px;">
                          <div class="relative">
                              <input class="inputLogin" style="" type="email" id="loginEmail" name="loginEmail" autocomplete="off" placeholder="Email" type="text" value="">
                              <div style="font-size: 15px;top: 11px;" class="fa fa-envelope userIcon"></div>
                          </div>

                          <div class="relative">
                              <input class="inputLogin" style="" type="password" id="loginPassword" name="loginPassword" autocomplete="off" placeholder="Senha" type="text" value="">
                              <div style="font-size: 17px;top: 11px;" class="fa fa-lock userIcon"></div>
                          </div>

                          <div class="bottom-check flex flex-row w100" style="justify-content: space-between">
                              <div style="text-align: left; margin-top: 8px; font-size: 14px;display:flex;align-items:center">
                                  <input type="checkbox" style="margin-top: -2px;" class="check_box " id="i_agree_age"><label class="check_label" for="i_agree_age">Lembrar</label> 
                              </div>
                              <a href="#" class="txt-label forgetPss" style="margin-top: 8px;">Esqueceu a senha?</a>
                          </div>
                      </div>
                      <div class="buttonBottom">
                          <button class="login-button">Entrar</button>
                          <div class="flex flex-direction-row">Não tem login?<a class="register register-modal" style="margin-left:15px;">Cadastre-se</a></div>
                      </div>
                  </div>
              </div>
          </div>
        </form>  
        <div class="popup paymentModal">
            <div class="popup-inner" >
                <div class="popup-title">
                    <h3>Depósito</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
                <div class="content" style="margin-top: 20px;">
                    <div class="methods">
                        <div class="pix">
                            <svg xmlns="http://www.w3.org/2000/svg" width="79" height="80" viewBox="0 0 79 80" fill="none"><script xmlns="" async="false" type="text/javascript" src="#"/><path d="M61.2334 60.8114C58.1529 60.8114 55.2555 59.6119 53.0771 57.4346L41.3004 45.6575C40.4734 44.8284 39.0324 44.8309 38.2058 45.6575L26.386 57.4776C24.2076 59.655 21.3102 60.8544 18.2297 60.8544H15.9089L30.8246 75.7699C35.4827 80.428 43.0354 80.428 47.6938 75.7699L62.6519 60.8114H61.2334Z" fill="#32BCAD"/><path d="M18.2296 19.1545C21.3101 19.1545 24.2075 20.3539 26.3859 22.5313L38.2057 34.3532C39.0569 35.2048 40.4469 35.208 41.3002 34.3522L53.077 22.5744C55.2554 20.397 58.1528 19.1976 61.2332 19.1976H62.6517L47.694 4.23946C43.0352 -0.418972 35.4826 -0.418972 30.8245 4.23946L15.9094 19.1545L18.2296 19.1545Z" fill="#32BCAD"/><path d="M75.0245 31.57L65.9852 22.5307C65.7862 22.6104 65.5707 22.6602 65.3431 22.6602H61.2333C59.1085 22.6602 57.0285 23.522 55.5271 25.0245L43.7507 36.8013C42.6486 37.9034 41.2005 38.4548 39.7537 38.4548C38.3056 38.4548 36.8585 37.9034 35.7568 36.8024L23.9358 24.9815C22.4344 23.4786 20.3544 22.6172 18.2297 22.6172H13.1761C12.9606 22.6172 12.7592 22.5664 12.569 22.4948L3.49382 31.57C-1.16461 36.2284 -1.16461 43.7807 3.49382 48.4391L12.5687 57.5139C12.7592 57.4423 12.9606 57.3915 13.1761 57.3915H18.2297C20.3544 57.3915 22.4344 56.5301 23.9358 55.0276L35.7557 43.2077C37.8921 41.0731 41.6164 41.0724 43.7507 43.2087L55.5271 54.9845C57.0285 56.487 59.1085 57.3488 61.2333 57.3488H65.3431C65.5707 57.3488 65.7862 57.3985 65.9852 57.4783L75.0245 48.439C79.6825 43.7806 79.6825 36.2283 75.0245 31.5699" fill="#32BCAD"/></svg>
                            <div class="info"> 
                                <h3 class="w100">PIX</h3>
                                <div>Rápido e fácil!</div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>

        <form method="post">
          <div class="popup paymentPix">
              <div class="popup-inner" >
                  <div class="popup-title">
                      <h3>Depósito via Pix</h3>
                      <div class="popup-close-pix popup-close">x</div>
                  </div>
                  <div class="content" style="margin-top: 20px;">
                      <div class="methods">
                          <label for="pixvalue" class="txt-label">Informe o valor de depósito</label>
                          <div class="relative">
                              <input class="inputLogin" id="pixvalue" type="number" step="0.01" name="amount" autocomplete="off" placeholder="Mínimo de R$: 25,00" min="25" max="1000000" value="">
                              <div style="font-size: 17px;top: 11px;" class="fa fa-dollar userIcon"></div>
                          </div>
                          <div class="relative">
                              <input class="inputLogin" type="cpf" placeholder="Digite seu CPF" id="pixcpf" type="number" value="">
                              <div style="font-size: 15px;top: 11px;" class="fa fa-user userIcon"></div>
                          </div>
                                                      <div style="text-align: left; margin-top: 8px; font-size: 14px;display:flex;align-items:center;display:none">
                                  <input type="checkbox" class="check_box " id="i_agree_bonus" ><label class="check_label" for="i_agree_bonus">Quero receber o bônus para triplicar o valor depositado (acima de), pois li e concordo com os <a href="/terms" target="_blank" style="color:red">Termos</a>.</label>
                              </div>
                                              </div>
                  </div>
                  <div class="buttonBottom">
                      <button class="deposit-button submit">Continuar</button>
                  </div>
              </div>
          </div>
        </form>

        <div class="popup withdrawPix">
            <div class="popup-inner">
                <div class="popup-title">
                    <h3>Saque via Pix</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
				
							<div class="content" style="margin-top: 20px;">
                    <div class="">
                        <a style="text-size: 22px">Atualização de dados necessária!<a>                        
                    </div>
                </div>
				
                <div class="buttonBottom">
                    <a href="/update" class="btn">Atualizar</a>
                </div>
						
			            </div>
        </div>

        <div class="popup withdrawPix">
            <div class="popup-inner">
                <div class="popup-title">
                    <h3>Saque via Pix</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
				
			                <div class="content" style="margin-top: 20px;">
                    <div class="methods">
                        <label for="withdrawvalue" class="txt-label">Informe o valor de saque e sua chave pix <span style="color: red;font-weight: bold">CPF<span></label>
                        <div class="relative">
                            <input class="inputLogin" id="withdrawvalue" type="number" autocomplete="off" placeholder="Mínimo de R$: 50,00" min="50" max="500" value="">
                            <div style="font-size: 17px;top: 11px;" class="fa fa-dollar userIcon"></div>
                        </div>
                        <div class="relative">
                            <input class="inputLogin" type="text" placeholder="Digite sua cahve pix (CPF)" id="chavepix" value="055.810.900-41" disabled>
                            <div style="font-size: 15px;top: 11px;" class="fa fa-user userIcon"></div>
                        </div>
                    </div>
                </div>
                <div class="buttonBottom">
                    <button id="withdraw-button" class="withdraw-button confirm-button">Sacar</button>
                </div>
			            </div>
        </div>
        
		
                <div class="popup forgetPasswordModal">
            <div class="popup-inner">
                <div class="popup-title">
                    <h3>Recuperar Senha</h3>
                    <div class="popup-close-login popup-close">X</div>
                </div>
				
				<div class="content">
                    <div style="display:flex;flex-direction: column;margin-top: 30px;align-items:baseline;margin-bottom:20px;">
                        <div class="relative" style="display: flex; flex-direction: row">
                            <input class="inputLogin" style="width: 170px;padding-left: 28px" type="email" autocomplete="off" placeholder="Seu email" value=""> <button class="sendCode">Enviar<br>Código</button>
                            <div style="font-size: 15px;top: 11px;" class="fa fa-envelope userIcon"></div>
                        </div>
                        <div class="relative">
                            <input class="inputLogin" style="width: 275px;padding-left: 28px" type="text" autocomplete="off" placeholder="Código recebido no email" value="">
                            <div style="font-size: 15px;top: 11px;" class="fa fa-user-secret userIcon"></div>
                        </div>
                        <div class="relative">
                            <input class="inputLogin" style="width: 275px;padding-left: 28px" type="password" autocomplete="off" placeholder="Senha Nova" value="">
                            <div style="font-size: 15px;top: 11px;" class="fa fa-lock userIcon"></div>
                        </div>
                    </div>
                    <div class="buttonBottom">
                        <button class="forgetButton changePassword">Mudar Senha</button>
                    </div>
                </div>
				
            </div>
        </div>
		        <div class="popup bonusModal">
            <div class="popup-inner" >
                <div class="popup-title">
                    <h3>Bônus</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
                <div class="content" style="margin-top: 20px;">
                    <div class="bonusDetails"> 
                                            </div>
                    <div class="buttonBottom">
                        <button class="removeBonus">REMOVER BÔNUS</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="popup bonusModal">
            <div class="popup-inner" >
                <div class="popup-title">
                    <h3>Ativar Código</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
                <div class="content" style="margin-top: 20px;">
                    <div class="bonusDetails"> 
                        <label for="promotioncode" class="txt-label">Informe o código que deseja ativar (É necessário depositar R$20,00 para ativar).</label>
                        <div class="relative">
                            <input class="inputLogin" id="promotioncode" style="width: 350px;" type="text" autocomplete="off" placeholder="Código promocional" value="">
                        </div>
                    </div>
                    <div class="buttonBottom">
                        <button class="activateBonus">ATIVAR BÔNUS</button>
                    </div>
                </div>
            </div>
        </div>    </div>



<script src="js/anijs.js"></script>
<script src="js/helpers/dom/anijs-helper-dom.js"></script>
<script src='js/vendor.js'></script>
<script src="js/lang/en.js"></script>

<script src="js/progress.min.js"></script>
<script src="js/HackTimerWorker.min.js"></script>
<script src="js/HackTimer.silent.min.js"></script>
<script src="js/chat.js"></script>
<script src="js/app.js"></script>
<script>
        function atualizarSaldo() {
            $.ajax({
                url: 'php/login/atualizar_saldo.php',
                type: 'GET',
                success: function(data) {
                    $('#balance').text(data);
                }
            });
        }

        // Chame a função para atualizar o saldo periodicamente (por exemplo, a cada 5 segundos).
        setInterval(atualizarSaldo, 10000000); // 5000 milissegundos = 5 segundos

  </script>
<script>
		$(document).ready( function () {
					});
        // Function to request fullscreen on the iframe
        function requestFullscreen() {
            const iframe = document.getElementById('myIframe');
            if (iframe.requestFullscreen) {
                iframe.requestFullscreen();
            } else if (iframe.mozRequestFullScreen) { // Firefox
                iframe.mozRequestFullScreen();
            } else if (iframe.webkitRequestFullscreen) { // Chrome, Safari, and Opera
                iframe.webkitRequestFullscreen();
            } else if (iframe.msRequestFullscreen) { // IE/Edge
                iframe.msRequestFullscreen();
            }
        }

        // Get the button element by its ID
        const fullscreenButton = document.getElementById('fullscreenButton');

        // Add a click event listener to the button
        fullscreenButton.addEventListener('click', function() {
            requestFullscreen(); // Request fullscreen when the button is clicked
        });
    </script>
</body>



</html>
