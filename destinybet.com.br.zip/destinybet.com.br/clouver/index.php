<?php

include('conexao.php');
include('php/login/fuctions.php');

require __DIR__ . '/vendor/autoload.php';



$accessToken = 'APP_USR-5811039818886604-081320-9f8d802296d8280e199ef0b9f77583b2-1333160103'; // Substitua pela sua chave de acesso do Mercado Pago
$publicKey = 'APP_USR-b24923a5-2f11-44d9-b254-4723d0084cd0';     // Substitua pela sua chave pública do Mercado Pago
$baseURL = 'http://localhost/cassino2/www.clouverbet.com/index.php'; // Substitua pela URL base do seu projeto

\MercadoPago\SDK::setAccessToken($accessToken);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['amount'])) {
    $amount = floatval($_POST['amount']);
    $userReference = $_SESSION['user_id']; // Substitua pela forma como você identifica o usuário

    // Criar preferência de pagamento
    $preference = new \MercadoPago\Preference();
    
    $item = new \MercadoPago\Item();
    $item->title = 'Adição de Saldo';
    $item->quantity = 1;
    $item->unit_price = $amount;
    
    $preference->items = array($item);
    $preference->back_urls = [
        'success' => $baseURL . '/success.php',
        'failure' => $baseURL . '/failure.php',
        'pending' => $baseURL . '/pending.php'
    ];
    
    $preference->auto_return = 'approved';
    $preference->save();
    
    header('Location: ' . $preference->init_point);
    exit();
}

// Código de tratamento de webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type']) && $_POST['type'] === 'payment') {
    $paymentId = $_POST['id'];

    // Consultar detalhes do pagamento
    $payment = \MercadoPago\Payment::find_by_id($paymentId);

    if ($payment) {
        $userId = $payment->external_reference; // Supondo que você use uma referência externa para identificar o usuário
        $amount = $payment->transaction_amount;
        $status = $payment->status;
        
        // Registrar a transação no banco de dados
        $conn = new mysqli('localhost', 'root', '', 'mercado-pago-api');
        if ($conn->connect_error) {
            die("Erro de conexão: " . $conn->connect_error);
        }

        $sql = "INSERT INTO transactions (user_id, amount, status, payment_id) VALUES ('$userId', '$amount', '$status', '$paymentId')";
        if ($conn->query($sql) === TRUE) {
            if ($status === 'approved') {
                // Atualizar o saldo do usuário no seu sistema
                $updateBalanceSql = "UPDATE users SET saldo = saldo + '$amount' WHERE id = '$userId'";
                if ($conn->query($updateBalanceSql) !== TRUE) {
                    echo "Erro ao atualizar saldo do usuário: " . $conn->error;
                }
            }
            http_response_code(200); // Responder ao Mercado Pago para confirmar o recebimento da notificação
        } else {
            echo "Erro ao registrar transação: " . $conn->error;
        }

        $conn->close();
    }
}

$balance = 0;

if(isset($_SESSION['id']) && isset($_SESSION['balance'])) {
    $sth = mysqli_query($conn, "SELECT balance FROM users WHERE id = '$_SESSION[id]'");
    while($st1=mysqli_fetch_assoc($sth)){
        $_SESSION['balance'] = $st1['balance'];
    }
} else {
    $_SESSION['balance'] = 0; // Define um valor padrão se o saldo não estiver definido na sessão
}

$bonus = 0;

if(isset($_SESSION['id']) && isset($_SESSION['bonus'])) {
    $sth = mysqli_query($conn, "SELECT bonus FROM users WHERE id = '$_SESSION[id]'");
    while($st1=mysqli_fetch_assoc($sth)){
        $_SESSION['bonus'] = $st1['bonus'];
    }
} else {
    $_SESSION['bonus'] = 0; // Define um valor padrão se o saldo não estiver definido na sessão
}


$total = $_SESSION['balance'] + $_SESSION['bonus'];
?>




<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>ClouverBET | Online</title>
    
	<link rel="stylesheet" href="css/newmenu.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <meta property="og:type" content="website" />
    <meta property="og:url" content="/" />
    <meta name="description" content="Jogue com seus amigos e ganhe dinheiro!">
    <meta name="keywords" content="cassino, site de apostas, crash, foguetinho, double">
    <link rel="icon" type="image/ico" href="favicon.ico" />

    <meta name="csrf-token" content="" />
    <meta name="language" content="en" />
    <meta name="logged" content="0" />
    <meta name="email" content="" />
    <meta name="id" content="" />
    <meta name="username" content=""/>
    <meta name="avatar" content=""/>
    <meta name="token" content=""/>
    <meta name="time" content="1696977627"/>
	
    <link rel="icon" type="image/ico" href="favicon.ico" />
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/app.css">
    <link rel="stylesheet" href="css/custon.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/appnew.css">
    <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

    <script src="../ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="../cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script src="../cdn.jsdelivr.net/npm/bootstrap%405.1.3/dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<style>
		
	    <div class="footer">


		
	</style>
</head>

<body>





<div class="navbar2">
    <style>
 
  


.modal-dash-content {
  position: absolute;
  width: 375px;
  box-sizing: border-box;
  padding: 0;
  border-radius: 0 0 2px 2px;
  background-color: #e4e4e4;
  z-index: 70;
}

.modal-dash-top {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  padding: 20px 15px;
  background: #f8f9fa;
}

.modal-dash-top > div {
  display: flex;
  color: #404040;
}

.modal-dash-top > div:first-of-type {
  display: flex;
  justify-content: space-between;
  padding-bottom: 20px;
}

.modal-dash-top > div:first-of-type span p {
  font-size: 12px;
}

.modal-dash-top > div:first-of-type span strong {
  font-size: 20px;
}

.modal-dash-top > div:first-of-type a {
  display: flex;
  align-items: center;
  vertical-align: middle;
  padding: 0 12px;
  border: 1px solid #c3c3c3;
  color: #404040;
  border-radius: 2px;
  height: 44px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 700;
  line-height: 14px;
  min-width: 120px;
  align-items: center;
  justify-content: center;
  background-color: #fafbfc;
}

.modal-dash-top > div:first-of-type a:hover {
  background: #FFF;
}

.modal-dash-top > div:first-of-type a:before {
  position: relative;
  top: 2px;
  content: "";
  width: 12px;
  height: 13px;
  margin-right: 10px;
  background-repeat: no-repeat;
  background-position: 50%;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 13'%3E%3Cpath fill='%23404040' d='M4.586 7.802L6 9.212l1.414-1.41-.003-.003 3.271-3.278-1.414-1.41L7 5.383V0H5l.002 5.385-2.27-2.274-1.414 1.41L4.588 7.8l-.002.003zM12 13v-1.995H0V13h12z'/%3E%3C/svg%3E");
}

.modal-dash-top > div:last-of-type > span:first-of-type {
  margin-right: 48px;
}


.modal-dash-top > div:last-of-type span p {
  font-size: 11px;
}

.modal-dash-top > div:last-of-type span strong {
  font-size: 15px;
}




.modal-dash-options {
  border-top: 1px solid #d4d4d4;
}

.um-GeneralTab_AccountContainer {
  display: flex;
  flex-wrap: wrap;
  background-color: #f3f5f4;
  box-sizing: border-box;
  padding: 20px 0 10px 5px;
  justify-content: space-around;
  width: 100%;
}

.ul-MembersLinkButton {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 11px;
  font-weight: 700;
  color: #505050;
  line-height: 17px;
  margin-right: 5px;
  padding-bottom: 20px;
  min-width: 100px;
  cursor: pointer;
  text-align: center;
  flex: 1 0 31%;
  max-width: 31%;
}

.ul-MembersLinkButton:hover {
  opacity: 0.8;
}

.ul-MembersLinkButton_Icon {
  height: 39px;
  margin-bottom: 8px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton {
  cursor: pointer;
}

.um-MessagesButton:hover {
  opacity: 0.8;
}

.um-MessagesButton_Icon {
  position: relative;
  height: 39px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton_MessagesCount {
  font-size: 10px;
  border-radius: 999px;
  color: #3b3b3b;
  background-color: #58d7af;
  line-height: 17px;
  height: 17px;
  width: 17px;
  top: 6px;
  right: 0;
  text-align: center;
  position: absolute;
  font-weight: 700;
}

.um-MessagesButton_Text {
  font-size: 11px;
  color: #505050;
  font-weight: 700;
  line-height: 17px;
  padding-top: 8px;
}

.modal-dash-footer {
  display: flex;
  flex-direction: column;
}

.modal-dash-footer > a {
  background-color: #f8f9fa;
  display: flex;
  align-items: center;
  width: 100%;
  height: 50px;
  font-size: 15px;
  color: #404040;
  box-sizing: border-box;
  padding: 0 15px;
  border-top: 1px solid #d4d4d4;
  transition: none;
}

.modal-dash-footer > a:hover {
  background:#fff;
  opacity: 1;
}

@media  screen and (max-width: 768px) {


.modal-dash-content {
  position: relative;
     left: -260px;
	 top: -15px;
  width: 375px;
  box-sizing: border-box;
 
  animation: all 0 .25s;
  border-radius: 0 0 2px 2px;
  background-color: #e4e4e4;
  z-index: 99;
}

.modal-dash-top {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  padding: 20px 15px;
  background: #f8f9fa;
}

.modal-dash-top > div {
  display: flex;
  color: #404040;
}

.modal-dash-top > div:first-of-type {
  display: flex;
  justify-content: space-between;
  padding-bottom: 20px;
}

.modal-dash-top > div:first-of-type span p {
  font-size: 12px;
}

.modal-dash-top > div:first-of-type span strong {
  font-size: 20px;
}

.modal-dash-top > div:first-of-type a {
  display: flex;
  align-items: center;
  vertical-align: middle;
  padding: 0 12px;
  border: 1px solid #c3c3c3;
  color: #404040;
  border-radius: 2px;
  height: 44px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 700;
  line-height: 14px;
  min-width: 120px;
  align-items: center;
  justify-content: center;
  background-color: #fafbfc;
}

.modal-dash-top > div:first-of-type a:hover {
  background: #FFF;
}

.modal-dash-top > div:first-of-type a:before {
  position: relative;
  top: 2px;
  content: "";
  width: 12px;
  height: 13px;
  margin-right: 10px;
  background-repeat: no-repeat;
  background-position: 50%;
  background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 13'%3E%3Cpath fill='%23404040' d='M4.586 7.802L6 9.212l1.414-1.41-.003-.003 3.271-3.278-1.414-1.41L7 5.383V0H5l.002 5.385-2.27-2.274-1.414 1.41L4.588 7.8l-.002.003zM12 13v-1.995H0V13h12z'/%3E%3C/svg%3E");
}

.modal-dash-top > div:last-of-type > span:first-of-type {
  margin-right: 48px;
}


.modal-dash-top > div:last-of-type span p {
  font-size: 11px;
}

.modal-dash-top > div:last-of-type span strong {
  font-size: 15px;
}




.modal-dash-options {
  border-top: 1px solid #d4d4d4;
}

.um-GeneralTab_AccountContainer {
  display: flex;
  flex-wrap: wrap;
  background-color: #f3f5f4;
  box-sizing: border-box;
  padding: 20px 0 10px 5px;
  justify-content: space-around;
  width: 100%;
}

.ul-MembersLinkButton {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-size: 11px;
  font-weight: 700;
  color: #505050;
  line-height: 17px;
  margin-right: 5px;
  padding-bottom: 20px;
  min-width: 100px;
  cursor: pointer;
  text-align: center;
  flex: 1 0 31%;
  max-width: 31%;
}

.ul-MembersLinkButton:hover {
  opacity: 0.8;
}

.ul-MembersLinkButton_Icon {
  height: 39px;
  margin-bottom: 8px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton {
  cursor: pointer;
}

.um-MessagesButton:hover {
  opacity: 0.8;
}

.um-MessagesButton_Icon {
  position: relative;
  height: 39px;
  display: flex;
  justify-content: center;
  align-items: flex-end;
}

.um-MessagesButton_MessagesCount {
  font-size: 10px;
  border-radius: 999px;
  color: #3b3b3b;
  background-color: #58d7af;
  line-height: 17px;
  height: 17px;
  width: 17px;
  top: 6px;
  right: 0;
  text-align: center;
  position: absolute;
  font-weight: 700;
}

.um-MessagesButton_Text {
  font-size: 11px;
  color: #505050;
  font-weight: 700;
  line-height: 17px;
  padding-top: 8px;
}

.modal-dash-footer {
  display: flex;
  flex-direction: column;
}

.modal-dash-footer > a {
  background-color: #f8f9fa;
  display: flex;
  align-items: center;
  width: 100%;
  height: 50px;
  font-size: 15px;
  color: #404040;
  box-sizing: border-box;
  padding: 0 15px;
  border-top: 1px solid #d4d4d4;
  transition: none;
}

.modal-dash-footer > a:hover {
  background:#fff;
  opacity: 1;
}

}



    </style>
	<!-- Desktop -->

  <?php
    include('header_pag.php');
    ?>

	
    
    <div class="mobile-menu">        

        <div class="icon-menu click-open-menu">
            <i class="fa-solid fa-bars"></i>
            <span>Menu</span>
        </div>
        <div class="icon-roulette">
            <a href="casino/providers/evoplay.php">
               <i class="fa-solid fa-gamepad"></i>
                <span>Cassino</span>
            </a>
        </div>
        
       

        <div class="icon-help">
            <a href="casino/providers/evolution.php">
               <i class="fa-solid fa-circle-play"></i>
                <span>Ao Vivo</span>
            </a>
        </div>
		
		 <div class="icon-chat">
            <i class="fa-solid fa-message"></i>
            <span>Chat</span>
        </div>

    </div>
	<nav class="right mobile-show">
  <a href="user/referrals.php" class="link-menu"> <div  class="btnDespositar "  ><a href="" style="margin-top: -5px;"> Ganhe R$ 100,00 gratis 💥 </a> </div> </a>
				 
            <div class="games">
				
            
                    <div style="background-color: #202a39;  border-radius: 8px; margin-left: 14px; width: 211px;"> 
                      <details class="collapse show" open>                 
                      <summary class="title">
                      <i  style="font-size: 16px; margin-left: 5px; margin-right:7px; color: #8c9099;"></i>
                      <a style="color:white;">🔥 EM ALTA</a>
                    </summary>
                    <div class="btnGames">
                        <a href="crash.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-rocket"  style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Crash</div>
                            </div>
                        </a>
                        <a href="dice.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fas fa-dice" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Dice</div>
                            </div>
                        </a>
                        <a href="double.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-dharmachakra" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Double</div>
                            </div>
                        </a>
                        <a href="mines.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 0H8C7.72386 0 7.5 0.223858 7.5 0.5V4.5C7.5 4.77614 7.72386 5 8 5H12C12.2761 5 12.5 4.77614 12.5 4.5V0.5C12.5 0.223858 12.2761 0 12 0Z" fill="#8C9099"></path><path d="M4.5 0H0.5C0.223858 0 0 0.223858 0 0.5V4.5C0 4.77614 0.223858 5 0.5 5H4.5C4.77614 5 5 4.77614 5 4.5V0.5C5 0.223858 4.77614 0 4.5 0Z" fill="#8C9099"></path><path d="M19.5 7.5H15.5C15.2239 7.5 15 7.72386 15 8V12C15 12.2761 15.2239 12.5 15.5 12.5H19.5C19.7761 12.5 20 12.2761 20 12V8C20 7.72386 19.7761 7.5 19.5 7.5Z" fill="#8C9099"></path><path d="M19.5 15H15.5C15.2239 15 15 15.2239 15 15.5V19.5C15 19.7761 15.2239 20 15.5 20H19.5C19.7761 20 20 19.7761 20 19.5V15.5C20 15.2239 19.7761 15 19.5 15Z" fill="#8C9099"></path><path d="M19.5 0H15.5C15.3674 0 15.2402 0.0526784 15.1464 0.146447C15.0527 0.240215 15 0.367392 15 0.5V4.5C15 4.63261 15.0527 4.75979 15.1464 4.85355C15.2402 4.94732 15.3674 5 15.5 5H19.5C19.6326 5 19.7598 4.94732 19.8536 4.85355C19.9473 4.75979 20 4.63261 20 4.5V0.5C20 0.367392 19.9473 0.240215 19.8536 0.146447C19.7598 0.0526784 19.6326 0 19.5 0V0ZM17.5 3.75C17.2528 3.75 17.0111 3.67669 16.8055 3.53934C16.6 3.40199 16.4398 3.20676 16.3451 2.97835C16.2505 2.74995 16.2258 2.49861 16.274 2.25614C16.3223 2.01366 16.4413 1.79093 16.6161 1.61612C16.7909 1.4413 17.0137 1.32225 17.2561 1.27402C17.4986 1.22579 17.7499 1.25054 17.9784 1.34515C18.2068 1.43976 18.402 1.59998 18.5393 1.80554C18.6767 2.0111 18.75 2.25277 18.75 2.5C18.75 2.83152 18.6183 3.14946 18.3839 3.38388C18.1495 3.6183 17.8315 3.75 17.5 3.75Z" fill="#414952"></path><path d="M12 7.5H8C7.86739 7.5 7.74021 7.55268 7.64645 7.64645C7.55268 7.74021 7.5 7.86739 7.5 8V12C7.5 12.1326 7.55268 12.2598 7.64645 12.3536C7.74021 12.4473 7.86739 12.5 8 12.5H12C12.1326 12.5 12.2598 12.4473 12.3536 12.3536C12.4473 12.2598 12.5 12.1326 12.5 12V8C12.5 7.86739 12.4473 7.74021 12.3536 7.64645C12.2598 7.55268 12.1326 7.5 12 7.5ZM10 11.25C9.75277 11.25 9.5111 11.1767 9.30554 11.0393C9.09998 10.902 8.93976 10.7068 8.84515 10.4784C8.75054 10.2499 8.72579 9.99861 8.77402 9.75614C8.82225 9.51366 8.9413 9.29093 9.11612 9.11612C9.29093 8.9413 9.51366 8.82225 9.75614 8.77402C9.99861 8.72579 10.2499 8.75054 10.4784 8.84515C10.7068 8.93976 10.902 9.09998 11.0393 9.30554C11.1767 9.5111 11.25 9.75277 11.25 10C11.25 10.3315 11.1183 10.6495 10.8839 10.8839C10.6495 11.1183 10.3315 11.25 10 11.25Z" fill="#414952"></path><path d="M10 18.75C10.6904 18.75 11.25 18.1904 11.25 17.5C11.25 16.8096 10.6904 16.25 10 16.25C9.30964 16.25 8.75 16.8096 8.75 17.5C8.75 18.1904 9.30964 18.75 10 18.75Z" fill="#8C9099"></path><path d="M2.5 11.25C3.19036 11.25 3.75 10.6904 3.75 10C3.75 9.30964 3.19036 8.75 2.5 8.75C1.80964 8.75 1.25 9.30964 1.25 10C1.25 10.6904 1.80964 11.25 2.5 11.25Z" fill="#8C9099"></path><path d="M4.5 15H0.5C0.367392 15 0.240215 15.0527 0.146447 15.1464C0.0526784 15.2402 0 15.3674 0 15.5L0 19.5C0 19.6326 0.0526784 19.7598 0.146447 19.8536C0.240215 19.9473 0.367392 20 0.5 20H4.5C4.63261 20 4.75979 19.9473 4.85355 19.8536C4.94732 19.7598 5 19.6326 5 19.5V15.5C5 15.3674 4.94732 15.2402 4.85355 15.1464C4.75979 15.0527 4.63261 15 4.5 15ZM2.5 18.75C2.25277 18.75 2.0111 18.6767 1.80554 18.5393C1.59998 18.402 1.43976 18.2068 1.34515 17.9784C1.25054 17.7499 1.22579 17.4986 1.27402 17.2561C1.32225 17.0137 1.4413 16.7909 1.61612 16.6161C1.79093 16.4413 2.01366 16.3223 2.25614 16.274C2.49861 16.2258 2.74995 16.2505 2.97835 16.3451C3.20676 16.4398 3.40199 16.6 3.53934 16.8055C3.67669 17.0111 3.75 17.2528 3.75 17.5C3.75 17.8315 3.6183 18.1495 3.38388 18.3839C3.14946 18.6183 2.83152 18.75 2.5 18.75Z" fill="#414952"></path></svg>
                                </div>
                                <div class="btnGameName">Mines</div>
                            </div>
                        </a>
                        <a href="tower.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <div class="icon fa fa-chess-rook" style="font-size: 17px; color: #8c9099;"></div>
                                </div>
                                <div class="btnGameName">Tower</div>
                            </div>
                        </a>
                        <div class="line" style="margin-bottom: 20px;"></div>
                    </div>
                        
                      
                </details>
                </div>
                
                <div style="background-color: #202a39;  border-radius: 8px; margin-left: 14px; width: 211px; margin-top: 20px"> 
                <details class="collapse show" style="border-bottom: 1px solid #040615;">
                    <summary class="title"><i  style="font-size: 16px; margin-left: 5px; margin-right:7px; color:white;"></i>
					<a style="color:white;">CASSINO</a>
					</summary>
                    <div class="btnGames">

                         <a href="pg/tiger.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path fill-rule="evenodd" clip-rule="evenodd" d="M19.29 13.8499H16.72C16.2274 15.4328 15.3355 16.862 14.13 17.9999H19.29C19.3819 18.0012 19.4732 17.9844 19.5587 17.9505C19.6441 17.9165 19.722 17.8661 19.7879 17.802C19.8539 17.7379 19.9065 17.6615 19.9429 17.5771C19.9793 17.4926 19.9987 17.4019 20 17.3099V14.5399C19.9987 14.448 19.9793 14.3572 19.9429 14.2728C19.9065 14.1884 19.8539 14.1119 19.7879 14.0479C19.722 13.9838 19.6441 13.9333 19.5587 13.8994C19.4732 13.8654 19.3819 13.8486 19.29 13.8499Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M7.14 4.15005C6.2149 4.1315 5.29529 4.29655 4.43437 4.63564C3.57346 4.97473 2.78831 5.48114 2.12434 6.12558C1.46037 6.77002 0.930748 7.53971 0.566115 8.39012C0.201481 9.24054 0.00906694 10.1548 0 11.0801C0.0103792 12.0045 0.20376 12.9176 0.568979 13.7669C0.934198 14.6162 1.46402 15.3847 2.12786 16.028C2.7917 16.6714 3.5764 17.1769 4.43667 17.5154C5.29694 17.8539 6.21573 18.0186 7.14 18.0001C8.0651 18.0199 8.98497 17.8562 9.8464 17.5183C10.7078 17.1805 11.4937 16.6752 12.1586 16.0317C12.8235 15.3881 13.3542 14.6192 13.7201 13.7693C14.0859 12.9193 14.2796 12.0053 14.29 11.0801C14.281 10.1539 14.0882 9.23884 13.723 8.38776C13.3577 7.53668 12.8272 6.76654 12.1621 6.12196C11.4971 5.47739 10.7108 4.97119 9.84869 4.6327C8.98662 4.29421 8.06594 4.13016 7.14 4.15005ZM7.14 15.5001C6.53984 15.5093 5.94373 15.4003 5.38573 15.1791C4.82772 14.958 4.31874 14.6291 3.88786 14.2112C3.45699 13.7933 3.11265 13.2946 2.87452 12.7437C2.63638 12.1927 2.50912 11.6002 2.5 11.0001C2.50912 10.3999 2.63638 9.8074 2.87452 9.25643C3.11265 8.70546 3.45699 8.20679 3.88786 7.78892C4.31874 7.37104 4.82772 7.04214 5.38573 6.82099C5.94373 6.59984 6.53984 6.49079 7.14 6.50005C7.74099 6.48946 8.33817 6.59753 8.89734 6.81808C9.4565 7.03863 9.96666 7.36732 10.3986 7.78533C10.8305 8.20334 11.1758 8.70245 11.4145 9.25409C11.6533 9.80572 11.7809 10.399 11.79 11.0001C11.7809 11.6011 11.6533 12.1944 11.4145 12.746C11.1758 13.2977 10.8305 13.7968 10.3986 14.2148C9.96666 14.6328 9.4565 14.9615 8.89734 15.182C8.33817 15.4026 7.74099 15.5106 7.14 15.5001Z" fill="#414952"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M19.29 7.24469e-05H3.56999C3.47806 -0.00125019 3.38677 0.015549 3.30134 0.0495107C3.2159 0.0834723 3.13799 0.133931 3.07206 0.198005C3.00613 0.26208 2.95347 0.338514 2.91708 0.422944C2.88069 0.507374 2.86129 0.598144 2.85999 0.690072V2.33007C4.70496 1.47094 6.76527 1.18513 8.77444 1.50959C10.7836 1.83405 12.6492 2.75387 14.13 4.15007H19.29C19.3819 4.1514 19.4732 4.1346 19.5586 4.10063C19.6441 4.06667 19.722 4.01621 19.7879 3.95214C19.8538 3.88807 19.9065 3.81163 19.9429 3.7272C19.9793 3.64277 19.9987 3.552 20 3.46007V0.690072C19.9987 0.598144 19.9793 0.507374 19.9429 0.422944C19.9065 0.338514 19.8538 0.26208 19.7879 0.198005C19.722 0.133931 19.6441 0.0834723 19.5586 0.0495107C19.4732 0.015549 19.3819 -0.00125019 19.29 7.24469e-05Z" fill="#8C9099"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M19.29 6.91999H16.16C16.8131 8.20971 17.1556 9.63432 17.16 11.08H19.31C19.4027 11.0813 19.4948 11.0642 19.5809 11.0296C19.667 10.995 19.7454 10.9437 19.8114 10.8785C19.8775 10.8134 19.9299 10.7358 19.9657 10.6502C20.0015 10.5646 20.02 10.4728 20.02 10.38V7.61999C20.02 7.52722 20.0015 7.43537 19.9657 7.34978C19.9299 7.2642 19.8775 7.18658 19.8114 7.12145C19.7454 7.05632 19.667 7.00496 19.5809 6.97038C19.4948 6.9358 19.4027 6.91867 19.31 6.91999" fill="#8C9099"></path><path d="M7.61002 7.5V8.35C8.07547 8.38455 8.52691 8.52477 8.93002 8.76L8.39002 9.76C8.13205 9.55018 7.81238 9.43074 7.48002 9.42C7.3099 9.40748 7.14058 9.45334 7.00002 9.55C6.94854 9.57733 6.90494 9.61743 6.87342 9.66647C6.84189 9.7155 6.82351 9.77181 6.82002 9.83C6.82365 9.88077 6.83801 9.9302 6.86214 9.97502C6.88627 10.0198 6.91963 10.059 6.96002 10.09C7.06194 10.1872 7.18525 10.2591 7.32002 10.3L7.75002 10.44C8.12485 10.5508 8.46773 10.7497 8.75002 11.02C8.96681 11.2726 9.08099 11.5973 9.07002 11.93C9.07151 12.1295 9.04458 12.3281 8.99002 12.52C8.95816 12.6907 8.89364 12.8537 8.80002 13C8.66033 13.1449 8.49826 13.2665 8.32002 13.36C8.09158 13.473 7.85408 13.5666 7.61002 13.64V14.51H6.94002V13.67C6.77862 13.6722 6.61751 13.6554 6.46002 13.62C6.28976 13.5873 6.12251 13.5405 5.96002 13.48L5.50002 13.28C5.37124 13.2029 5.2535 13.1087 5.15002 13L5.74002 12C6.09377 12.3505 6.56297 12.5602 7.06002 12.59C7.2273 12.5924 7.39131 12.5435 7.53002 12.45C7.59098 12.4093 7.64106 12.3543 7.67591 12.2898C7.71077 12.2253 7.72934 12.1533 7.73002 12.08C7.73002 11.87 7.57002 11.72 7.26002 11.62L6.85002 11.5C6.63064 11.4331 6.41669 11.3495 6.21002 11.25C6.0533 11.1715 5.91123 11.0666 5.79002 10.94C5.67924 10.8259 5.59402 10.6896 5.54002 10.54C5.48099 10.3663 5.45389 10.1834 5.46002 10C5.4598 9.80317 5.49016 9.6075 5.55002 9.42C5.60707 9.23546 5.70249 9.06506 5.83002 8.92C5.95574 8.7658 6.11246 8.63975 6.29002 8.55C6.49065 8.44102 6.71228 8.37623 6.94002 8.36V7.5H7.61002Z" fill="#8C9099"></path></g><defs><clipPath id="clip0"><rect width="20" height="18" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Fortune Tiger</div>
                            </div>
                        </a>
                        <a href="index.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path fill-rule="evenodd" clip-rule="evenodd" d="M10 15.69L0 11.97V14.45L10 18.17L20 14.45V11.97L10 15.69Z" fill="#414952"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M10.82 6.28003V9.93003H9.18005V6.28003L0.180046 9.69003C0.129444 9.708 0.0856492 9.74121 0.0546784 9.78508C0.0237076 9.82895 0.00708008 9.88133 0.00708008 9.93503C0.00708008 9.98873 0.0237076 10.0411 0.0546784 10.085C0.0856492 10.1288 0.129444 10.1621 0.180046 10.18L9.83005 13.77C9.94665 13.8104 10.0734 13.8104 10.19 13.77L19.84 10.18C19.8906 10.1621 19.9344 10.1288 19.9654 10.085C19.9964 10.0411 20.013 9.98873 20.013 9.93503C20.013 9.88133 19.9964 9.82895 19.9654 9.78508C19.9344 9.74121 19.8906 9.708 19.84 9.69003L10.82 6.28003Z" fill="#8C9099"></path><path d="M10 4.58C11.2648 4.58 12.29 3.55473 12.29 2.29C12.29 1.02527 11.2648 0 10 0C8.73529 0 7.71002 1.02527 7.71002 2.29C7.71002 3.55473 8.73529 4.58 10 4.58Z" fill="#414952"></path></g><defs><clipPath id="clip0"><rect width="20" height="18.17" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Fortune Panda</div>
                            </div>
                        </a>
                     
                        <div class="line" style="margin-bottom: 20px;"></div>
                    </div>
                </details>
                </div>
                <div style="background-color: #202a39;  border-radius: 8px; margin-left: 14px; width: 211px; margin-top: 20px;
                padding: 15px;"> 
				
                 
                    <div class="btnGames">
                        <a href="support.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.2 13.6V14.024C15.1937 14.3381 15.0645 14.6372 14.8402 14.857C14.6158 15.0769 14.3141 15.2001 14 15.2H10V16H14C14.5304 16 15.0391 15.7893 15.4142 15.4142C15.7893 15.0391 16 14.5304 16 14V12.8C15.7748 13.1052 15.5052 13.3748 15.2 13.6Z" fill="#414952"></path><path d="M0 10.5839C0.049109 9.80103 0.327312 9.04988 0.8 8.42389V8.30389C0.289133 8.88313 0.00499042 9.62758 0 10.3999C0 10.4639 0 10.5199 0 10.5839Z" fill="#414952"></path><path d="M8 0C5.87827 0 3.84344 0.842855 2.34315 2.34315C0.842855 3.84344 0 5.87827 0 8H0C0.244633 7.6957 0.529976 7.42651 0.848 7.2C1.05156 5.44594 1.89262 3.82784 3.21126 2.65338C4.5299 1.47892 6.23417 0.829998 8 0.829998C9.76583 0.829998 11.4701 1.47892 12.7887 2.65338C14.1074 3.82784 14.9484 5.44594 15.152 7.2C15.47 7.42651 15.7554 7.6957 16 8C16 5.87827 15.1571 3.84344 13.6569 2.34315C12.1566 0.842855 10.1217 0 8 0V0Z" fill="#414952"></path><path d="M3.2 7.20001C2.35131 7.20001 1.53737 7.53715 0.937258 8.13727C0.337142 8.73739 0 9.55132 0 10.4C0 11.2487 0.337142 12.0626 0.937258 12.6628C1.53737 13.2629 2.35131 13.6 3.2 13.6V7.20001Z" fill="#8C9099"></path><path d="M12.8 13.6C13.6487 13.6 14.4626 13.2629 15.0627 12.6628C15.6628 12.0626 16 11.2487 16 10.4C16 9.55132 15.6628 8.73739 15.0627 8.13727C14.4626 7.53715 13.6487 7.20001 12.8 7.20001V13.6Z" fill="#8C9099"></path><path d="M3.20001 7.20001H4.00001C4.21219 7.20001 4.41567 7.2843 4.5657 7.43433C4.71573 7.58436 4.80001 7.78784 4.80001 8.00001V12.8C4.80001 13.0122 4.71573 13.2157 4.5657 13.3657C4.41567 13.5157 4.21219 13.6 4.00001 13.6H3.20001V7.20001Z" fill="#414952"></path><path d="M12 7.20001H12.8V13.6H12C11.7878 13.6 11.5844 13.5157 11.4343 13.3657C11.2843 13.2157 11.2 13.0122 11.2 12.8V8.00001C11.2 7.78784 11.2843 7.58436 11.4343 7.43433C11.5844 7.2843 11.7878 7.20001 12 7.20001Z" fill="#414952"></path><path d="M6.8 14H9.2C9.41217 14 9.61566 14.0843 9.76569 14.2343C9.91571 14.3843 10 14.5878 10 14.8V16H6.8C6.58783 16 6.38434 15.9157 6.23431 15.7657C6.08429 15.6157 6 15.4122 6 15.2V14.8C6 14.5878 6.08429 14.3843 6.23431 14.2343C6.38434 14.0843 6.58783 14 6.8 14Z" fill="#8C9099"></path></svg>
                                </div>
                                <div class="btnGameName">Suporte ao Vivo</div>
                            </div>
                        </a>
												
                        </a>
						                        <a href="user/referrals.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                   <svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.1787 9.63885L10.0651 10.062L9.64343 10.1738L7.47002 10.7646L6.30222 16.6091C6.43671 16.7378 6.59606 16.8387 6.77085 16.9058C6.94564 16.9728 7.1323 17.0047 7.31982 16.9995C7.50733 16.9942 7.69187 16.9521 7.86254 16.8754C8.03321 16.7988 8.18652 16.6892 8.31343 16.5532L16.561 8.30548C16.8332 8.04213 16.9905 7.68478 16.9996 7.30918C17.0087 6.93358 16.8688 6.56926 16.6097 6.29346L10.7707 7.45915L10.1787 9.63885Z" fill="#414952"></path><path d="M9.7004 1.43115L1.43658 9.67885C1.16573 9.94455 1.00948 10.3029 1.00042 10.6792C0.991353 11.0556 1.13017 11.4208 1.38792 11.6989L9.49765 9.48723L11.6954 1.38324C11.5612 1.25742 11.4032 1.15886 11.2303 1.09317C11.0574 1.02748 10.8731 0.995965 10.6878 1.00041C10.5026 1.00486 10.32 1.04519 10.1506 1.1191C9.98117 1.193 9.82819 1.29904 9.7004 1.43115Z" fill="#8C9099"></path><path d="M1.18518 1.39122L6.26187 1.38324" stroke="#8C9099" stroke-miterlimit="10" stroke-linecap="round"></path><path d="M1.18518 3.7865H4.42907" stroke="#8C9099" stroke-miterlimit="10" stroke-linecap="round"></path><path d="M1.18518 6.18176H1.99615" stroke="#8C9099" stroke-miterlimit="10" stroke-linecap="round"></path><path d="M6.52948 11.1639L2.07724 12.3775L5.58065 15.8906L6.52948 11.1639Z" fill="#8C9099"></path><path d="M15.8879 5.57496L12.3845 2.06989L11.1681 6.52508L15.8879 5.57496Z" fill="#8C9099"></path></svg>
							   </div>
                                <div class="btnGameName">Indique um amigo</div>
                            </div>
                        </a>

                        <a href="recompensas.php" class="link-menu">
                            <div class="btnGame">
                                <div class="btnGameIcons">
                                    <svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0)"><path d="M17.5 10.93H2.5L5 8.5H15L17.5 10.93Z" fill="#414952"></path><path d="M19.91 14C19.7632 13.4745 19.4478 13.0117 19.0124 12.6829C18.577 12.3541 18.0456 12.1774 17.5 12.18H2.49997C1.95434 12.1774 1.42297 12.3541 0.987552 12.6829C0.552134 13.0117 0.236776 13.4745 0.0899658 14H19.91Z" fill="#8C9099"></path><path d="M20 15.1799H0V16.9999H20V15.1799Z" fill="#414952"></path><path d="M13.75 -6.53708e-05H6.25C5.44103 -0.011971 4.63765 0.135599 3.88572 0.434218C3.13379 0.732836 2.44806 1.17665 1.86767 1.74032C1.28729 2.30399 0.823627 2.97647 0.503169 3.71935C0.182711 4.46223 0.011733 5.26097 0 6.06993H20C19.9883 5.26097 19.8173 4.46223 19.4968 3.71935C19.1764 2.97647 18.7127 2.30399 18.1323 1.74032C17.5519 1.17665 16.8662 0.732836 16.1143 0.434218C15.3624 0.135599 14.559 -0.011971 13.75 -6.53708e-05ZM4 3.65993C3.31 4.33993 2.45 4.59994 2.1 4.25993C1.75 3.91993 2 3.07993 2.69 2.40993C3.38 1.73993 4.23 1.46993 4.59 1.81993C4.95 2.16993 4.67 2.99993 4 3.65993Z" fill="#8C9099"></path></g><defs><clipPath id="clip0"><rect width="20" height="17" fill="white"></rect></clipPath></defs></svg>
                                </div>
                                <div class="btnGameName">Resgatar bônus</div>
                            </div>
                        </a>
                    
                       
                    </div>
             
                </div>



                <div class="footerMenu">
				
				
					
					
					
					
					
                </div>
            </div>
        </div>
		
    </nav>
    <div class="chat hidden">
        <div class="chat-header">
            <div class="text">
                <span style="font-size:80%; display: flex;flex-direction: row;"><svg width="10px" style="margin-right: 5px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 122.88 122.88" xml:space="preserve"><style type="text/css">.st0{fill-rule:evenodd;clip-rule:evenodd;fill:#1fff20;}</style><g><path class="st0" d="M61.44,0c33.93,0,61.44,27.51,61.44,61.44c0,33.93-27.51,61.44-61.44,61.44C27.51,122.88,0,95.37,0,61.44 C0,27.51,27.51,0,61.44,0L61.44,0z"></path></g></svg> Online: <span class="players-online" style="margin-left: 3px">517</span></span> <svg class="chat-toggle-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" id="Layer_1" style="enable-background:new 0 0 512 512;" version="1.1" viewBox="0 0 512 512" width="20px" xml:space="preserve"><path d="M443.6,387.1L312.4,255.4l131.5-130c5.4-5.4,5.4-14.2,0-19.6l-37.4-37.6c-2.6-2.6-6.1-4-9.8-4c-3.7,0-7.2,1.5-9.8,4  L256,197.8L124.9,68.3c-2.6-2.6-6.1-4-9.8-4c-3.7,0-7.2,1.5-9.8,4L68,105.9c-5.4,5.4-5.4,14.2,0,19.6l131.5,130L68.4,387.1  c-2.6,2.6-4.1,6.1-4.1,9.8c0,3.7,1.4,7.2,4.1,9.8l37.4,37.6c2.7,2.7,6.2,4.1,9.8,4.1c3.5,0,7.1-1.3,9.8-4.1L256,313.1l130.7,131.1  c2.7,2.7,6.2,4.1,9.8,4.1c3.5,0,7.1-1.3,9.8-4.1l37.4-37.6c2.6-2.6,4.1-6.1,4.1-9.8C447.7,393.2,446.2,389.7,443.6,387.1z"></path></svg>
            </div>
        </div>
        <div class="chat-messages">
        </div> 
                <div class="send-area">
                        <div class="input-area">
                    <input type="text" class="chat-input" placeholder="Digite sua mensagem" maxlength="75" pattern="[A-Za-z0-9_./!?,$+-= ]{1,75}" required>
                    <div class="emots-button">
                        <img src="img/misc/emots-button.png">
                    </div>
                    <div class="emots"></div>
                </div>
                <img src="img/misc/chat-send-img.png" class="send-message">
                </div>
                <div class="footer">
        <div class="data">
            <div class="social">
            <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
            </div>

            <a href="#" style="color: white !important" target="_blank"><div class="copyright copyright0">&copy; #</div></a>
            
            <div class="legal">
            <a href="/terms" target="_blank">TERMOS</a>
            <a class="chat-info" style="cursor: pointer;">REGRAS</a>
            </div>

        </div>


        </div>
    </div>
    
	<div class="main-wrapper">
        <main>
            


  <html lang="pt-BR" style="background-color: #212a31;" class="dark-mode">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta data-n-head="1" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes">
  <meta data-n-head="1" name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">


   
    
    <style type="text/css">
		
		 #__layout::-webkit-scrollbar,
        ::-webkit-scrollbar {
            display: none!important;
            width: 0!important
        }
		
      .small,
      small {
        font-size: .875em;
        font-weight: 400
      }

      .mark,
      mark {
        padding: .2em;
        background-color: #fcf8e3
      }

      .list-inline,
      .list-unstyled {
        padding-left: 0;
        list-style: none
      }

      .list-inline-item {
        display: inline-block
      }

      .list-inline-item:not(:last-child) {
        margin-right: .5rem
      }

      .initialism {
        font-size: 90%;
        text-transform: uppercase
      }

      .blockquote {
        margin-bottom: 1rem;
        font-size: 1.25rem
      }

      .blockquote-footer {
        display: block;
        font-size: .875em;
        color: #b8c2cc
      }

      .blockquote-footer:before {
        content: "—&nbsp;"
      }

      .img-fluid,
      .img-thumbnail {
        max-width: 100%;
        height: auto
      }

      .img-thumbnail {
        padding: .25rem;
        background-color: #fdffff;
        border: 1px solid #dae1e7;
        border-radius: .25rem
      }

      .figure {
        display: inline-block
      }

      .figure-img {
        margin-bottom: .5rem;
        line-height: 1
      }

      .figure-caption {
        font-size: 90%;
        color: #b8c2cc
      }

      code {
        font-size: 87.5%;
        color: #e83e8c;
        word-wrap: break-word
      }

      a>code {
        color: inherit
      }

      kbd {
        padding: .2rem .4rem;
        font-size: 87.5%;
        color: #fdffff;
        background-color: #2a2e30;
        border-radius: .2rem
      }

      kbd kbd {
        padding: 0;
        font-size: 100%;
        font-weight: 700
      }

      pre {
        display: block;
        font-size: 87.5%;
        color: #2a2e30
      }

      pre code {
        font-size: inherit;
        color: inherit;
        word-break: normal
      }

      .pre-scrollable {
        max-height: 340px;
        overflow-y: scroll
      }

      .container,
      .container-fluid,
      .container-lg,
      .container-md,
      .container-sm,
      .container-xl {
        width: 100%;
        padding-right: 5.5%;
        padding-left: 5.5%;
        margin-right: auto;
        margin-left: auto
      }

      @media(min-width:576px) {

        .container,
        .container-sm {
          max-width: 540px
        }
      }

      @media(min-width:768px) {

        .container,
        .container-md,
        .container-sm {
          max-width: 720px
        }
      }

      @media(min-width:992px) {

        .container,
        .container-lg,
        .container-md,
        .container-sm {
          max-width: 960px
        }
      }

      @media(min-width:1200px) {

        .container,
        .container-lg,
        .container-md,
        .container-sm,
        .container-xl {
          max-width: 1140px
        }
      }

      .row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -15px;
        margin-left: -15px
      }

      .no-gutters {
        margin-right: 0;
        margin-left: 0
      }

      .no-gutters>.col,
      .no-gutters>[class*=col-] {
        padding-right: 0;
        padding-left: 0
      }

      .col,
      .col-1,
      .col-2,
      .col-3,
      .col-4,
      .col-5,
      .col-6,
      .col-7,
      .col-8,
      .col-9,
      .col-10,
      .col-11,
      .col-12,
      .col-auto,
      .col-lg,
      .col-lg-1,
      .col-lg-2,
      .col-lg-3,
      .col-lg-4,
      .col-lg-5,
      .col-lg-6,
      .col-lg-7,
      .col-lg-8,
      .col-lg-9,
      .col-lg-10,
      .col-lg-11,
      .col-lg-12,
      .col-lg-auto,
      .col-md,
      .col-md-1,
      .col-md-2,
      .col-md-3,
      .col-md-4,
      .col-md-5,
      .col-md-6,
      .col-md-7,
      .col-md-8,
      .col-md-9,
      .col-md-10,
      .col-md-11,
      .col-md-12,
      .col-md-auto,
      .col-sm,
      .col-sm-1,
      .col-sm-2,
      .col-sm-3,
      .col-sm-4,
      .col-sm-5,
      .col-sm-6,
      .col-sm-7,
      .col-sm-8,
      .col-sm-9,
      .col-sm-10,
      .col-sm-11,
      .col-sm-12,
      .col-sm-auto,
      .col-xl,
      .col-xl-1,
      .col-xl-2,
      .col-xl-3,
      .col-xl-4,
      .col-xl-5,
      .col-xl-6,
      .col-xl-7,
      .col-xl-8,
      .col-xl-9,
      .col-xl-10,
      .col-xl-11,
      .col-xl-12,
      .col-xl-auto {
        position: relative;
        width: 100%;
        padding-right: 15px;
        padding-left: 15px
      }

      .col {
        flex-basis: 0;
        flex-grow: 1;
        max-width: 100%
      }

      .row-cols-1>* {
        flex: 0 0 100%;
        max-width: 100%
      }

      .row-cols-2>* {
        flex: 0 0 50%;
        max-width: 50%
      }

      .row-cols-3>* {
        flex: 0 0 33.3333333333%;
        max-width: 33.3333333333%
      }

      .row-cols-4>* {
        flex: 0 0 25%;
        max-width: 25%
      }

      .row-cols-5>* {
        flex: 0 0 20%;
        max-width: 20%
      }

      .row-cols-6>* {
        flex: 0 0 16.6666666667%;
        max-width: 16.6666666667%
      }

      .col-auto {
        flex: 0 0 auto;
        width: auto;
        max-width: 100%
      }

      .col-1 {
        flex: 0 0 8.33333333%;
        max-width: 8.33333333%
      }

      .col-2 {
        flex: 0 0 16.66666667%;
        max-width: 16.66666667%
      }

      .col-3 {
        flex: 0 0 25%;
        max-width: 25%
      }

      .col-4 {
        flex: 0 0 33.33333333%;
        max-width: 33.33333333%
      }

      .col-5 {
        flex: 0 0 41.66666667%;
        max-width: 41.66666667%
      }

      .col-6 {
        flex: 0 0 50%;
        max-width: 50%
      }

      .col-7 {
        flex: 0 0 58.33333333%;
        max-width: 58.33333333%
      }

      .col-8 {
        flex: 0 0 66.66666667%;
        max-width: 66.66666667%
      }

      .col-9 {
        flex: 0 0 75%;
        max-width: 75%
      }

      .col-10 {
        flex: 0 0 83.33333333%;
        max-width: 83.33333333%
      }

      .col-11 {
        flex: 0 0 91.66666667%;
        max-width: 91.66666667%
      }

      .col-12 {
        flex: 0 0 100%;
        max-width: 100%
      }

      .order-first {
        order: -1
      }

      .order-last {
        order: 13
      }

      .order-0 {
        order: 0
      }

      .order-1 {
        order: 1
      }

      .order-2 {
        order: 2
      }

      .order-3 {
        order: 3
      }

      .order-4 {
        order: 4
      }

      .order-5 {
        order: 5
      }

      .order-6 {
        order: 6
      }

      .order-7 {
        order: 7
      }

      .order-8 {
        order: 8
      }

      .order-9 {
        order: 9
      }

      .order-10 {
        order: 10
      }

      .order-11 {
        order: 11
      }

      .order-12 {
        order: 12
      }

      .offset-1 {
        margin-left: 8.33333333%
      }

      .offset-2 {
        margin-left: 16.66666667%
      }

      .offset-3 {
        margin-left: 25%
      }

      .offset-4 {
        margin-left: 33.33333333%
      }

      .offset-5 {
        margin-left: 41.66666667%
      }

      .offset-6 {
        margin-left: 50%
      }

      .offset-7 {
        margin-left: 58.33333333%
      }

      .offset-8 {
        margin-left: 66.66666667%
      }

      .offset-9 {
        margin-left: 75%
      }

      .offset-10 {
        margin-left: 83.33333333%
      }

      .offset-11 {
        margin-left: 91.66666667%
      }

      @media(min-width:576px) {
        .col-sm {
          flex-basis: 0;
          flex-grow: 1;
          max-width: 100%
        }

        .row-cols-sm-1>* {
          flex: 0 0 100%;
          max-width: 100%
        }

        .row-cols-sm-2>* {
          flex: 0 0 50%;
          max-width: 50%
        }

        .row-cols-sm-3>* {
          flex: 0 0 33.3333333333%;
          max-width: 33.3333333333%
        }

        .row-cols-sm-4>* {
          flex: 0 0 25%;
          max-width: 25%
        }

        .row-cols-sm-5>* {
          flex: 0 0 20%;
          max-width: 20%
        }

        .row-cols-sm-6>* {
          flex: 0 0 16.6666666667%;
          max-width: 16.6666666667%
        }

        .col-sm-auto {
          flex: 0 0 auto;
          width: auto;
          max-width: 100%
        }

        .col-sm-1 {
          flex: 0 0 8.33333333%;
          max-width: 8.33333333%
        }

        .col-sm-2 {
          flex: 0 0 16.66666667%;
          max-width: 16.66666667%
        }

        .col-sm-3 {
          flex: 0 0 25%;
          max-width: 25%
        }

        .col-sm-4 {
          flex: 0 0 33.33333333%;
          max-width: 33.33333333%
        }

        .col-sm-5 {
          flex: 0 0 41.66666667%;
          max-width: 41.66666667%
        }

        .col-sm-6 {
          flex: 0 0 50%;
          max-width: 50%
        }

        .col-sm-7 {
          flex: 0 0 58.33333333%;
          max-width: 58.33333333%
        }

        .col-sm-8 {
          flex: 0 0 66.66666667%;
          max-width: 66.66666667%
        }

        .col-sm-9 {
          flex: 0 0 75%;
          max-width: 75%
        }

        .col-sm-10 {
          flex: 0 0 83.33333333%;
          max-width: 83.33333333%
        }

        .col-sm-11 {
          flex: 0 0 91.66666667%;
          max-width: 91.66666667%
        }

        .col-sm-12 {
          flex: 0 0 100%;
          max-width: 100%
        }

        .order-sm-first {
          order: -1
        }

        .order-sm-last {
          order: 13
        }

        .order-sm-0 {
          order: 0
        }

        .order-sm-1 {
          order: 1
        }

        .order-sm-2 {
          order: 2
        }

        .order-sm-3 {
          order: 3
        }

        .order-sm-4 {
          order: 4
        }

        .order-sm-5 {
          order: 5
        }

        .order-sm-6 {
          order: 6
        }

        .order-sm-7 {
          order: 7
        }

        .order-sm-8 {
          order: 8
        }

        .order-sm-9 {
          order: 9
        }

        .order-sm-10 {
          order: 10
        }

        .order-sm-11 {
          order: 11
        }

        .order-sm-12 {
          order: 12
        }

        .offset-sm-0 {
          margin-left: 0
        }

        .offset-sm-1 {
          margin-left: 8.33333333%
        }

        .offset-sm-2 {
          margin-left: 16.66666667%
        }

        .offset-sm-3 {
          margin-left: 25%
        }

        .offset-sm-4 {
          margin-left: 33.33333333%
        }

        .offset-sm-5 {
          margin-left: 41.66666667%
        }

        .offset-sm-6 {
          margin-left: 50%
        }

        .offset-sm-7 {
          margin-left: 58.33333333%
        }

        .offset-sm-8 {
          margin-left: 66.66666667%
        }

        .offset-sm-9 {
          margin-left: 75%
        }

        .offset-sm-10 {
          margin-left: 83.33333333%
        }

        .offset-sm-11 {
          margin-left: 91.66666667%
        }
      }

      @media(min-width:768px) {
        .col-md {
          flex-basis: 0;
          flex-grow: 1;
          max-width: 100%
        }

        .row-cols-md-1>* {
          flex: 0 0 100%;
          max-width: 100%
        }

        .row-cols-md-2>* {
          flex: 0 0 50%;
          max-width: 50%
        }

        .row-cols-md-3>* {
          flex: 0 0 33.3333333333%;
          max-width: 33.3333333333%
        }

        .row-cols-md-4>* {
          flex: 0 0 25%;
          max-width: 25%
        }

        .row-cols-md-5>* {
          flex: 0 0 20%;
          max-width: 20%
        }

        .row-cols-md-6>* {
          flex: 0 0 16.6666666667%;
          max-width: 16.6666666667%
        }

        .col-md-auto {
          flex: 0 0 auto;
          width: auto;
          max-width: 100%
        }

        .col-md-1 {
          flex: 0 0 8.33333333%;
          max-width: 8.33333333%
        }

        .col-md-2 {
          flex: 0 0 16.66666667%;
          max-width: 16.66666667%
        }

        .col-md-3 {
          flex: 0 0 25%;
          max-width: 25%
        }

        .col-md-4 {
          flex: 0 0 33.33333333%;
          max-width: 33.33333333%
        }

        .col-md-5 {
          flex: 0 0 41.66666667%;
          max-width: 41.66666667%
        }

        .col-md-6 {
          flex: 0 0 50%;
          max-width: 50%
        }

        .col-md-7 {
          flex: 0 0 58.33333333%;
          max-width: 58.33333333%
        }

        .col-md-8 {
          flex: 0 0 66.66666667%;
          max-width: 66.66666667%
        }

        .col-md-9 {
          flex: 0 0 75%;
          max-width: 75%
        }

        .col-md-10 {
          flex: 0 0 83.33333333%;
          max-width: 83.33333333%
        }

        .col-md-11 {
          flex: 0 0 91.66666667%;
          max-width: 91.66666667%
        }

        .col-md-12 {
          flex: 0 0 100%;
          max-width: 100%
        }

        .order-md-first {
          order: -1
        }

        .order-md-last {
          order: 13
        }

        .order-md-0 {
          order: 0
        }

        .order-md-1 {
          order: 1
        }

        .order-md-2 {
          order: 2
        }

        .order-md-3 {
          order: 3
        }

        .order-md-4 {
          order: 4
        }

        .order-md-5 {
          order: 5
        }

        .order-md-6 {
          order: 6
        }

        .order-md-7 {
          order: 7
        }

        .order-md-8 {
          order: 8
        }

        .order-md-9 {
          order: 9
        }

        .order-md-10 {
          order: 10
        }

        .order-md-11 {
          order: 11
        }

        .order-md-12 {
          order: 12
        }

        .offset-md-0 {
          margin-left: 0
        }

        .offset-md-1 {
          margin-left: 8.33333333%
        }

        .offset-md-2 {
          margin-left: 16.66666667%
        }

        .offset-md-3 {
          margin-left: 25%
        }

        .offset-md-4 {
          margin-left: 33.33333333%
        }

        .offset-md-5 {
          margin-left: 41.66666667%
        }

        .offset-md-6 {
          margin-left: 50%
        }

        .offset-md-7 {
          margin-left: 58.33333333%
        }

        .offset-md-8 {
          margin-left: 66.66666667%
        }

        .offset-md-9 {
          margin-left: 75%
        }

        .offset-md-10 {
          margin-left: 83.33333333%
        }

        .offset-md-11 {
          margin-left: 91.66666667%
        }
      }

      @media(min-width:992px) {
        .col-lg {
          flex-basis: 0;
          flex-grow: 1;
          max-width: 100%
        }

        .row-cols-lg-1>* {
          flex: 0 0 100%;
          max-width: 100%
        }

        .row-cols-lg-2>* {
          flex: 0 0 50%;
          max-width: 50%
        }

        .row-cols-lg-3>* {
          flex: 0 0 33.3333333333%;
          max-width: 33.3333333333%
        }

        .row-cols-lg-4>* {
          flex: 0 0 25%;
          max-width: 25%
        }

        .row-cols-lg-5>* {
          flex: 0 0 20%;
          max-width: 20%
        }

        .row-cols-lg-6>* {
          flex: 0 0 16.6666666667%;
          max-width: 16.6666666667%
        }

        .col-lg-auto {
          flex: 0 0 auto;
          width: auto;
          max-width: 100%
        }

        .col-lg-1 {
          flex: 0 0 8.33333333%;
          max-width: 8.33333333%
        }

        .col-lg-2 {
          flex: 0 0 16.66666667%;
          max-width: 16.66666667%
        }

        .col-lg-3 {
          flex: 0 0 25%;
          max-width: 25%
        }

        .col-lg-4 {
          flex: 0 0 33.33333333%;
          max-width: 33.33333333%
        }

        .col-lg-5 {
          flex: 0 0 41.66666667%;
          max-width: 41.66666667%
        }

        .col-lg-6 {
          flex: 0 0 50%;
          max-width: 50%
        }

        .col-lg-7 {
          flex: 0 0 58.33333333%;
          max-width: 58.33333333%
        }

        .col-lg-8 {
          flex: 0 0 66.66666667%;
          max-width: 66.66666667%
        }

        .col-lg-9 {
          flex: 0 0 75%;
          max-width: 75%
        }

        .col-lg-10 {
          flex: 0 0 83.33333333%;
          max-width: 83.33333333%
        }

        .col-lg-11 {
          flex: 0 0 91.66666667%;
          max-width: 91.66666667%
        }

        .col-lg-12 {
          flex: 0 0 100%;
          max-width: 100%
        }

        .order-lg-first {
          order: -1
        }

        .order-lg-last {
          order: 13
        }

        .order-lg-0 {
          order: 0
        }

        .order-lg-1 {
          order: 1
        }

        .order-lg-2 {
          order: 2
        }

        .order-lg-3 {
          order: 3
        }

        .order-lg-4 {
          order: 4
        }

        .order-lg-5 {
          order: 5
        }

        .order-lg-6 {
          order: 6
        }

        .order-lg-7 {
          order: 7
        }

        .order-lg-8 {
          order: 8
        }

        .order-lg-9 {
          order: 9
        }

        .order-lg-10 {
          order: 10
        }

        .order-lg-11 {
          order: 11
        }

        .order-lg-12 {
          order: 12
        }

        .offset-lg-0 {
          margin-left: 0
        }

        .offset-lg-1 {
          margin-left: 8.33333333%
        }

        .offset-lg-2 {
          margin-left: 16.66666667%
        }

        .offset-lg-3 {
          margin-left: 25%
        }

        .offset-lg-4 {
          margin-left: 33.33333333%
        }

        .offset-lg-5 {
          margin-left: 41.66666667%
        }

        .offset-lg-6 {
          margin-left: 50%
        }

        .offset-lg-7 {
          margin-left: 58.33333333%
        }

        .offset-lg-8 {
          margin-left: 66.66666667%
        }

        .offset-lg-9 {
          margin-left: 75%
        }

        .offset-lg-10 {
          margin-left: 83.33333333%
        }

        .offset-lg-11 {
          margin-left: 91.66666667%
        }
      }

      @media(min-width:1200px) {
        .col-xl {
          flex-basis: 0;
          flex-grow: 1;
          max-width: 100%
        }

        .row-cols-xl-1>* {
          flex: 0 0 100%;
          max-width: 100%
        }

        .row-cols-xl-2>* {
          flex: 0 0 50%;
          max-width: 50%
        }

        .row-cols-xl-3>* {
          flex: 0 0 33.3333333333%;
          max-width: 33.3333333333%
        }

        .row-cols-xl-4>* {
          flex: 0 0 25%;
          max-width: 25%
        }

        .row-cols-xl-5>* {
          flex: 0 0 20%;
          max-width: 20%
        }

        .row-cols-xl-6>* {
          flex: 0 0 16.6666666667%;
          max-width: 16.6666666667%
        }

        .col-xl-auto {
          flex: 0 0 auto;
          width: auto;
          max-width: 100%
        }

        .col-xl-1 {
          flex: 0 0 8.33333333%;
          max-width: 8.33333333%
        }

        .col-xl-2 {
          flex: 0 0 16.66666667%;
          max-width: 16.66666667%
        }

        .col-xl-3 {
          flex: 0 0 25%;
          max-width: 25%
        }

        .col-xl-4 {
          flex: 0 0 33.33333333%;
          max-width: 33.33333333%
        }

        .col-xl-5 {
          flex: 0 0 41.66666667%;
          max-width: 41.66666667%
        }

        .col-xl-6 {
          flex: 0 0 50%;
          max-width: 50%
        }

        .col-xl-7 {
          flex: 0 0 58.33333333%;
          max-width: 58.33333333%
        }

        .col-xl-8 {
          flex: 0 0 66.66666667%;
          max-width: 66.66666667%
        }

        .col-xl-9 {
          flex: 0 0 75%;
          max-width: 75%
        }

        .col-xl-10 {
          flex: 0 0 83.33333333%;
          max-width: 83.33333333%
        }

        .col-xl-11 {
          flex: 0 0 91.66666667%;
          max-width: 91.66666667%
        }

        .col-xl-12 {
          flex: 0 0 100%;
          max-width: 100%
        }

        .order-xl-first {
          order: -1
        }

        .order-xl-last {
          order: 13
        }

        .order-xl-0 {
          order: 0
        }

        .order-xl-1 {
          order: 1
        }

        .order-xl-2 {
          order: 2
        }

        .order-xl-3 {
          order: 3
        }

        .order-xl-4 {
          order: 4
        }

        .order-xl-5 {
          order: 5
        }

        .order-xl-6 {
          order: 6
        }

        .order-xl-7 {
          order: 7
        }

        .order-xl-8 {
          order: 8
        }

        .order-xl-9 {
          order: 9
        }

        .order-xl-10 {
          order: 10
        }

        .order-xl-11 {
          order: 11
        }

        .order-xl-12 {
          order: 12
        }

        .offset-xl-0 {
          margin-left: 0
        }

        .offset-xl-1 {
          margin-left: 8.33333333%
        }

        .offset-xl-2 {
          margin-left: 16.66666667%
        }

        .offset-xl-3 {
          margin-left: 25%
        }

        .offset-xl-4 {
          margin-left: 33.33333333%
        }

        .offset-xl-5 {
          margin-left: 41.66666667%
        }

        .offset-xl-6 {
          margin-left: 50%
        }

        .offset-xl-7 {
          margin-left: 58.33333333%
        }

        .offset-xl-8 {
          margin-left: 66.66666667%
        }

        .offset-xl-9 {
          margin-left: 75%
        }

        .offset-xl-10 {
          margin-left: 83.33333333%
        }

        .offset-xl-11 {
          margin-left: 91.66666667%
        }
      }

      .table {
        width: 100%;
        margin-bottom: 1rem;
        color: var(--color-primary)
      }

      .table td,
      .table th {
        padding: .75rem;
        vertical-align: top;
        border-top: 1px solid #dae1e7
      }

      .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dae1e7
      }

      .table tbody+tbody {
        border-top: 2px solid #dae1e7
      }

      .table-sm td,
      .table-sm th {
        padding: .3rem
      }

      .table-bordered,
      .table-bordered td,
      .table-bordered th {
        border: 1px solid #dae1e7
      }

      .table-bordered thead td,
      .table-bordered thead th {
        border-bottom-width: 2px
      }

      .table-borderless tbody+tbody,
      .table-borderless td,
      .table-borderless th,
      .table-borderless thead th {
        border: 0
      }

      .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(34, 41, 47, .05)
      }

      .table-hover tbody tr:hover {
        color: var(--color-primary);
        background-color: rgba(34, 41, 47, .075)
      }

      .table-primary,
      .table-primary>td,
      .table-primary>th {
        background-color: #feffff
      }

      .table-primary tbody+tbody,
      .table-primary td,
      .table-primary th,
      .table-primary thead th {
        border-color: #feffff
      }

      .table-hover .table-primary:hover,
      .table-hover .table-primary:hover>td,
      .table-hover .table-primary:hover>th {
        background-color: #e5ffff
      }

      .table-secondary,
      .table-secondary>td,
      .table-secondary>th {
        background-color: #feffff
      }

      .table-secondary tbody+tbody,
      .table-secondary td,
      .table-secondary th,
      .table-secondary thead th {
        border-color: #feffff
      }

      .table-hover .table-secondary:hover,
      .table-hover .table-secondary:hover>td,
      .table-hover .table-secondary:hover>th {
        background-color: #e5ffff
      }

      .table-success,
      .table-success>td,
      .table-success>th {
        background-color: #baf3d3
      }

      .table-success tbody+tbody,
      .table-success td,
      .table-success th,
      .table-success thead th {
        border-color: #80e9ae
      }

      .table-hover .table-success:hover,
      .table-hover .table-success:hover>td,
      .table-hover .table-success:hover>th {
        background-color: #a4efc5
      }

      .table-info,
      .table-info>td,
      .table-info>th {
        background-color: #b6f2f9
      }

      .table-info tbody+tbody,
      .table-info td,
      .table-info th,
      .table-info thead th {
        border-color: #79e6f3
      }

      .table-hover .table-info:hover,
      .table-hover .table-info:hover>td,
      .table-hover .table-info:hover>th {
        background-color: #9eeef7
      }

      .table-warning,
      .table-warning>td,
      .table-warning>th {
        background-color: #fee4ca
      }

      .table-warning tbody+tbody,
      .table-warning td,
      .table-warning th,
      .table-warning thead th {
        border-color: #fecd9d
      }

      .table-hover .table-warning:hover,
      .table-hover .table-warning:hover>td,
      .table-hover .table-warning:hover>th {
        background-color: #fed7b1
      }

      .table-danger,
      .table-danger>td,
      .table-danger>th {
        background-color: #f6cbc4
      }

      .table-danger tbody+tbody,
      .table-danger td,
      .table-danger th,
      .table-danger thead th {
        border-color: #f19f92
      }

      .table-hover .table-danger:hover,
      .table-hover .table-danger:hover>td,
      .table-hover .table-danger:hover>th {
        background-color: #f3b8ae
      }

      .table-light,
      .table-light>td,
      .table-light>th {
        background-color: #fbfcfc
      }

      .table-light tbody+tbody,
      .table-light td,
      .table-light th,
      .table-light thead th {
        border-color: #f9fafa
      }

      .table-hover .table-light:hover,
      .table-hover .table-light:hover>td,
      .table-hover .table-light:hover>th {
        background-color: #ecf1f1
      }

      .table-dark,
      .table-dark>td,
      .table-dark>th {
        background-color: #eceded
      }

      .table-dark tbody+tbody,
      .table-dark td,
      .table-dark th,
      .table-dark thead th {
        border-color: #dedddd
      }

      .table-hover .table-dark:hover,
      .table-hover .table-dark:hover>td,
      .table-hover .table-dark:hover>th {
        background-color: #dfe1e1
      }

      .table-active,
      .table-active>td,
      .table-active>th {
        background-color: rgba(34, 41, 47, .075)
      }

      .table-hover .table-active:hover,
      .table-hover .table-active:hover>td,
      .table-hover .table-active:hover>th {
        background-color: rgba(23, 28, 32, .075)
      }

      .table .thead-dark th {
        color: #fdffff;
        background-color: #1e1e1e;
        border-color: #313131
      }

      .table .thead-light th {
        color: #4e5154;
        background-color: #ededed;
        border-color: #dae1e7
      }

      .table-dark {
        color: #fdffff;
        background-color: #1e1e1e
      }

      .table-dark td,
      .table-dark th,
      .table-dark thead th {
        border-color: #313131
      }

      .table-dark.table-bordered {
        border: 0
      }

      .table-dark.table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(253, 255, 255, .05)
      }

      .table-dark.table-hover tbody tr:hover {
        color: #fdffff;
        background-color: rgba(253, 255, 255, .075)
      }

      @media(max-width:575.98px) {
        

      }

      @media(max-width:767.98px) {
      }
      @media(max-width:991.98px) {
      }
      @media(max-width:1199.98px) {
       

      @media(prefers-reduced-motion:reduce) {
        .form-control {
          transition: none
        }
      }

      .form-control::-ms-expand {
        background-color: transparent;
        border: 0
      }

      .form-control:focus {
        color: #4e5154;
        background-color: #fdffff;
        border-color: #fff;
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 100%, .25)
      }

      .form-control::-moz-placeholder {
        color: #b8c2cc;
        opacity: 1
      }

      .form-control::placeholder {
        color: #b8c2cc;
        opacity: 1
      }

      .form-control:disabled,
      .form-control[readonly] {
        background-color: #ededed;
        opacity: 1
      }

      input[type=date].form-control,
      input[type=datetime-local].form-control,
      input[type=month].form-control,
      input[type=time].form-control {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none
      }

      select.form-control:-moz-focusring {
        color: transparent;
        text-shadow: 0 0 0 #4e5154
      }

      select.form-control:focus::-ms-value {
        color: #4e5154;
        background-color: #fdffff
      }

      .form-control-file,
      .form-control-range {
        display: block;
        width: 100%
      }

      .col-form-label {
        padding-top: calc(.375rem + 1px);
        padding-bottom: calc(.375rem + 1px);
        margin-bottom: 0;
        font-size: inherit;
        line-height: 1.5
      }

      .col-form-label-lg {
        padding-top: calc(.5rem + 1px);
        padding-bottom: calc(.5rem + 1px);
        font-size: 1.25rem;
        line-height: 1.5
      }

      .col-form-label-sm {
        padding-top: calc(.25rem + 1px);
        padding-bottom: calc(.25rem + 1px);
        font-size: .875rem;
        line-height: 1.5
      }

      .form-control-plaintext {
        display: block;
        width: 100%;
        padding: .375rem 0;
        margin-bottom: 0;
        font-size: 1rem;
        line-height: 1.5;
        color: #2a2e30;
        background-color: transparent;
        border: solid transparent;
        border-width: 1px 0
      }

      .form-control-plaintext.form-control-lg,
      .form-control-plaintext.form-control-sm {
        padding-right: 0;
        padding-left: 0
      }

      .form-control-sm {
        height: calc(1.5em + .5rem + 2px);
        padding: .25rem .5rem;
        font-size: .875rem;
        line-height: 1.5;
        border-radius: .2rem
      }

      .form-control-lg {
        height: calc(1.5em + 1rem + 2px);
        padding: .5rem 1rem;
        font-size: 1.25rem;
        line-height: 1.5;
        border-radius: .3rem
      }

      select.form-control[multiple],
      select.form-control[size],
      textarea.form-control {
        height: auto
      }

      .form-group {
        margin-bottom: 1rem
      }

      .form-text {
        display: block;
        margin-top: .25rem
      }

      .form-row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -5px;
        margin-left: -5px
      }

      .form-row>.col,
      .form-row>[class*=col-] {
        padding-right: 5px;
        padding-left: 5px
      }

      .form-check {
        position: relative;
        display: block;
        padding-left: 1.25rem
      }

      .form-check-input {
        position: absolute;
        margin-top: .3rem;
        margin-left: -1.25rem
      }

      .form-check-input:disabled~.form-check-label,
      .form-check-input[disabled]~.form-check-label {
        color: #b8c2cc
      }

      .form-check-label {
        margin-bottom: 0
      }

      .form-check-inline {
        display: inline-flex;
        align-items: center;
        padding-left: 0;
        margin-right: .75rem
      }

      .form-check-inline .form-check-input {
        position: static;
        margin-top: 0;
        margin-right: .3125rem;
        margin-left: 0
      }

      .valid-feedback {
        display: none;
        width: 100%;
        margin-top: .25rem;
        font-size: .875em;
        color: #0cd463
      }

      .valid-tooltip {
        position: absolute;
        top: 100%;
        left: 0;
        z-index: 5;
        display: none;
        max-width: 100%;
        padding: .25rem .5rem;
        margin-top: .1rem;
        font-size: .875rem;
        line-height: 1.5;
        color: #fdffff;
        background-color: rgba(12, 212, 99, .9);
        border-radius: .25rem
      }

      .form-row>.col>.valid-tooltip,
      .form-row>[class*=col-]>.valid-tooltip {
        left: 5px
      }

      .is-valid~.valid-feedback,
      .is-valid~.valid-tooltip,
      .was-validated :valid~.valid-feedback,
      .was-validated :valid~.valid-tooltip {
        display: block
      }

      .form-control.is-valid,
      .was-validated .form-control:valid {
        border-color: #0cd463;
        padding-right: calc(1.5em + .75rem) !important;
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath fill='%230cd463' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right calc(.375em + .1875rem) center;
        background-size: calc(.75em + .375rem) calc(.75em + .375rem)
      }

      .form-control.is-valid:focus,
      .was-validated .form-control:valid:focus {
        border-color: #0cd463;
        box-shadow: 0 0 0 .2rem rgba(12, 212, 99, .25)
      }

      .was-validated select.form-control:valid,
      select.form-control.is-valid {
        padding-right: 3rem !important;
        background-position: right 1.5rem center
      }

      .was-validated textarea.form-control:valid,
      textarea.form-control.is-valid {
        padding-right: calc(1.5em + .75rem);
        background-position: top calc(.375em + .1875rem) right calc(.375em + .1875rem)
      }

      .custom-select.is-valid,
      .was-validated .custom-select:valid {
        border-color: #0cd463;
        padding-right: calc(.75em + 2.3125rem) !important;
        background: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='4' height='5'%3E%3Cpath fill='%231e1e1e' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E") right .75rem center/8px 10px no-repeat, #fdffff url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath fill='%230cd463' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3E%3C/svg%3E") center right 1.75rem/calc(.75em + .375rem) calc(.75em + .375rem) no-repeat
      }

      .custom-select.is-valid:focus,
      .was-validated .custom-select:valid:focus {
        border-color: #0cd463;
        box-shadow: 0 0 0 .2rem rgba(12, 212, 99, .25)
      }

      .form-check-input.is-valid~.form-check-label,
      .was-validated .form-check-input:valid~.form-check-label {
        color: #0cd463
      }

      .form-check-input.is-valid~.valid-feedback,
      .form-check-input.is-valid~.valid-tooltip,
      .was-validated .form-check-input:valid~.valid-feedback,
      .was-validated .form-check-input:valid~.valid-tooltip {
        display: block
      }

      .custom-control-input.is-valid~.custom-control-label,
      .was-validated .custom-control-input:valid~.custom-control-label {
        color: #0cd463
      }

      .custom-control-input.is-valid~.custom-control-label:before,
      .was-validated .custom-control-input:valid~.custom-control-label:before {
        border-color: #0cd463
      }

      .custom-control-input.is-valid:checked~.custom-control-label:before,
      .was-validated .custom-control-input:valid:checked~.custom-control-label:before {
        border-color: #21f27c;
        background-color: #21f27c
      }

      .custom-control-input.is-valid:focus~.custom-control-label:before,
      .was-validated .custom-control-input:valid:focus~.custom-control-label:before {
        box-shadow: 0 0 0 .2rem rgba(12, 212, 99, .25)
      }

      .custom-control-input.is-valid:focus:not(:checked)~.custom-control-label:before,
      .custom-file-input.is-valid~.custom-file-label,
      .was-validated .custom-control-input:valid:focus:not(:checked)~.custom-control-label:before,
      .was-validated .custom-file-input:valid~.custom-file-label {
        border-color: #0cd463
      }

      .custom-file-input.is-valid:focus~.custom-file-label,
      .was-validated .custom-file-input:valid:focus~.custom-file-label {
        border-color: #0cd463;
        box-shadow: 0 0 0 .2rem rgba(12, 212, 99, .25)
      }

      .invalid-feedback {
        display: none;
        width: 100%;
        margin-top: .25rem;
        font-size: .875em;
        color: #e5472e
      }

      .invalid-tooltip {
        position: absolute;
        top: 100%;
        left: 0;
        z-index: 5;
        display: none;
        max-width: 100%;
        padding: .25rem .5rem;
        margin-top: .1rem;
        font-size: .875rem;
        line-height: 1.5;
        color: #fdffff;
        background-color: rgba(229, 71, 46, .9);
        border-radius: .25rem
      }

      .form-row>.col>.invalid-tooltip,
      .form-row>[class*=col-]>.invalid-tooltip {
        left: 5px
      }

      .is-invalid~.invalid-feedback,
      .is-invalid~.invalid-tooltip,
      .was-validated :invalid~.invalid-feedback,
      .was-validated :invalid~.invalid-tooltip {
        display: block
      }

      .form-control.is-invalid,
      .was-validated .form-control:invalid {
        border-color: #e5472e;
        padding-right: calc(1.5em + .75rem) !important;
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23e5472e'%3E%3Ccircle cx='6' cy='6' r='4.5'/%3E%3Cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3E%3Ccircle cx='6' cy='8.2' r='.6' fill='%23e5472e' stroke='none'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right calc(.375em + .1875rem) center;
        background-size: calc(.75em + .375rem) calc(.75em + .375rem)
      }

      .form-control.is-invalid:focus,
      .was-validated .form-control:invalid:focus {
        border-color: #e5472e;
        box-shadow: 0 0 0 .2rem rgba(229, 71, 46, .25)
      }

      .was-validated select.form-control:invalid,
      select.form-control.is-invalid {
        padding-right: 3rem !important;
        background-position: right 1.5rem center
      }

      .was-validated textarea.form-control:invalid,
      textarea.form-control.is-invalid {
        padding-right: calc(1.5em + .75rem);
        background-position: top calc(.375em + .1875rem) right calc(.375em + .1875rem)
      }

      .custom-select.is-invalid,
      .was-validated .custom-select:invalid {
        border-color: #e5472e;
        padding-right: calc(.75em + 2.3125rem) !important;
        background: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='4' height='5'%3E%3Cpath fill='%231e1e1e' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E") right .75rem center/8px 10px no-repeat, #fdffff url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23e5472e'%3E%3Ccircle cx='6' cy='6' r='4.5'/%3E%3Cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3E%3Ccircle cx='6' cy='8.2' r='.6' fill='%23e5472e' stroke='none'/%3E%3C/svg%3E") center right 1.75rem/calc(.75em + .375rem) calc(.75em + .375rem) no-repeat
      }

      .custom-select.is-invalid:focus,
      .was-validated .custom-select:invalid:focus {
        border-color: #e5472e;
        box-shadow: 0 0 0 .2rem rgba(229, 71, 46, .25)
      }

      .form-check-input.is-invalid~.form-check-label,
      .was-validated .form-check-input:invalid~.form-check-label {
        color: #e5472e
      }

      .form-check-input.is-invalid~.invalid-feedback,
      .form-check-input.is-invalid~.invalid-tooltip,
      .was-validated .form-check-input:invalid~.invalid-feedback,
      .was-validated .form-check-input:invalid~.invalid-tooltip {
        display: block
      }

      .custom-control-input.is-invalid~.custom-control-label,
      .was-validated .custom-control-input:invalid~.custom-control-label {
        color: #e5472e
      }

      .custom-control-input.is-invalid~.custom-control-label:before,
      .was-validated .custom-control-input:invalid~.custom-control-label:before {
        border-color: #e5472e
      }

      .custom-control-input.is-invalid:checked~.custom-control-label:before,
      .was-validated .custom-control-input:invalid:checked~.custom-control-label:before {
        border-color: #eb6f5b;
        background-color: #eb6f5b
      }

      .custom-control-input.is-invalid:focus~.custom-control-label:before,
      .was-validated .custom-control-input:invalid:focus~.custom-control-label:before {
        box-shadow: 0 0 0 .2rem rgba(229, 71, 46, .25)
      }

      .custom-control-input.is-invalid:focus:not(:checked)~.custom-control-label:before,
      .custom-file-input.is-invalid~.custom-file-label,
      .was-validated .custom-control-input:invalid:focus:not(:checked)~.custom-control-label:before,
      .was-validated .custom-file-input:invalid~.custom-file-label {
        border-color: #e5472e
      }

      .custom-file-input.is-invalid:focus~.custom-file-label,
      .was-validated .custom-file-input:invalid:focus~.custom-file-label {
        border-color: #e5472e;
        box-shadow: 0 0 0 .2rem rgba(229, 71, 46, .25)
      }

      .form-inline {
        display: flex;
        flex-flow: row wrap;
        align-items: center
      }

      .form-inline .form-check {
        width: 100%
      }

      @media(min-width:576px) {
        .form-inline label {
          justify-content: center
        }

        .form-inline .form-group,
        .form-inline label {
          display: flex;
          align-items: center;
          margin-bottom: 0
        }

        .form-inline .form-group {
          flex: 0 0 auto;
          flex-flow: row wrap
        }

        .form-inline .form-control {
          display: inline-block;
          width: auto;
          vertical-align: middle
        }

        .form-inline .form-control-plaintext {
          display: inline-block
        }

        .form-inline .custom-select,
        .form-inline .input-group {
          width: auto
        }

        .form-inline .form-check {
          display: flex;
          align-items: center;
          justify-content: center;
          width: auto;
          padding-left: 0
        }

        .form-inline .form-check-input {
          position: relative;
          flex-shrink: 0;
          margin-top: 0;
          margin-right: .25rem;
          margin-left: 0
        }

        .form-inline .custom-control {
          align-items: center;
          justify-content: center
        }

        .form-inline .custom-control-label {
          margin-bottom: 0
        }
      }

   
     

      

      @media(prefers-reduced-motion:reduce) 
   
    

      @media(min-width:768px) 

      @media(min-width:992px)

      @media(min-width:1200px) 

      

    

    
      .badge {
        display: inline-block;
        padding: .25em .4em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: .25rem;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out
      }

      @media(prefers-reduced-motion:reduce) {
        .badge {
          transition: none
        }
      }

      a.badge:focus,
      a.badge:hover {
        text-decoration: none
      }

      .badge:empty {
        display: none
      }

      .btn .badge {
        position: relative;
        top: -1px
      }

      .badge-pill {
        padding-right: .6em;
        padding-left: .6em;
        border-radius: 10rem
      }

      .badge-primary {
        color: #2a2e30;
        background-color: #fff
      }

      a.badge-primary:focus,
      a.badge-primary:hover {
        color: #2a2e30;
        background-color: #e6e6e6
      }

      a.badge-primary.focus,
      a.badge-primary:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 100%, .5)
      }

      .badge-secondary {
        color: #2a2e30;
        background-color: #fff
      }

      a.badge-secondary:focus,
      a.badge-secondary:hover {
        color: #2a2e30;
        background-color: #e6e6e6
      }

      a.badge-secondary.focus,
      a.badge-secondary:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 100%, .5)
      }

      .badge-success {
        color: #fdffff;
        background-color: #0cd463
      }

      a.badge-success:focus,
      a.badge-success:hover {
        color: #fdffff;
        background-color: #09a44c
      }

      a.badge-success.focus,
      a.badge-success:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(12, 212, 99, .5)
      }

      .badge-info {
        color: #fdffff;
        background-color: #00cfe8
      }

      a.badge-info:focus,
      a.badge-info:hover {
        color: #fdffff;
        background-color: #00a1b5
      }

      a.badge-info.focus,
      a.badge-info:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(0, 207, 232, .5)
      }

      .badge-warning {
        color: #2a2e30;
        background-color: #ff9f43
      }

      a.badge-warning:focus,
      a.badge-warning:hover {
        color: #2a2e30;
        background-color: #ff8510
      }

      a.badge-warning.focus,
      a.badge-warning:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(255, 159, 67, .5)
      }

      .badge-danger {
        color: #fdffff;
        background-color: #e5472e
      }

      a.badge-danger:focus,
      a.badge-danger:hover {
        color: #fdffff;
        background-color: #c73119
      }

      a.badge-danger.focus,
      a.badge-danger:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(229, 71, 46, .5)
      }

      .badge-light {
        color: #2a2e30;
        background-color: #f6f6f6
      }

      a.badge-light:focus,
      a.badge-light:hover {
        color: #2a2e30;
        background-color: #ddd
      }

      a.badge-light.focus,
      a.badge-light:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 96.5%, .5)
      }

      .badge-dark {
        color: #2a2e30;
        background-color: #c2bdbd
      }

      a.badge-dark:focus,
      a.badge-dark:hover {
        color: #2a2e30;
        background-color: #aaa2a2
      }

      a.badge-dark.focus,
      a.badge-dark:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(194, 189, 189, .5)
      }

      .jumbotron {
        padding: 2rem 1rem;
        margin-bottom: 2rem;
        background-color: #ededed;
        border-radius: .3rem
      }

      @media(min-width:576px) {
        .jumbotron {
          padding: 4rem 2rem
        }
      }

      .jumbotron-fluid {
        padding-right: 0;
        padding-left: 0;
        border-radius: 0
      }

      .alert {
        position: relative;
        padding: .75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem
      }

      .alert-heading {
        color: inherit
      }

      .alert-link {
        font-weight: 700
      }

      .alert-dismissible {
        padding-right: 4rem
      }

      .alert-dismissible .close {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 2;
        padding: .75rem 1.25rem;
        color: inherit
      }

      .alert-primary {
        color: #95989b;
        background-color: #fdffff;
        border-color: #feffff
      }

      .alert-primary hr {
        border-top-color: #e5ffff
      }

      .alert-primary .alert-link {
        color: #7b7f82
      }

      .alert-secondary {
        color: #95989b;
        background-color: #fdffff;
        border-color: #feffff
      }

      .alert-secondary hr {
        border-top-color: #e5ffff
      }

      .alert-secondary .alert-link {
        color: #7b7f82
      }

      .alert-success {
        color: #17824a;
        background-color: #cdf6e0;
        border-color: #baf3d3
      }

      .alert-success hr {
        border-top-color: #a4efc5
      }

      .alert-success .alert-link {
        color: #0f5731
      }

      .alert-info {
        color: #107f8f;
        background-color: #caf5fa;
        border-color: #b6f2f9
      }

      .alert-info hr {
        border-top-color: #9eeef7
      }

      .alert-info .alert-link {
        color: #0b5661
      }

      .alert-warning {
        color: #956639;
        background-color: #fdecd9;
        border-color: #fee4ca
      }

      .alert-warning hr {
        border-top-color: #fed7b1
      }

      .alert-warning .alert-link {
        color: #704d2b
      }

      .alert-danger {
        color: #87392e;
        background-color: #f8dad5;
        border-color: #f6cbc4
      }

      .alert-danger hr {
        border-top-color: #f3b8ae
      }

      .alert-danger .alert-link {
        color: #612921
      }

      .alert-light {
        color: #909496;
        background-color: #fcfdfd;
        border-color: #fbfcfc
      }

      .alert-light hr {
        border-top-color: #ecf1f1
      }

      .alert-light .alert-link {
        color: #767b7d
      }

      .alert-dark {
        color: #757679;
        background-color: #f1f2f2;
        border-color: #eceded
      }

      .alert-dark hr {
        border-top-color: #dfe1e1
      }

      .alert-dark .alert-link {
        color: #5c5d5f
      }

      @keyframes  progress-bar-stripes {
        0% {
          background-position: 1rem 0
        }

        to {
          background-position: 0 0
        }
      }

      .progress {
        height: 1rem;
        line-height: 0;
        font-size: .75rem;
        background-color: #ededed;
        border-radius: .25rem
      }

      .progress,
      .progress-bar {
        display: flex;
        overflow: hidden
      }

      .progress-bar {
        flex-direction: column;
        justify-content: center;
        color: #fdffff;
        text-align: center;
        white-space: nowrap;
        background-color: #fff;
        transition: width .6s ease
      }

      @media(prefers-reduced-motion:reduce) 

      

     


     

    
    </style>
    <style type="text/css">
     

      

    

      .nav {
        display: flex;
        flex-wrap: wrap;
        padding-left: 0;
        margin-bottom: 0;
        list-style: none;
      }

      .nav-link {
        display: block;
        padding: .5rem 1rem
      }

      .nav-link:focus,
      .nav-link:hover {
        text-decoration: none
      }

      .nav-link.disabled {
        color: #b8c2cc;
        pointer-events: none;
        cursor: default
      }

      .nav-tabs {
        border-bottom: 1px solid #dae1e7
      }

      .nav-tabs .nav-link {
        margin-bottom: -1px;
        background-color: transparent;
        border: 1px solid transparent;
        border-top-left-radius: .25rem;
        border-top-right-radius: .25rem
      }

      .nav-tabs .nav-link:focus,
      .nav-tabs .nav-link:hover {
        isolation: isolate;
        border-color: #ededed #ededed #dae1e7
      }

      .nav-tabs .nav-link.disabled {
        color: #b8c2cc;
        background-color: transparent;
        border-color: transparent
      }

      .nav-tabs .nav-item.show .nav-link,
      .nav-tabs .nav-link.active {
        color: #4e5154;
        background-color: #fdffff;
        border-color: #dae1e7 #dae1e7 #fdffff
      }

      .nav-tabs .dropdown-menu {
        margin-top: -1px;
        border-top-left-radius: 0;
        border-top-right-radius: 0
      }

      .nav-pills .nav-link {
        background: none;
        border: 0;
        border-radius: .25rem
      }

      .nav-pills .nav-link.active,
      .nav-pills .show>.nav-link {
        color: #fdffff;
        background-color: #fff
      }

      .nav-fill .nav-item,
      .nav-fill>.nav-link {
        flex: 1 1 auto;
        text-align: center
      }

      .nav-justified .nav-item,
      .nav-justified>.nav-link {
        flex-basis: 0;
        flex-grow: 1;
        text-align: center
      }

      .tab-content>.tab-pane {
        display: none
      }

      .tab-content>.active {
        display: block
      }

      .navbar {
        position: relative;
        padding: .5rem 1rem
      }

      .navbar,
      .navbar .container,
      .navbar .container-fluid,
      .navbar .container-lg,
      .navbar .container-md,
      .navbar .container-sm,
      .navbar .container-xl {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between
      }

      .navbar-brand {
        display: inline-block;
        padding-top: .3125rem;
        padding-bottom: .3125rem;
        margin-right: 1rem;
        font-size: 1.25rem;
        line-height: inherit;
        white-space: nowrap
      }

      .navbar-brand:focus,
      .navbar-brand:hover {
        text-decoration: none
      }

      .navbar-nav {
        display: flex;
        flex-direction: column;
        padding-left: 0;
        margin-bottom: 0;
        list-style: none
      }

      .navbar-nav .nav-link {
        padding-right: 0;
        padding-left: 0
      }

      .navbar-nav .dropdown-menu {
        position: static;
        float: none
      }

      .navbar-text {
        display: inline-block;
        padding-top: .5rem;
        padding-bottom: .5rem
      }

      .navbar-collapse {
        flex-basis: 100%;
        flex-grow: 1;
        align-items: center
      }

      .navbar-toggler {
        padding: .25rem .75rem;
        font-size: 1.25rem;
        line-height: 1;
        background-color: transparent;
        border: 1px solid transparent;
        border-radius: .25rem
      }

      .navbar-toggler:focus,
      .navbar-toggler:hover {
        text-decoration: none
      }

      .navbar-toggler-icon {
        display: inline-block;
        width: 1.5em;
        height: 1.5em;
        vertical-align: middle;
        content: "";
        background: 50%/100% 100% no-repeat
      }

      .navbar-nav-scroll {
        max-height: 75vh;
        overflow-y: auto
      }

      @media(max-width:575.98px) {

        .navbar-expand-sm>.container,
        .navbar-expand-sm>.container-fluid,
        .navbar-expand-sm>.container-lg,
        .navbar-expand-sm>.container-md,
        .navbar-expand-sm>.container-sm,
        .navbar-expand-sm>.container-xl {
          padding-right: 0;
          padding-left: 0
        }
      }

      @media(min-width:576px) {
        .navbar-expand-sm {
          flex-flow: row nowrap;
          justify-content: flex-start
        }

        .navbar-expand-sm .navbar-nav {
          flex-direction: row
        }

       

        .navbar-expand-sm .navbar-nav .nav-link {
          padding-right: .5rem;
          padding-left: .5rem
        }

        .navbar-expand-sm>.container,
        .navbar-expand-sm>.container-fluid,
        .navbar-expand-sm>.container-lg,
        .navbar-expand-sm>.container-md,
        .navbar-expand-sm>.container-sm,
        .navbar-expand-sm>.container-xl {
          flex-wrap: nowrap
        }

        .navbar-expand-sm .navbar-nav-scroll {
          overflow: visible
        }

        .navbar-expand-sm .navbar-collapse {
          display: flex !important;
          flex-basis: auto
        }

        .navbar-expand-sm .navbar-toggler {
          display: none
        }
      }

      @media(max-width:767.98px) {

        .navbar-expand-md>.container,
        .navbar-expand-md>.container-fluid,
        .navbar-expand-md>.container-lg,
        .navbar-expand-md>.container-md,
        .navbar-expand-md>.container-sm,
        .navbar-expand-md>.container-xl {
          padding-right: 0;
          padding-left: 0
        }
      }

      @media(min-width:768px) {
        .navbar-expand-md {
          flex-flow: row nowrap;
          justify-content: flex-start
        }

        .navbar-expand-md .navbar-nav {
          flex-direction: row
        }

        

        .navbar-expand-md .navbar-nav .nav-link {
          padding-right: .5rem;
          padding-left: .5rem
        }

        .navbar-expand-md>.container,
        .navbar-expand-md>.container-fluid,
        .navbar-expand-md>.container-lg,
        .navbar-expand-md>.container-md,
        .navbar-expand-md>.container-sm,
        .navbar-expand-md>.container-xl {
          flex-wrap: nowrap
        }

        .navbar-expand-md .navbar-nav-scroll {
          overflow: visible
        }

        .navbar-expand-md .navbar-collapse {
          display: flex !important;
          flex-basis: auto
        }

        .navbar-expand-md .navbar-toggler {
          display: none
        }
      }

      @media(max-width:991.98px) {

        .navbar-expand-lg>.container,
        .navbar-expand-lg>.container-fluid,
        .navbar-expand-lg>.container-lg,
        .navbar-expand-lg>.container-md,
        .navbar-expand-lg>.container-sm,
        .navbar-expand-lg>.container-xl {
          padding-right: 0;
          padding-left: 0
        }
      }

      @media(min-width:992px) {
        .navbar-expand-lg {
          flex-flow: row nowrap;
          justify-content: flex-start
        }

        .navbar-expand-lg .navbar-nav {
          flex-direction: row
        }

        
        .navbar-expand-lg .navbar-nav .nav-link {
          padding-right: .5rem;
          padding-left: .5rem
        }

        .navbar-expand-lg>.container,
        .navbar-expand-lg>.container-fluid,
        .navbar-expand-lg>.container-lg,
        .navbar-expand-lg>.container-md,
        .navbar-expand-lg>.container-sm,
        .navbar-expand-lg>.container-xl {
          flex-wrap: nowrap
        }

        .navbar-expand-lg .navbar-nav-scroll {
          overflow: visible
        }

        .navbar-expand-lg .navbar-collapse {
          display: flex !important;
          flex-basis: auto
        }

        .navbar-expand-lg .navbar-toggler {
          display: none
        }
      }

      @media(max-width:1199.98px) {

        .navbar-expand-xl>.container,
        .navbar-expand-xl>.container-fluid,
        .navbar-expand-xl>.container-lg,
        .navbar-expand-xl>.container-md,
        .navbar-expand-xl>.container-sm,
        .navbar-expand-xl>.container-xl {
          padding-right: 0;
          padding-left: 0
        }
      }

      @media(min-width:1200px) {
        .navbar-expand-xl {
          flex-flow: row nowrap;
          justify-content: flex-start
        }

        .navbar-expand-xl .navbar-nav {
          flex-direction: row
        }

       

        .navbar-expand-xl .navbar-nav .nav-link {
          padding-right: .5rem;
          padding-left: .5rem
        }

        .navbar-expand-xl>.container,
        .navbar-expand-xl>.container-fluid,
        .navbar-expand-xl>.container-lg,
        .navbar-expand-xl>.container-md,
        .navbar-expand-xl>.container-sm,
        .navbar-expand-xl>.container-xl {
          flex-wrap: nowrap
        }

        .navbar-expand-xl .navbar-nav-scroll {
          overflow: visible
        }

        .navbar-expand-xl .navbar-collapse {
          display: flex !important;
          flex-basis: auto
        }

        .navbar-expand-xl .navbar-toggler {
          display: none
        }
      }

      .navbar-expand {
        flex-flow: row nowrap;
        justify-content: flex-start
      }

      .navbar-expand>.container,
      .navbar-expand>.container-fluid,
      .navbar-expand>.container-lg,
      .navbar-expand>.container-md,
      .navbar-expand>.container-sm,
      .navbar-expand>.container-xl {
        padding-right: 0;
        padding-left: 0
      }

      .navbar-expand .navbar-nav {
        flex-direction: row
      }

      
      .navbar-expand .navbar-nav .nav-link {
        padding-right: .5rem;
        padding-left: .5rem
      }

      .navbar-expand>.container,
      .navbar-expand>.container-fluid,
      .navbar-expand>.container-lg,
      .navbar-expand>.container-md,
      .navbar-expand>.container-sm,
      .navbar-expand>.container-xl {
        flex-wrap: nowrap
      }

      .navbar-expand .navbar-nav-scroll {
        overflow: visible
      }

      .navbar-expand .navbar-collapse {
        display: flex !important;
        flex-basis: auto
      }

      .navbar-expand .navbar-toggler {
        display: none
      }

      .navbar-light .navbar-brand,
      .navbar-light .navbar-brand:focus,
      .navbar-light .navbar-brand:hover {
        color: rgba(34, 41, 47, .9)
      }

      .navbar-light .navbar-nav .nav-link {
        color: rgba(34, 41, 47, .5)
      }

      .navbar-light .navbar-nav .nav-link:focus,
      .navbar-light .navbar-nav .nav-link:hover {
        color: rgba(34, 41, 47, .7)
      }

      .navbar-light .navbar-nav .nav-link.disabled {
        color: rgba(34, 41, 47, .3)
      }

      .navbar-light .navbar-nav .active>.nav-link,
      .navbar-light .navbar-nav .nav-link.active,
      .navbar-light .navbar-nav .nav-link.show,
      .navbar-light .navbar-nav .show>.nav-link {
        color: rgba(34, 41, 47, .9)
      }

      .navbar-light .navbar-toggler {
        color: rgba(34, 41, 47, .5);
        border-color: rgba(34, 41, 47, .1)
      }

      .navbar-light .navbar-toggler-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='30' height='30'%3E%3Cpath stroke='rgba(34, 41, 47, 0.5)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E")
      }

      .navbar-light .navbar-text {
        color: rgba(34, 41, 47, .5)
      }

      .navbar-light .navbar-text a,
      .navbar-light .navbar-text a:focus,
      .navbar-light .navbar-text a:hover {
        color: rgba(34, 41, 47, .9)
      }

      .navbar-dark .navbar-brand,
      .navbar-dark .navbar-brand:focus,
      .navbar-dark .navbar-brand:hover {
        color: #fdffff
      }

      .navbar-dark .navbar-nav .nav-link {
        color: rgba(253, 255, 255, .5)
      }

      .navbar-dark .navbar-nav .nav-link:focus,
      .navbar-dark .navbar-nav .nav-link:hover {
        color: rgba(253, 255, 255, .75)
      }

      .navbar-dark .navbar-nav .nav-link.disabled {
        color: rgba(253, 255, 255, .25)
      }

      .navbar-dark .navbar-nav .active>.nav-link,
      .navbar-dark .navbar-nav .nav-link.active,
      .navbar-dark .navbar-nav .nav-link.show,
      .navbar-dark .navbar-nav .show>.nav-link {
        color: #fdffff
      }

      .navbar-dark .navbar-toggler {
        color: rgba(253, 255, 255, .5);
        border-color: rgba(253, 255, 255, .1)
      }

      .navbar-dark .navbar-toggler-icon {
        background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='30' height='30'%3E%3Cpath stroke='rgba(253, 255, 255, 0.5)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E")
      }

      .navbar-dark .navbar-text {
        color: rgba(253, 255, 255, .5)
      }

      .navbar-dark .navbar-text a,
      .navbar-dark .navbar-text a:focus,
      .navbar-dark .navbar-text a:hover {
        color: #fdffff
      }

      .card {
        position: relative;
        display: flex;
        flex-direction: column;
        min-width: 0;
        word-wrap: break-word;
        background-color: #fdffff;
        background-clip: border-box;
        border: 1px solid rgba(34, 41, 47, .125);
        border-radius: .25rem
      }

      .card>hr {
        margin-right: 0;
        margin-left: 0
      }

      .card>.list-group {
        border-top: inherit;
        border-bottom: inherit
      }

      .card>.list-group:first-child {
        border-top-width: 0;
        border-top-left-radius: calc(.25rem - 1px);
        border-top-right-radius: calc(.25rem - 1px)
      }

      .card>.list-group:last-child {
        border-bottom-width: 0;
        border-bottom-right-radius: calc(.25rem - 1px);
        border-bottom-left-radius: calc(.25rem - 1px)
      }

      .card>.card-header+.list-group,
      .card>.list-group+.card-footer {
        border-top: 0
      }

      .card-body {
        flex: 1 1 auto;
        min-height: 1px;
        padding: 1.25rem
      }

      .card-title {
        margin-bottom: .75rem
      }

      .card-subtitle {
        margin-top: -.375rem
      }

      .card-subtitle,
      .card-text:last-child {
        margin-bottom: 0
      }

      .card-link:hover {
        text-decoration: none
      }

      .card-link+.card-link {
        margin-left: 1.25rem
      }

      .card-header {
        padding: .75rem 1.25rem;
        margin-bottom: 0;
        background-color: rgba(34, 41, 47, .03);
        border-bottom: 1px solid rgba(34, 41, 47, .125)
      }

      .card-header:first-child {
        border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0
      }

      .card-footer {
        padding: .75rem 1.25rem;
        background-color: rgba(34, 41, 47, .03);
        border-top: 1px solid rgba(34, 41, 47, .125)
      }

      .card-footer:last-child {
        border-radius: 0 0 calc(.25rem - 1px) calc(.25rem - 1px)
      }

      .card-header-tabs {
        margin-bottom: -.75rem;
        border-bottom: 0
      }

      .card-header-pills,
      .card-header-tabs {
        margin-right: -.625rem;
        margin-left: -.625rem
      }

      .card-img-overlay {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 1.25rem;
        border-radius: calc(.25rem - 1px)
      }

      .card-img,
      .card-img-bottom,
      .card-img-top {
        flex-shrink: 0;
        width: 100%
      }

      .card-img,
      .card-img-top {
        border-top-left-radius: calc(.25rem - 1px);
        border-top-right-radius: calc(.25rem - 1px)
      }

      .card-img,
      .card-img-bottom {
        border-bottom-right-radius: calc(.25rem - 1px);
        border-bottom-left-radius: calc(.25rem - 1px)
      }

      .card-deck .card {
        margin-bottom: 15px
      }

      @media(min-width:576px) {
        .card-deck {
          display: flex;
          flex-flow: row wrap;
          margin-right: -15px;
          margin-left: -15px
        }

        .card-deck .card {
          flex: 1 0 0%;
          margin-right: 15px;
          margin-bottom: 0;
          margin-left: 15px
        }
      }

      .card-group>.card {
        margin-bottom: 15px
      }

      @media(min-width:576px) {
        .card-group {
          display: flex;
          flex-flow: row wrap
        }

        .card-group>.card {
          flex: 1 0 0%;
          margin-bottom: 0
        }

        .card-group>.card+.card {
          margin-left: 0;
          border-left: 0
        }

        .card-group>.card:not(:last-child) {
          border-top-right-radius: 0;
          border-bottom-right-radius: 0
        }

        .card-group>.card:not(:last-child) .card-header,
        .card-group>.card:not(:last-child) .card-img-top {
          border-top-right-radius: 0
        }

        .card-group>.card:not(:last-child) .card-footer,
        .card-group>.card:not(:last-child) .card-img-bottom {
          border-bottom-right-radius: 0
        }

        .card-group>.card:not(:first-child) {
          border-top-left-radius: 0;
          border-bottom-left-radius: 0
        }

        .card-group>.card:not(:first-child) .card-header,
        .card-group>.card:not(:first-child) .card-img-top {
          border-top-left-radius: 0
        }

        .card-group>.card:not(:first-child) .card-footer,
        .card-group>.card:not(:first-child) .card-img-bottom {
          border-bottom-left-radius: 0
        }
      }

      .card-columns .card {
        margin-bottom: .75rem
      }

      @media(min-width:576px) {
        .card-columns {
          -moz-column-count: 3;
          column-count: 3;
          -moz-column-gap: 1.25rem;
          column-gap: 1.25rem;
          orphans: 1;
          widows: 1
        }

        .card-columns .card {
          display: inline-block;
          width: 100%
        }
      }

     
      .breadcrumb {
        display: flex;
        flex-wrap: wrap;
        padding: .75rem 1rem;
        margin-bottom: 1rem;
        list-style: none;
        background-color: #ededed;
        border-radius: .25rem
      }

      .breadcrumb-item+.breadcrumb-item {
        padding-left: .5rem
      }

      .breadcrumb-item+.breadcrumb-item:before {
        float: left;
        padding-right: .5rem;
        color: #b8c2cc;
        content: "/"
      }

      .breadcrumb-item+.breadcrumb-item:hover:before {
        text-decoration: underline;
        text-decoration: none
      }

      .breadcrumb-item.active {
        color: #b8c2cc
      }

      .pagination {
        display: flex;
        padding-left: 0;
        list-style: none;
        border-radius: .25rem
      }

     
      .badge {
        display: inline-block;
        padding: .25em .4em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: .25rem;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out
      }

      @media(prefers-reduced-motion:reduce) {
        .badge {
          transition: none
        }
      }

      a.badge:focus,
      a.badge:hover {
        text-decoration: none
      }

      .badge:empty {
        display: none
      }

      .btn .badge {
        position: relative;
        top: -1px
      }

      .badge-pill {
        padding-right: .6em;
        padding-left: .6em;
        border-radius: 10rem
      }

      .badge-primary {
        color: #2a2e30;
        background-color: #fff
      }

      a.badge-primary:focus,
      a.badge-primary:hover {
        color: #2a2e30;
        background-color: #e6e6e6
      }

      a.badge-primary.focus,
      a.badge-primary:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 100%, .5)
      }

      .badge-secondary {
        color: #2a2e30;
        background-color: #fff
      }

      a.badge-secondary:focus,
      a.badge-secondary:hover {
        color: #2a2e30;
        background-color: #e6e6e6
      }

      a.badge-secondary.focus,
      a.badge-secondary:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 100%, .5)
      }

      .badge-success {
        color: #fdffff;
        background-color: #0cd463
      }

      a.badge-success:focus,
      a.badge-success:hover {
        color: #fdffff;
        background-color: #09a44c
      }

      a.badge-success.focus,
      a.badge-success:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(12, 212, 99, .5)
      }

      .badge-info {
        color: #fdffff;
        background-color: #00cfe8
      }

      a.badge-info:focus,
      a.badge-info:hover {
        color: #fdffff;
        background-color: #00a1b5
      }

      a.badge-info.focus,
      a.badge-info:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(0, 207, 232, .5)
      }

      .badge-warning {
        color: #2a2e30;
        background-color: #ff9f43
      }

      a.badge-warning:focus,
      a.badge-warning:hover {
        color: #2a2e30;
        background-color: #ff8510
      }

      a.badge-warning.focus,
      a.badge-warning:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(255, 159, 67, .5)
      }

      .badge-danger {
        color: #fdffff;
        background-color: #e5472e
      }

      a.badge-danger:focus,
      a.badge-danger:hover {
        color: #fdffff;
        background-color: #c73119
      }

      a.badge-danger.focus,
      a.badge-danger:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(229, 71, 46, .5)
      }

      .badge-light {
        color: #2a2e30;
        background-color: #f6f6f6
      }

      a.badge-light:focus,
      a.badge-light:hover {
        color: #2a2e30;
        background-color: #ddd
      }

      a.badge-light.focus,
      a.badge-light:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem hsla(0, 0%, 96.5%, .5)
      }

      .badge-dark {
        color: #2a2e30;
        background-color: #c2bdbd
      }

      a.badge-dark:focus,
      a.badge-dark:hover {
        color: #2a2e30;
        background-color: #aaa2a2
      }

      a.badge-dark.focus,
      a.badge-dark:focus {
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(194, 189, 189, .5)
      }

      .jumbotron {
        padding: 2rem 1rem;
        margin-bottom: 2rem;
        background-color: #ededed;
        border-radius: .3rem
      }

      @media(min-width:576px) {
        .jumbotron {
          padding: 4rem 2rem
        }
      }

      .jumbotron-fluid {
        padding-right: 0;
        padding-left: 0;
        border-radius: 0
      }

      .alert {
        position: relative;
        padding: .75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem
      }

      .alert-heading {
        color: inherit
      }

      .alert-link {
        font-weight: 700
      }

      .alert-dismissible {
        padding-right: 4rem
      }

      .alert-dismissible .close {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 2;
        padding: .75rem 1.25rem;
        color: inherit
      }

      .alert-primary {
        color: #95989b;
        background-color: #fdffff;
        border-color: #feffff
      }

      .alert-primary hr {
        border-top-color: #e5ffff
      }

      .alert-primary .alert-link {
        color: #7b7f82
      }

      .alert-secondary {
        color: #95989b;
        background-color: #fdffff;
        border-color: #feffff
      }

      .alert-secondary hr {
        border-top-color: #e5ffff
      }

      .alert-secondary .alert-link {
        color: #7b7f82
      }

      .alert-success {
        color: #17824a;
        background-color: #cdf6e0;
        border-color: #baf3d3
      }

      .alert-success hr {
        border-top-color: #a4efc5
      }

      .alert-success .alert-link {
        color: #0f5731
      }

      .alert-info {
        color: #107f8f;
        background-color: #caf5fa;
        border-color: #b6f2f9
      }

      .alert-info hr {
        border-top-color: #9eeef7
      }

      .alert-info .alert-link {
        color: #0b5661
      }

      .alert-warning {
        color: #956639;
        background-color: #fdecd9;
        border-color: #fee4ca
      }

      .alert-warning hr {
        border-top-color: #fed7b1
      }

      .alert-warning .alert-link {
        color: #704d2b
      }

      .alert-danger {
        color: #87392e;
        background-color: #f8dad5;
        border-color: #f6cbc4
      }

      .alert-danger hr {
        border-top-color: #f3b8ae
      }

      .alert-danger .alert-link {
        color: #612921
      }

      .alert-light {
        color: #909496;
        background-color: #fcfdfd;
        border-color: #fbfcfc
      }

      .alert-light hr {
        border-top-color: #ecf1f1
      }

      .alert-light .alert-link {
        color: #767b7d
      }

      .alert-dark {
        color: #757679;
        background-color: #f1f2f2;
        border-color: #eceded
      }

      .alert-dark hr {
        border-top-color: #dfe1e1
      }

      .alert-dark .alert-link {
        color: #5c5d5f
      }

      @keyframes  progress-bar-stripes {
        0% {
          background-position: 1rem 0
        }

        to {
          background-position: 0 0
        }
      }

      .progress {
        height: 1rem;
        line-height: 0;
        font-size: .75rem;
        background-color: #ededed;
        border-radius: .25rem
      }

      .progress,
      .progress-bar {
        display: flex;
        overflow: hidden
      }

      .progress-bar {
        flex-direction: column;
        justify-content: center;
        color: #fdffff;
        text-align: center;
        white-space: nowrap;
        background-color: #fff;
        transition: width .6s ease
      }

      @media(prefers-reduced-motion:reduce) {
        .progress-bar {
          transition: none
        }
      }

      .progress-bar-striped {
        background-image: linear-gradient(45deg, rgba(253, 255, 255, .15) 25%, transparent 0, transparent 50%, rgba(253, 255, 255, .15) 0, rgba(253, 255, 255, .15) 75%, transparent 0, transparent);
        background-size: 1rem 1rem
      }

      .progress-bar-animated {
        animation: progress-bar-stripes 1s linear infinite
      }

      @media(prefers-reduced-motion:reduce) {
        .progress-bar-animated {
          animation: none
        }
      }

      .media {
        display: flex;
        align-items: flex-start
      }

      .media-body {
        flex: 1
      }

      .list-group {
        display: flex;
        flex-direction: column;
        padding-left: 0;
        margin-bottom: 0;
        border-radius: .25rem
      }

      .list-group-item-action {
        width: 100%;
        color: #4e5154;
        text-align: inherit
      }

      .list-group-item-action:focus,
      .list-group-item-action:hover {
        z-index: 1;
        color: #4e5154;
        text-decoration: none;
        background-color: #babfc7
      }

      .list-group-item-action:active {
        color: #2a2e30;
        background-color: #ededed
      }

      .list-group-item {
        position: relative;
        display: block;
        padding: .75rem 1.25rem;
        background-color: #fdffff;
        border: 1px solid rgba(34, 41, 47, .125)
      }

      .list-group-item:first-child {
        border-top-left-radius: inherit;
        border-top-right-radius: inherit
      }

      .list-group-item:last-child {
        border-bottom-right-radius: inherit;
        border-bottom-left-radius: inherit
      }

      .list-group-item.disabled,
      .list-group-item:disabled {
        color: #b8c2cc;
        pointer-events: none;
        background-color: #fdffff
      }

      .list-group-item.active {
        z-index: 2;
        color: #fdffff;
        background-color: #fff;
        border-color: #fff
      }

      .list-group-item+.list-group-item {
        border-top-width: 0
      }

      .list-group-item+.list-group-item.active {
        margin-top: -1px;
        border-top-width: 1px
      }

      .list-group-horizontal {
        flex-direction: row
      }

      .list-group-horizontal>.list-group-item:first-child {
        border-bottom-left-radius: .25rem;
        border-top-right-radius: 0
      }

      .list-group-horizontal>.list-group-item:last-child {
        border-top-right-radius: .25rem;
        border-bottom-left-radius: 0
      }

      .list-group-horizontal>.list-group-item.active {
        margin-top: 0
      }

      .list-group-horizontal>.list-group-item+.list-group-item {
        border-top-width: 1px;
        border-left-width: 0
      }

      .list-group-horizontal>.list-group-item+.list-group-item.active {
        margin-left: -1px;
        border-left-width: 1px
      }

      @media(min-width:576px) {
        .list-group-horizontal-sm {
          flex-direction: row
        }

        .list-group-horizontal-sm>.list-group-item:first-child {
          border-bottom-left-radius: .25rem;
          border-top-right-radius: 0
        }

        .list-group-horizontal-sm>.list-group-item:last-child {
          border-top-right-radius: .25rem;
          border-bottom-left-radius: 0
        }

        .list-group-horizontal-sm>.list-group-item.active {
          margin-top: 0
        }

        .list-group-horizontal-sm>.list-group-item+.list-group-item {
          border-top-width: 1px;
          border-left-width: 0
        }

        .list-group-horizontal-sm>.list-group-item+.list-group-item.active {
          margin-left: -1px;
          border-left-width: 1px
        }
      }

      @media(min-width:768px) {
        .list-group-horizontal-md {
          flex-direction: row
        }

        .list-group-horizontal-md>.list-group-item:first-child {
          border-bottom-left-radius: .25rem;
          border-top-right-radius: 0
        }

        .list-group-horizontal-md>.list-group-item:last-child {
          border-top-right-radius: .25rem;
          border-bottom-left-radius: 0
        }

        .list-group-horizontal-md>.list-group-item.active {
          margin-top: 0
        }

        .list-group-horizontal-md>.list-group-item+.list-group-item {
          border-top-width: 1px;
          border-left-width: 0
        }

        .list-group-horizontal-md>.list-group-item+.list-group-item.active {
          margin-left: -1px;
          border-left-width: 1px
        }
      }

      @media(min-width:992px) {
        .list-group-horizontal-lg {
          flex-direction: row
        }

        .list-group-horizontal-lg>.list-group-item:first-child {
          border-bottom-left-radius: .25rem;
          border-top-right-radius: 0
        }

        .list-group-horizontal-lg>.list-group-item:last-child {
          border-top-right-radius: .25rem;
          border-bottom-left-radius: 0
        }

        .list-group-horizontal-lg>.list-group-item.active {
          margin-top: 0
        }

        .list-group-horizontal-lg>.list-group-item+.list-group-item {
          border-top-width: 1px;
          border-left-width: 0
        }

        .list-group-horizontal-lg>.list-group-item+.list-group-item.active {
          margin-left: -1px;
          border-left-width: 1px
        }
      }

      @media(min-width:1200px) {
        .list-group-horizontal-xl {
          flex-direction: row
        }

        .list-group-horizontal-xl>.list-group-item:first-child {
          border-bottom-left-radius: .25rem;
          border-top-right-radius: 0
        }

        .list-group-horizontal-xl>.list-group-item:last-child {
          border-top-right-radius: .25rem;
          border-bottom-left-radius: 0
        }

        .list-group-horizontal-xl>.list-group-item.active {
          margin-top: 0
        }

        .list-group-horizontal-xl>.list-group-item+.list-group-item {
          border-top-width: 1px;
          border-left-width: 0
        }

        .list-group-horizontal-xl>.list-group-item+.list-group-item.active {
          margin-left: -1px;
          border-left-width: 1px
        }
      }

      .list-group-flush {
        border-radius: 0
      }

      .list-group-flush>.list-group-item {
        border-width: 0 0 1px
      }

      .list-group-flush>.list-group-item:last-child {
        border-bottom-width: 0
      }

      .list-group-item-primary {
        color: #95989b;
        background-color: #feffff
      }

      .list-group-item-primary.list-group-item-action:focus,
      .list-group-item-primary.list-group-item-action:hover {
        color: #95989b;
        background-color: #e5ffff
      }

      .list-group-item-primary.list-group-item-action.active {
        color: #fdffff;
        background-color: #95989b;
        border-color: #95989b
      }

      .list-group-item-secondary {
        color: #95989b;
        background-color: #feffff
      }

      .list-group-item-secondary.list-group-item-action:focus,
      .list-group-item-secondary.list-group-item-action:hover {
        color: #95989b;
        background-color: #e5ffff
      }

      .list-group-item-secondary.list-group-item-action.active {
        color: #fdffff;
        background-color: #95989b;
        border-color: #95989b
      }

      .list-group-item-success {
        color: #17824a;
        background-color: #baf3d3
      }

      .list-group-item-success.list-group-item-action:focus,
      .list-group-item-success.list-group-item-action:hover {
        color: #17824a;
        background-color: #a4efc5
      }

      .list-group-item-success.list-group-item-action.active {
        color: #fdffff;
        background-color: #17824a;
        border-color: #17824a
      }

      .list-group-item-info {
        color: #107f8f;
        background-color: #b6f2f9
      }

      .list-group-item-info.list-group-item-action:focus,
      .list-group-item-info.list-group-item-action:hover {
        color: #107f8f;
        background-color: #9eeef7
      }

      .list-group-item-info.list-group-item-action.active {
        color: #fdffff;
        background-color: #107f8f;
        border-color: #107f8f
      }

      .list-group-item-warning {
        color: #956639;
        background-color: #fee4ca
      }

      .list-group-item-warning.list-group-item-action:focus,
      .list-group-item-warning.list-group-item-action:hover {
        color: #956639;
        background-color: #fed7b1
      }

      .list-group-item-warning.list-group-item-action.active {
        color: #fdffff;
        background-color: #956639;
        border-color: #956639
      }

      .list-group-item-danger {
        color: #87392e;
        background-color: #f6cbc4
      }

      .list-group-item-danger.list-group-item-action:focus,
      .list-group-item-danger.list-group-item-action:hover {
        color: #87392e;
        background-color: #f3b8ae
      }

      .list-group-item-danger.list-group-item-action.active {
        color: #fdffff;
        background-color: #87392e;
        border-color: #87392e
      }

      .list-group-item-light {
        color: #909496;
        background-color: #fbfcfc
      }

      .list-group-item-light.list-group-item-action:focus,
      .list-group-item-light.list-group-item-action:hover {
        color: #909496;
        background-color: #ecf1f1
      }

      .list-group-item-light.list-group-item-action.active {
        color: #fdffff;
        background-color: #909496;
        border-color: #909496
      }

      .list-group-item-dark {
        color: #757679;
        background-color: #eceded
      }

      .list-group-item-dark.list-group-item-action:focus,
      .list-group-item-dark.list-group-item-action:hover {
        color: #757679;
        background-color: #dfe1e1
      }

      .list-group-item-dark.list-group-item-action.active {
        color: #fdffff;
        background-color: #757679;
        border-color: #757679
      }

      .close {
        float: right;
        font-size: 1.5rem;
        font-weight: 700;
        line-height: 1;
        color: #22292f;
        text-shadow: 0 1px 0 #fdffff;
        opacity: .5
      }

      .close:hover {
        color: #22292f;
        text-decoration: none
      }

      .close:not(:disabled):not(.disabled):focus,
      .close:not(:disabled):not(.disabled):hover {
        opacity: .75
      }

      button.close {
        padding: 0;
        background-color: transparent;
        border: 0
      }

      a.close.disabled {
        pointer-events: none
      }

      .toast {
        flex-basis: 350px;
        max-width: 350px;
        font-size: .875rem;
        background-color: rgba(253, 255, 255, .85);
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, .1);
        box-shadow: 0 .25rem .75rem rgba(34, 41, 47, .1);
        opacity: 0;
        border-radius: .25rem
      }

      .toast:not(:last-child) {
        margin-bottom: .75rem
      }

      .toast.showing {
        opacity: 1
      }

      .toast.show {
        display: block;
        opacity: 1
      }

      .toast.hide {
        display: none
      }

      .toast-header {
        display: flex;
        align-items: center;
        padding: .25rem .75rem;
        color: #b8c2cc;
        background-color: rgba(253, 255, 255, .85);
        background-clip: padding-box;
        border-bottom: 1px solid rgba(0, 0, 0, .05);
        border-top-left-radius: calc(.25rem - 1px);
        border-top-right-radius: calc(.25rem - 1px)
      }

      .toast-body {
        padding: .75rem
      }

      .modal-open {
        overflow: hidden
      }

      .modal-open .modal {
        overflow-x: hidden;
        overflow-y: auto
      }

      .modal {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1050;
        display: none;
        width: 100%;
        height: 100%;
        overflow: hidden;
        outline: 0
      }

      .modal-dialog {
        position: relative;
        width: auto;
        margin: .5rem;
        pointer-events: none
      }

      .modal.fade .modal-dialog {
        transition: transform .3s ease-out;
        transform: translateY(-50px)
      }

      @media(prefers-reduced-motion:reduce) {
        .modal.fade .modal-dialog {
          transition: none
        }
      }

      .modal.show .modal-dialog {
        transform: none
      }

      .modal.modal-static .modal-dialog {
        transform: scale(1.02)
      }

     

      .modal-dialog-centered {
        display: flex;
        align-items: center;
        min-height: calc(100% - 1rem)
      }

      .modal-dialog-centered:before {
        display: block;
        height: calc(100vh - 1rem);
        height: -moz-min-content;
        height: min-content;
        content: ""
      }

     

      .modal-content {
        position: relative;
        display: flex;
        flex-direction: column;
        width: 100%;
        pointer-events: auto;
        background-color: #fdffff;
        background-clip: padding-box;
        border: 1px solid rgba(34, 41, 47, .2);
        border-radius: .3rem;
        outline: 0
      }

      

      .modal-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        padding: 1rem;
        border-bottom: 1px solid #dae1e7;
        border-top-left-radius: calc(.3rem - 1px);
        border-top-right-radius: calc(.3rem - 1px)
      }

      .modal-header .close {
        padding: 1rem;
        margin: -1rem -1rem -1rem auto
      }

      .modal-title {
        margin-bottom: 0;
        line-height: 1.5
      }

      .modal-body {
        position: relative;
        flex: 1 1 auto;
        padding: 1rem
      }

      .modal-footer {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: flex-end;
        padding: .75rem;
        border-top: 1px solid #dae1e7;
        border-bottom-right-radius: calc(.3rem - 1px);
        border-bottom-left-radius: calc(.3rem - 1px)
      }

      .modal-footer>* {
        margin: .25rem
      }

     

      @media(min-width:576px) {
        .modal-dialog {
          max-width: 500px;
          margin: 1.75rem auto
        }

       

      
        .modal-dialog-centered {
          min-height: calc(100% - 3.5rem)
        }

        .modal-dialog-centered:before {
          height: calc(100vh - 3.5rem);
          height: -moz-min-content;
          height: min-content
        }

        .modal-sm {
          max-width: 300px
        }
      }

      @media(min-width:992px) {

        .modal-lg,
        .modal-xl {
          max-width: 800px
        }
      }

      @media(min-width:1200px) {
        .modal-xl {
          max-width: 1140px
        }
      }

      

      .popover {
        top: 0;
        left: 0;
        z-index: 1060;
        max-width: 276px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        font-style: normal;
        font-weight: 400;
        line-height: 1.5;
        text-align: left;
        text-align: start;
        text-decoration: none;
        text-shadow: none;
        text-transform: none;
        letter-spacing: normal;
        word-break: normal;
        white-space: normal;
        word-spacing: normal;
        line-break: auto;
        font-size: .875rem;
        word-wrap: break-word;
        background-color: #fdffff;
        background-clip: padding-box;
        border: 1px solid rgba(34, 41, 47, .2);
        border-radius: .3rem
      }

      .popover,
      .popover .arrow {
        position: absolute;
        display: block
      }

      .popover .arrow {
        width: 1rem;
        height: .5rem;
        margin: 0 .3rem
      }

      .popover .arrow:after,
      .popover .arrow:before {
        position: absolute;
        display: block;
        content: "";
        border-color: transparent;
        border-style: solid
      }

      .b-popover-danger.bs-popover-auto[x-placement^=top],
      .b-popover-dark.bs-popover-auto[x-placement^=top],
      .b-popover-info.bs-popover-auto[x-placement^=top],
      .b-popover-light.bs-popover-auto[x-placement^=top],
      .b-popover-primary.bs-popover-auto[x-placement^=top],
      .b-popover-secondary.bs-popover-auto[x-placement^=top],
      .b-popover-success.bs-popover-auto[x-placement^=top],
      .b-popover-warning.bs-popover-auto[x-placement^=top],
      .bs-popover-auto[x-placement^=top],
      .bs-popover-top {
        margin-bottom: .5rem
      }

      .bs-popover-auto[x-placement^=top]>.arrow,
      .bs-popover-top>.arrow {
        bottom: calc(-.5rem - 1px)
      }

      .bs-popover-auto[x-placement^=top]>.arrow:before,
      .bs-popover-top>.arrow:before {
        bottom: 0;
        border-width: .5rem .5rem 0;
        border-top-color: rgba(34, 41, 47, .25)
      }

      .bs-popover-auto[x-placement^=top]>.arrow:after,
      .bs-popover-top>.arrow:after {
        bottom: 1px;
        border-width: .5rem .5rem 0;
        border-top-color: #fdffff
      }

      .b-popover-danger.bs-popover-auto[x-placement^=right],
      .b-popover-dark.bs-popover-auto[x-placement^=right],
      .b-popover-info.bs-popover-auto[x-placement^=right],
      .b-popover-light.bs-popover-auto[x-placement^=right],
      .b-popover-primary.bs-popover-auto[x-placement^=right],
      .b-popover-secondary.bs-popover-auto[x-placement^=right],
      .b-popover-success.bs-popover-auto[x-placement^=right],
      .b-popover-warning.bs-popover-auto[x-placement^=right],
      .bs-popover-auto[x-placement^=right],
      .bs-popover-right {
        margin-left: .5rem
      }

      .bs-popover-auto[x-placement^=right]>.arrow,
      .bs-popover-right>.arrow {
        left: calc(-.5rem - 1px);
        width: .5rem;
        height: 1rem;
        margin: .3rem 0
      }

      .bs-popover-auto[x-placement^=right]>.arrow:before,
      .bs-popover-right>.arrow:before {
        left: 0;
        border-width: .5rem .5rem .5rem 0;
        border-right-color: rgba(34, 41, 47, .25)
      }

      .bs-popover-auto[x-placement^=right]>.arrow:after,
      .bs-popover-right>.arrow:after {
        left: 1px;
        border-width: .5rem .5rem .5rem 0;
        border-right-color: #fdffff
      }

      .b-popover-danger.bs-popover-auto[x-placement^=bottom],
      .b-popover-dark.bs-popover-auto[x-placement^=bottom],
      .b-popover-info.bs-popover-auto[x-placement^=bottom],
      .b-popover-light.bs-popover-auto[x-placement^=bottom],
      .b-popover-primary.bs-popover-auto[x-placement^=bottom],
      .b-popover-secondary.bs-popover-auto[x-placement^=bottom],
      .b-popover-success.bs-popover-auto[x-placement^=bottom],
      .b-popover-warning.bs-popover-auto[x-placement^=bottom],
      .bs-popover-auto[x-placement^=bottom],
      .bs-popover-bottom {
        margin-top: .5rem
      }

      .bs-popover-auto[x-placement^=bottom]>.arrow,
      .bs-popover-bottom>.arrow {
        top: calc(-.5rem - 1px)
      }

      .bs-popover-auto[x-placement^=bottom]>.arrow:before,
      .bs-popover-bottom>.arrow:before {
        top: 0;
        border-width: 0 .5rem .5rem;
        border-bottom-color: rgba(34, 41, 47, .25)
      }

      .bs-popover-auto[x-placement^=bottom]>.arrow:after,
      .bs-popover-bottom>.arrow:after {
        top: 1px;
        border-width: 0 .5rem .5rem;
        border-bottom-color: #fdffff
      }

      .bs-popover-auto[x-placement^=bottom] .popover-header:before,
      .bs-popover-bottom .popover-header:before {
        position: absolute;
        top: 0;
        left: 50%;
        display: block;
        width: 1rem;
        margin-left: -.5rem;
        content: "";
        border-bottom: 1px solid #eff
      }

      .b-popover-danger.bs-popover-auto[x-placement^=left],
      .b-popover-dark.bs-popover-auto[x-placement^=left],
      .b-popover-info.bs-popover-auto[x-placement^=left],
      .b-popover-light.bs-popover-auto[x-placement^=left],
      .b-popover-primary.bs-popover-auto[x-placement^=left],
      .b-popover-secondary.bs-popover-auto[x-placement^=left],
      .b-popover-success.bs-popover-auto[x-placement^=left],
      .b-popover-warning.bs-popover-auto[x-placement^=left],
      .bs-popover-auto[x-placement^=left],
      .bs-popover-left {
        margin-right: .5rem
      }

      .bs-popover-auto[x-placement^=left]>.arrow,
      .bs-popover-left>.arrow {
        right: calc(-.5rem - 1px);
        width: .5rem;
        height: 1rem;
        margin: .3rem 0
      }

      .bs-popover-auto[x-placement^=left]>.arrow:before,
      .bs-popover-left>.arrow:before {
        right: 0;
        border-width: .5rem 0 .5rem .5rem;
        border-left-color: rgba(34, 41, 47, .25)
      }

      .bs-popover-auto[x-placement^=left]>.arrow:after,
      .bs-popover-left>.arrow:after {
        right: 1px;
        border-width: .5rem 0 .5rem .5rem;
        border-left-color: #fdffff
      }

      .popover-header {
        padding: .5rem .75rem;
        margin-bottom: 0;
        font-size: 1rem;
        background-color: #eff;
        border-bottom: 1px solid #d4ffff;
        border-top-left-radius: calc(.3rem - 1px);
        border-top-right-radius: calc(.3rem - 1px)
      }

      .popover-header:empty {
        display: none
      }
	  
	 @media  only screen and (min-width: 960px) {
.hidedesktop{display:none;}
}
}

@media  screen and (max-width: 600px) {
  .hidemobile {
    display:none;
  }
  
  
}


      .popover-body {
        padding: .5rem .75rem;
        color: #2a2e30
      }

      .carousel {
    position: relative;
    margin: -15px -21px 0;
	
}
.carousel.pointer-event {
    touch-action: pan-y
}
.carousel-inner {
    position: relative;
    width: 100%;
    overflow: hidden
}
.carousel-inner:after {
    display: block;
    clear: both;
    content: ""
}
.carousel-item {
    position: relative;
    display: none;
    float: left;
    width: 100%;
    margin-right: -100%;
    backface-visibility: hidden;
    transition: transform .6s ease-in-out
}
@media(prefers-reduced-motion:reduce) {
    .carousel-item {
        transition: none
    }
}
.carousel-item-next,
.carousel-item-prev,
.carousel-item.active {
    display: block
}
.active.carousel-item-right,
.carousel-item-next:not(.carousel-item-left) {
    transform: translateX(100%)
}
.active.carousel-item-left,
.carousel-item-prev:not(.carousel-item-right) {
    transform: translateX(-100%)
}
.carousel-fade .carousel-item {
    opacity: 0;
    transition-property: opacity;
    transform: none
}
.carousel-fade .carousel-item-next.carousel-item-left,
.carousel-fade .carousel-item-prev.carousel-item-right,
.carousel-fade .carousel-item.active {
    z-index: 1;
    opacity: 1
}
.carousel-fade .active.carousel-item-left,
.carousel-fade .active.carousel-item-right {
    z-index: 0;
    opacity: 0;
    transition: opacity 0s .6s
}
@media(prefers-reduced-motion:reduce) {
    .carousel-fade .active.carousel-item-left,
    .carousel-fade .active.carousel-item-right {
        transition: none
    }
}
.carousel-control-next,
.carousel-control-prev {
    position: absolute;
    top: 0;
    bottom: 0;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 15%;
    padding: 0;
    color: #fdffff;
    text-align: center;
    background: none;
    border: 0;
    opacity: .5;
    transition: opacity .15s ease
}
@media(prefers-reduced-motion:reduce) {
    .carousel-control-next,
    .carousel-control-prev {
        transition: none
    }
}
.carousel-control-next:focus,
.carousel-control-next:hover,
.carousel-control-prev:focus,
.carousel-control-prev:hover {
    color: #fdffff;
    text-decoration: none;
    outline: 0;
    opacity: .9
}
.carousel-control-prev {
    left: 0
}
.carousel-control-next {
    right: 0
}
.carousel-control-next-icon,
.carousel-control-prev-icon {
    display: inline-block;
    width: 20px;
    height: 20px;
    background: 50%/100% 100% no-repeat
}
.carousel-control-prev-icon {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fdffff' width='8' height='8'%3E%3Cpath d='M5.25 0l-4 4 4 4 1.5-1.5L4.25 4l2.5-2.5L5.25 0z'/%3E%3C/svg%3E")
}
.carousel-control-next-icon {
    background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fdffff' width='8' height='8'%3E%3Cpath d='M2.75 0l-1.5 1.5L3.75 4l-2.5 2.5L2.75 8l4-4-4-4z'/%3E%3C/svg%3E")
}
.carousel-indicators {
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 15;
    display: flex;
    justify-content: center;
    padding-left: 0;
    margin-right: 15%;
    margin-left: 15%;
    list-style: none
}
.carousel-indicators li {
    box-sizing: content-box;
    flex: 0 1 auto;
    width: 30px;
    height: 3px;
    margin-right: 3px;
    margin-left: 3px;
    text-indent: -999px;
    cursor: pointer;
    background-color: #fdffff;
    background-clip: padding-box;
    border-top: 10px solid transparent;
    border-bottom: 10px solid transparent;
    opacity: .5;
    transition: opacity .6s ease
}
@media(prefers-reduced-motion:reduce) {
    .carousel-indicators li {
        transition: none
    }
}
.carousel-indicators .active {
    opacity: 1
}
.carousel-caption {
    position: absolute;
    right: 15%;
    bottom: 20px;
    left: 15%;
    z-index: 10;
    padding-top: 20px;
    padding-bottom: 20px;
    color: #fdffff;
    text-align: center
}
@keyframes  spinner-border {
    to {
        transform: rotate(1turn)
    }
}
.spinner-border {
    display: inline-block;
    width: 2rem;
    height: 2rem;
    vertical-align: -.125em;
    border: .25em solid;
    border-right: .25em solid transparent;
    border-radius: 50%;
    animation: spinner-border .75s linear infinite
}
.spinner-border-sm {
    width: 1rem;
    height: 1rem;
    border-width: .2em
}

      @keyframes  spinner-grow {
        0% {
          transform: scale(0)
        }

        50% {
          opacity: 1;
          transform: none
        }
      }

      .spinner-grow {
        display: inline-block;
        width: 2rem;
        height: 2rem;
        vertical-align: -.125em;
        background-color: currentcolor;
        border-radius: 50%;
        opacity: 0;
        animation: spinner-grow .75s linear infinite
      }

      .spinner-grow-sm {
        width: 1rem;
        height: 1rem
      }

      @media(prefers-reduced-motion:reduce) {

        .spinner-border,
        .spinner-grow {
          animation-duration: 1.5s
        }
      }

      .align-baseline {
        vertical-align: baseline !important
      }

      .align-top {
        vertical-align: top !important
      }

      .align-middle {
        vertical-align: middle !important
      }

      .align-bottom {
        vertical-align: bottom !important
      }

      .align-text-bottom {
        vertical-align: text-bottom !important
      }

      .align-text-top {
        vertical-align: text-top !important
      }

      .bg-primary {
        background-color: #fff !important
      }

      a.bg-primary:focus,
      a.bg-primary:hover,
      button.bg-primary:focus,
      button.bg-primary:hover {
        background-color: #e6e6e6 !important
      }

      .bg-secondary {
        background-color: #fff !important
      }

      a.bg-secondary:focus,
      a.bg-secondary:hover,
      button.bg-secondary:focus,
      button.bg-secondary:hover {
        background-color: #e6e6e6 !important
      }

      .bg-success {
        background-color: #0cd463 !important
      }

      a.bg-success:focus,
      a.bg-success:hover,
      button.bg-success:focus,
      button.bg-success:hover {
        background-color: #09a44c !important
      }

      .bg-info {
        background-color: #00cfe8 !important
      }

      a.bg-info:focus,
      a.bg-info:hover,
      button.bg-info:focus,
      button.bg-info:hover {
        background-color: #00a1b5 !important
      }

      .bg-warning {
        background-color: #ff9f43 !important
      }

      a.bg-warning:focus,
      a.bg-warning:hover,
      button.bg-warning:focus,
      button.bg-warning:hover {
        background-color: #ff8510 !important
      }

      .bg-danger {
        background-color: #e5472e !important
      }

      a.bg-danger:focus,
      a.bg-danger:hover,
      button.bg-danger:focus,
      button.bg-danger:hover {
        background-color: #c73119 !important
      }

      .bg-light {
        background-color: #f6f6f6 !important
      }

      a.bg-light:focus,
      a.bg-light:hover,
      button.bg-light:focus,
      button.bg-light:hover {
        background-color: #ddd !important
      }

      .bg-dark {
        background-color: #c2bdbd !important
      }

      a.bg-dark:focus,
      a.bg-dark:hover,
      button.bg-dark:focus,
      button.bg-dark:hover {
        background-color: #aaa2a2 !important
      }

      .bg-white {
        background-color: #fdffff !important
      }

      .bg-transparent {
        background-color: transparent !important
      }

      .border {
        border: 1px solid #dae1e7 !important
      }

      .border-top {
        border-top: 1px solid #dae1e7 !important
      }

      .border-right {
        border-right: 1px solid #dae1e7 !important
      }

      .border-bottom {
        border-bottom: 1px solid #dae1e7 !important
      }

      .border-left {
        border-left: 1px solid #dae1e7 !important
      }

      .border-0 {
        border: 0 !important
      }

      .border-top-0 {
        border-top: 0 !important
      }

      .border-right-0 {
        border-right: 0 !important
      }

      .border-bottom-0 {
        border-bottom: 0 !important
      }

      .border-left-0 {
        border-left: 0 !important
      }

      .border-primary,
      .border-secondary {
        border-color: #fff !important
      }

      .border-success {
        border-color: #0cd463 !important
      }

      .border-info {
        border-color: #00cfe8 !important
      }

      .border-warning {
        border-color: #ff9f43 !important
      }

      .border-danger {
        border-color: #e5472e !important
      }

      .border-light {
        border-color: #f6f6f6 !important
      }

      .border-dark {
        border-color: #c2bdbd !important
      }

      .border-white {
        border-color: #fdffff !important
      }

      .rounded-sm {
        border-radius: .2rem !important
      }

      .rounded {
        border-radius: .25rem !important
      }

      .rounded-top {
        border-top-left-radius: .25rem !important
      }

      .rounded-right,
      .rounded-top {
        border-top-right-radius: .25rem !important
      }

      .rounded-bottom,
      .rounded-right {
        border-bottom-right-radius: .25rem !important
      }

      .rounded-bottom,
      .rounded-left {
        border-bottom-left-radius: .25rem !important
      }

      .rounded-left {
        border-top-left-radius: .25rem !important
      }

      .rounded-lg {
        border-radius: .3rem !important
      }

      .rounded-circle {
        border-radius: 50% !important
      }

      .rounded-pill {
        border-radius: 50rem !important
      }

      .rounded-0 {
        border-radius: 0 !important
      }

      .clearfix:after {
        display: block;
        clear: both;
        content: ""
      }

      .d-none {
        display: none !important
      }

      .d-inline {
        display: inline !important
      }

      .d-inline-block {
        display: inline-block !important
      }

      .d-block {
        display: block !important
      }

      .d-table {
        display: table !important
      }

      .d-table-row {
        display: table-row !important
      }

      .d-table-cell {
        display: table-cell !important
      }

      .d-flex {
        display: flex !important
      }

      .d-inline-flex {
        display: inline-flex !important
      }

      @media(min-width:576px) {
        .d-sm-none {
          display: none !important
        }

        .d-sm-inline {
          display: inline !important
        }

        .d-sm-inline-block {
          display: inline-block !important
        }

        .d-sm-block {
          display: block !important
        }

        .d-sm-table {
          display: table !important
        }

        .d-sm-table-row {
          display: table-row !important
        }

        .d-sm-table-cell {
          display: table-cell !important
        }

        .d-sm-flex {
          display: flex !important
        }

        .d-sm-inline-flex {
          display: inline-flex !important
        }
      }

      @media(min-width:768px) {
        .d-md-none {
          display: none !important
        }

        .d-md-inline {
          display: inline !important
        }

        .d-md-inline-block {
          display: inline-block !important
        }

        .d-md-block {
          display: block !important
        }

        .d-md-table {
          display: table !important
        }

        .d-md-table-row {
          display: table-row !important
        }

        .d-md-table-cell {
          display: table-cell !important
        }

        .d-md-flex {
          display: flex !important
        }

        .d-md-inline-flex {
          display: inline-flex !important
        }
      }

      @media(min-width:992px) {
        .d-lg-none {
          display: none !important
        }

        .d-lg-inline {
          display: inline !important
        }

        .d-lg-inline-block {
          display: inline-block !important
        }

        .d-lg-block {
          display: block !important
        }

        .d-lg-table {
          display: table !important
        }

        .d-lg-table-row {
          display: table-row !important
        }

        .d-lg-table-cell {
          display: table-cell !important
        }

        .d-lg-flex {
          display: flex !important
        }

        .d-lg-inline-flex {
          display: inline-flex !important
        }
      }

      @media(min-width:1200px) {
        .d-xl-none {
          display: none !important
        }

        .d-xl-inline {
          display: inline !important
        }

        .d-xl-inline-block {
          display: inline-block !important
        }

        .d-xl-block {
          display: block !important
        }

        .d-xl-table {
          display: table !important
        }

        .d-xl-table-row {
          display: table-row !important
        }

        .d-xl-table-cell {
          display: table-cell !important
        }

        .d-xl-flex {
          display: flex !important
        }

        .d-xl-inline-flex {
          display: inline-flex !important
        }
      }

      @media  print {
        .d-print-none {
          display: none !important
        }

        .d-print-inline {
          display: inline !important
        }

        .d-print-inline-block {
          display: inline-block !important
        }

        .d-print-block {
          display: block !important
        }

        .d-print-table {
          display: table !important
        }

        .d-print-table-row {
          display: table-row !important
        }

        .d-print-table-cell {
          display: table-cell !important
        }

        .d-print-flex {
          display: flex !important
        }

        .d-print-inline-flex {
          display: inline-flex !important
        }
      }

      .embed-responsive {
        position: relative;
        display: block;
        width: 100%;
        padding: 0;
        overflow: hidden
      }

      .embed-responsive:before {
        display: block;
        content: ""
      }

      .embed-responsive .embed-responsive-item,
      .embed-responsive embed,
      .embed-responsive iframe,
      .embed-responsive object,
      .embed-responsive video {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 0
      }

      .embed-responsive-21by9:before {
        padding-top: 42.85714286%
      }

      .embed-responsive-16by9:before {
        padding-top: 56.25%
      }

      .embed-responsive-4by3:before {
        padding-top: 75%
      }

      .embed-responsive-1by1:before {
        padding-top: 100%
      }

      .flex-row {
        flex-direction: row !important
      }

      .flex-column {
        flex-direction: column !important
      }

      .flex-row-reverse {
        flex-direction: row-reverse !important
      }

      .flex-column-reverse {
        flex-direction: column-reverse !important
      }

      .flex-wrap {
        flex-wrap: wrap !important
      }

      .flex-nowrap {
        flex-wrap: nowrap !important
      }

      .flex-wrap-reverse {
        flex-wrap: wrap-reverse !important
      }

      .flex-fill {
        flex: 1 1 auto !important
      }

      .flex-grow-0 {
        flex-grow: 0 !important
      }

      .flex-grow-1 {
        flex-grow: 1 !important
      }

      .flex-shrink-0 {
        flex-shrink: 0 !important
      }

      .flex-shrink-1 {
        flex-shrink: 1 !important
      }

      .justify-content-start {
        justify-content: flex-start !important
      }

      .justify-content-end {
        justify-content: flex-end !important
      }

      .justify-content-center {
        justify-content: center !important
      }

      .justify-content-between {
        justify-content: space-between !important
      }

      .justify-content-around {
        justify-content: space-around !important
      }

      .align-items-start {
        align-items: flex-start !important
      }

      .align-items-end {
        align-items: flex-end !important
      }

      .align-items-center {
        align-items: center !important
      }

      .align-items-baseline {
        align-items: baseline !important
      }

      .align-items-stretch {
        align-items: stretch !important
      }

      .align-content-start {
        align-content: flex-start !important
      }

      .align-content-end {
        align-content: flex-end !important
      }

      .align-content-center {
        align-content: center !important
      }

      .align-content-between {
        align-content: space-between !important
      }

      .align-content-around {
        align-content: space-around !important
      }

      .align-content-stretch {
        align-content: stretch !important
      }

      .align-self-auto {
        align-self: auto !important
      }

      .align-self-start {
        align-self: flex-start !important
      }

      .align-self-end {
        align-self: flex-end !important
      }

      .align-self-center {
        align-self: center !important
      }

      .align-self-baseline {
        align-self: baseline !important
      }

      .align-self-stretch {
        align-self: stretch !important
      }

      @media(min-width:576px) {
        .flex-sm-row {
          flex-direction: row !important
        }

        .flex-sm-column {
          flex-direction: column !important
        }

        .flex-sm-row-reverse {
          flex-direction: row-reverse !important
        }

        .flex-sm-column-reverse {
          flex-direction: column-reverse !important
        }

        .flex-sm-wrap {
          flex-wrap: wrap !important
        }

        .flex-sm-nowrap {
          flex-wrap: nowrap !important
        }

        .flex-sm-wrap-reverse {
          flex-wrap: wrap-reverse !important
        }

        .flex-sm-fill {
          flex: 1 1 auto !important
        }

        .flex-sm-grow-0 {
          flex-grow: 0 !important
        }

        .flex-sm-grow-1 {
          flex-grow: 1 !important
        }

        .flex-sm-shrink-0 {
          flex-shrink: 0 !important
        }

        .flex-sm-shrink-1 {
          flex-shrink: 1 !important
        }

        .justify-content-sm-start {
          justify-content: flex-start !important
        }

        .justify-content-sm-end {
          justify-content: flex-end !important
        }

        .justify-content-sm-center {
          justify-content: center !important
        }

        .justify-content-sm-between {
          justify-content: space-between !important
        }

        .justify-content-sm-around {
          justify-content: space-around !important
        }

        .align-items-sm-start {
          align-items: flex-start !important
        }

        .align-items-sm-end {
          align-items: flex-end !important
        }

        .align-items-sm-center {
          align-items: center !important
        }

        .align-items-sm-baseline {
          align-items: baseline !important
        }

        .align-items-sm-stretch {
          align-items: stretch !important
        }

        .align-content-sm-start {
          align-content: flex-start !important
        }

        .align-content-sm-end {
          align-content: flex-end !important
        }

        .align-content-sm-center {
          align-content: center !important
        }

        .align-content-sm-between {
          align-content: space-between !important
        }

        .align-content-sm-around {
          align-content: space-around !important
        }

        .align-content-sm-stretch {
          align-content: stretch !important
        }

        .align-self-sm-auto {
          align-self: auto !important
        }

        .align-self-sm-start {
          align-self: flex-start !important
        }

        .align-self-sm-end {
          align-self: flex-end !important
        }

        .align-self-sm-center {
          align-self: center !important
        }

        .align-self-sm-baseline {
          align-self: baseline !important
        }

        .align-self-sm-stretch {
          align-self: stretch !important
        }
      }

      @media(min-width:768px) {
        .flex-md-row {
          flex-direction: row !important
        }

        .flex-md-column {
          flex-direction: column !important
        }

        .flex-md-row-reverse {
          flex-direction: row-reverse !important
        }

        .flex-md-column-reverse {
          flex-direction: column-reverse !important
        }

        .flex-md-wrap {
          flex-wrap: wrap !important
        }

        .flex-md-nowrap {
          flex-wrap: nowrap !important
        }

        .flex-md-wrap-reverse {
          flex-wrap: wrap-reverse !important
        }

        .flex-md-fill {
          flex: 1 1 auto !important
        }

        .flex-md-grow-0 {
          flex-grow: 0 !important
        }

        .flex-md-grow-1 {
          flex-grow: 1 !important
        }

        .flex-md-shrink-0 {
          flex-shrink: 0 !important
        }

        .flex-md-shrink-1 {
          flex-shrink: 1 !important
        }

        .justify-content-md-start {
          justify-content: flex-start !important
        }

        .justify-content-md-end {
          justify-content: flex-end !important
        }

        .justify-content-md-center {
          justify-content: center !important
        }

        .justify-content-md-between {
          justify-content: space-between !important
        }

        .justify-content-md-around {
          justify-content: space-around !important
        }

        .align-items-md-start {
          align-items: flex-start !important
        }

        .align-items-md-end {
          align-items: flex-end !important
        }

        .align-items-md-center {
          align-items: center !important
        }

        .align-items-md-baseline {
          align-items: baseline !important
        }

        .align-items-md-stretch {
          align-items: stretch !important
        }

        .align-content-md-start {
          align-content: flex-start !important
        }

        .align-content-md-end {
          align-content: flex-end !important
        }

        .align-content-md-center {
          align-content: center !important
        }

        .align-content-md-between {
          align-content: space-between !important
        }

        .align-content-md-around {
          align-content: space-around !important
        }

        .align-content-md-stretch {
          align-content: stretch !important
        }

        .align-self-md-auto {
          align-self: auto !important
        }

        .align-self-md-start {
          align-self: flex-start !important
        }

        .align-self-md-end {
          align-self: flex-end !important
        }

        .align-self-md-center {
          align-self: center !important
        }

        .align-self-md-baseline {
          align-self: baseline !important
        }

        .align-self-md-stretch {
          align-self: stretch !important
        }
      }

      @media(min-width:992px) {
        .flex-lg-row {
          flex-direction: row !important
        }

        .flex-lg-column {
          flex-direction: column !important
        }

        .flex-lg-row-reverse {
          flex-direction: row-reverse !important
        }

        .flex-lg-column-reverse {
          flex-direction: column-reverse !important
        }

        .flex-lg-wrap {
          flex-wrap: wrap !important
        }

        .flex-lg-nowrap {
          flex-wrap: nowrap !important
        }

        .flex-lg-wrap-reverse {
          flex-wrap: wrap-reverse !important
        }

        .flex-lg-fill {
          flex: 1 1 auto !important
        }

        .flex-lg-grow-0 {
          flex-grow: 0 !important
        }

        .flex-lg-grow-1 {
          flex-grow: 1 !important
        }

        .flex-lg-shrink-0 {
          flex-shrink: 0 !important
        }

        .flex-lg-shrink-1 {
          flex-shrink: 1 !important
        }

        .justify-content-lg-start {
          justify-content: flex-start !important
        }

        .justify-content-lg-end {
          justify-content: flex-end !important
        }

        .justify-content-lg-center {
          justify-content: center !important
        }

        .justify-content-lg-between {
          justify-content: space-between !important
        }

        .justify-content-lg-around {
          justify-content: space-around !important
        }

        .align-items-lg-start {
          align-items: flex-start !important
        }

        .align-items-lg-end {
          align-items: flex-end !important
        }

        .align-items-lg-center {
          align-items: center !important
        }

        .align-items-lg-baseline {
          align-items: baseline !important
        }

        .align-items-lg-stretch {
          align-items: stretch !important
        }

        .align-content-lg-start {
          align-content: flex-start !important
        }

        .align-content-lg-end {
          align-content: flex-end !important
        }

        .align-content-lg-center {
          align-content: center !important
        }

        .align-content-lg-between {
          align-content: space-between !important
        }

        .align-content-lg-around {
          align-content: space-around !important
        }

        .align-content-lg-stretch {
          align-content: stretch !important
        }

        .align-self-lg-auto {
          align-self: auto !important
        }

        .align-self-lg-start {
          align-self: flex-start !important
        }

        .align-self-lg-end {
          align-self: flex-end !important
        }

        .align-self-lg-center {
          align-self: center !important
        }

        .align-self-lg-baseline {
          align-self: baseline !important
        }

        .align-self-lg-stretch {
          align-self: stretch !important
        }
      }

      @media(min-width:1200px) {
        .flex-xl-row {
          flex-direction: row !important
        }

        .flex-xl-column {
          flex-direction: column !important
        }

        .flex-xl-row-reverse {
          flex-direction: row-reverse !important
        }

        .flex-xl-column-reverse {
          flex-direction: column-reverse !important
        }

        .flex-xl-wrap {
          flex-wrap: wrap !important
        }

        .flex-xl-nowrap {
          flex-wrap: nowrap !important
        }

        .flex-xl-wrap-reverse {
          flex-wrap: wrap-reverse !important
        }

        .flex-xl-fill {
          flex: 1 1 auto !important
        }

        .flex-xl-grow-0 {
          flex-grow: 0 !important
        }

        .flex-xl-grow-1 {
          flex-grow: 1 !important
        }

        .flex-xl-shrink-0 {
          flex-shrink: 0 !important
        }

        .flex-xl-shrink-1 {
          flex-shrink: 1 !important
        }

        .justify-content-xl-start {
          justify-content: flex-start !important
        }

        .justify-content-xl-end {
          justify-content: flex-end !important
        }

        .justify-content-xl-center {
          justify-content: center !important
        }

        .justify-content-xl-between {
          justify-content: space-between !important
        }

        .justify-content-xl-around {
          justify-content: space-around !important
        }

        .align-items-xl-start {
          align-items: flex-start !important
        }

        .align-items-xl-end {
          align-items: flex-end !important
        }

        .align-items-xl-center {
          align-items: center !important
        }

        .align-items-xl-baseline {
          align-items: baseline !important
        }

        .align-items-xl-stretch {
          align-items: stretch !important
        }

        .align-content-xl-start {
          align-content: flex-start !important
        }

        .align-content-xl-end {
          align-content: flex-end !important
        }

        .align-content-xl-center {
          align-content: center !important
        }

        .align-content-xl-between {
          align-content: space-between !important
        }

        .align-content-xl-around {
          align-content: space-around !important
        }

        .align-content-xl-stretch {
          align-content: stretch !important
        }

        .align-self-xl-auto {
          align-self: auto !important
        }

        .align-self-xl-start {
          align-self: flex-start !important
        }

        .align-self-xl-end {
          align-self: flex-end !important
        }

        .align-self-xl-center {
          align-self: center !important
        }

        .align-self-xl-baseline {
          align-self: baseline !important
        }

        .align-self-xl-stretch {
          align-self: stretch !important
        }
      }

      .float-left {
        float: left !important
      }

      .float-right {
        float: right !important
      }

      .float-none {
        float: none !important
      }

      @media(min-width:576px) {
        .float-sm-left {
          float: left !important
        }

        .float-sm-right {
          float: right !important
        }

        .float-sm-none {
          float: none !important
        }
      }

      @media(min-width:768px) {
        .float-md-left {
          float: left !important
        }

        .float-md-right {
          float: right !important
        }

        .float-md-none {
          float: none !important
        }
      }

      @media(min-width:992px) {
        .float-lg-left {
          float: left !important
        }

        .float-lg-right {
          float: right !important
        }

        .float-lg-none {
          float: none !important
        }
      }

      @media(min-width:1200px) 
      .overflow-auto {
        overflow: auto !important
      }

      .overflow-hidden {
        overflow: hidden !important
      }

      .position-static {
        position: static !important
      }

      .position-relative {
        position: relative !important
      }

      .position-absolute {
        position: absolute !important
      }

      .position-fixed {
        position: fixed !important
      }

      .position-sticky {
        position: sticky !important
      }

      .fixed-top {
        top: 0
      }

      .fixed-bottom,
      .fixed-top {
        position: fixed;
        right: 0;
        left: 0;
        z-index: 1030
      }

      .fixed-bottom {
        bottom: 0
      }

      @supports(position:sticky) {
        .sticky-top {
          position: sticky;
          top: 0;
          z-index: 1020
        }
      }

      .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0
      }

      .sr-only-focusable:active,
      .sr-only-focusable:focus {
        position: static;
        width: auto;
        height: auto;
        overflow: visible;
        clip: auto;
        white-space: normal
      }

      .shadow-sm {
        box-shadow: 0 .125rem .25rem rgba(34, 41, 47, .075) !important
      }

      .shadow {
        box-shadow: 0 .5rem 1rem rgba(34, 41, 47, .15) !important
      }

      .shadow-lg {
        box-shadow: 0 1rem 3rem rgba(34, 41, 47, .175) !important
      }

      .shadow-none {
        box-shadow: none !important
      }

    
 
      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-cylon-vertical,
        .b-icon.b-iconstack .b-icon-animation-cylon-vertical>g {
          animation: none
        }
      }

      .b-icon.b-icon-animation-fade,
      .b-icon.b-iconstack .b-icon-animation-fade>g {
        transform-origin: center;
        animation: b-icon-animation-fade .75s ease-in-out infinite alternate
      }

      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-fade,
        .b-icon.b-iconstack .b-icon-animation-fade>g {
          animation: none
        }
      }

      .b-icon.b-icon-animation-spin,
      .b-icon.b-iconstack .b-icon-animation-spin>g {
        transform-origin: center;
        animation: b-icon-animation-spin 2s linear infinite normal
      }

      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-spin,
        .b-icon.b-iconstack .b-icon-animation-spin>g {
          animation: none
        }
      }

      .b-icon.b-icon-animation-spin-reverse,
      .b-icon.b-iconstack .b-icon-animation-spin-reverse>g {
        transform-origin: center;
        animation: b-icon-animation-spin 2s linear infinite reverse
      }

      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-spin-reverse,
        .b-icon.b-iconstack .b-icon-animation-spin-reverse>g {
          animation: none
        }
      }

      .b-icon.b-icon-animation-spin-pulse,
      .b-icon.b-iconstack .b-icon-animation-spin-pulse>g {
        transform-origin: center;
        animation: b-icon-animation-spin 1s steps(8) infinite normal
      }

      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-spin-pulse,
        .b-icon.b-iconstack .b-icon-animation-spin-pulse>g {
          animation: none
        }
      }

      .b-icon.b-icon-animation-spin-reverse-pulse,
      .b-icon.b-iconstack .b-icon-animation-spin-reverse-pulse>g {
        transform-origin: center;
        animation: b-icon-animation-spin 1s steps(8) infinite reverse
      }

      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-spin-reverse-pulse,
        .b-icon.b-iconstack .b-icon-animation-spin-reverse-pulse>g {
          animation: none
        }
      }

      .b-icon.b-icon-animation-throb,
      .b-icon.b-iconstack .b-icon-animation-throb>g {
        transform-origin: center;
        animation: b-icon-animation-throb .75s ease-in-out infinite alternate
      }

      @media(prefers-reduced-motion:reduce) {

        .b-icon.b-icon-animation-throb,
        .b-icon.b-iconstack .b-icon-animation-throb>g {
          animation: none
        }
      }

      @keyframes  b-icon-animation-cylon {
        0% {
          transform: translateX(-25%)
        }

        to {
          transform: translateX(25%)
        }
      }

      @keyframes  b-icon-animation-cylon-vertical {
        0% {
          transform: translateY(25%)
        }

        to {
          transform: translateY(-25%)
        }
      }

      @keyframes  b-icon-animation-fade {
        0% {
          opacity: .1
        }

        to {
          opacity: 1
        }
      }

      @keyframes  b-icon-animation-spin {
        0% {
          transform: rotate(0deg)
        }

        to {
          transform: rotate(359deg)
        }
      }

      @keyframes  b-icon-animation-throb {
        0% {
          opacity: .5;
          transform: scale(.5)
        }

        to {
          opacity: 1;
          transform: scale(1)
        }
      }

     

      .alert {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: .8rem;
        border: 0;
        padding: .7rem 1rem;
        font-weight: 500;
        font-size: .9rem;
        line-height: 1.2;
        background: transparent
      }

      .alert:after {
        content: "";
        position: absolute;
        border-radius: 5px;
        width: 100%;
        height: 100%;
        background: currentColor;
        opacity: .12;
        top: 0;
        left: 0;
        transition: .2s ease-in-out
      }

      .alert.alert-dismissible .close {
        position: relative;
        padding: 0;
        opacity: 1;
        color: inherit;
        text-shadow: none
      }

      .alert .alert-icon {
        font-size: 1.3em
      }

      .alert.alert-primary {
        color: #CF5AFF
      }

      .alert.alert-secondary {
        color: #82868b
      }

      .alert.alert-success {
        color: #0cd463
      }

      .alert.alert-danger {
        color: #f1416c
      }

      .alert.alert-warning {
        color: #ff9f43
      }

      .alert.alert-info {
        color: #009ef7
      }

      .alert.alert-light {
        color: var(--color-light)
      }

      .alert.alert-dark {
        color: var(--color-dark)
      }

      .alert .alert-body {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: .5rem
      }

      .alert .alert-body span {
        padding: 0 1rem
      }

      .alert .alert-body span b {
        font-weight: 700
      }

      .alert .alert-body span small {
        display: flex;
        margin-top: .6rem;
        font-size: .8em
      }

      .btn {
        font-weight: 600;
        display: inline-flex;
        flex-direction: row;
        flex-wrap: nowrap;
        gap: .5rem;
        justify-content: center;
        align-items: center
      }

      .btn:focus {
        outline: none;
        box-shadow: unset
      }

      .btn.btn-default {
        color: #adadad
      }

      .btn-group-sm>.btn.btn-primary,
      .btn.btn-primary.btn-sm {
        font-weight: 700
      }

      .btn.btn-primary a {
        color: var(--background-secondary)
      }

      .button--green {
        display: inline-block;
        border-radius: 4px;
        border: 1px solid #3b8070;
        color: #3b8070;
        text-decoration: none;
        padding: 10px 30px
      }

      .button--green:hover {
        color: #fff;
        background-color: #3b8070
      }

      .button--grey {
        display: inline-block;
        border-radius: 4px;
        border: 1px solid #35495e;
        color: #35495e;
        text-decoration: none;
        padding: 10px 30px;
        margin-left: 15px
      }

      .button--grey:hover {
        color: #fff;
        background-color: #35495e
      }

      .btn-primary {
        background-color: #CF5AFF;
        border-color: #CF5AFF
      }

      .btn-primary.focus,
      .btn-primary:focus,
      .btn-primary:hover {
        background-color: #CF5AFF;
        border-color: #CF5AFF;
        opacity: .9
      }

      .btn-primary.focus,
      .btn-primary:focus {
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

      

      .btn-outline-primary {
        color: #CF5AFF;
        border-color: #CF5AFF
      }

      .btn-outline-primary:hover {
        background-color: #CF5AFF;
        border-color: #CF5AFF
      }

      .btn-outline-primary.focus,
      .btn-outline-primary:focus {
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

      .btn-outline-primary.disabled,
      .btn-outline-primary:disabled {
        color: #CF5AFF;
        background-color: transparent
      }

      

      .btn-secondary {
        background-color: transparent;
        border-color: transparent;
        color: #CF5AFF;
        position: relative;
        transition: .2s ease-in-out
      }

      .btn-secondary:after {
        content: "";
        position: absolute;
        border-radius: 5px;
        width: 100%;
        height: 100%;
        background: currentColor;
        opacity: .15;
        top: 0;
        left: 0;
        transition: .2s ease-in-out
      }

      .btn-secondary:active,
      .btn-secondary:focus,
      .btn-secondary:hover {
        background: transparent !important;
        color: #CF5AFF !important;
        border-color: transparent !important
      }

      .btn-secondary:active:after,
      .btn-secondary:focus:after,
      .btn-secondary:hover:after {
        opacity: .1
      }

      .btn-secondary.focus,
      .btn-secondary:focus {
        opacity: .9;
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

    

      .btn-outline-secondary {
        color: #82868b;
        border-color: #82868b
      }

      .btn-outline-secondary:hover {
        background-color: #82868b;
        border-color: #82868b
      }

      .btn-outline-secondary.focus,
      .btn-outline-secondary:focus {
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

      .btn-outline-secondary.disabled,
      .btn-outline-secondary:disabled {
        color: #82868b;
        background-color: transparent
      }

      

      .card {
        background: var(--background-secondary);
        border-color: var(--background-secondary);
        margin-bottom: 2rem
      }

      @media(max-width:768px) {
        .card {
          margin-bottom: 1rem
        }
      }

      .card .card-header {
        background: transparent;
        padding-bottom: 0;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        margin: .75rem 0 0
      }

      .card .card-header .card-header__title h3 {
        font-size: 1.2rem;
        font-weight: 700;
        color: #adadad;
        margin-bottom: 0
      }

      .card .card-header .card-title {
        margin-bottom: 0;
        margin-top: 0;
        font-weight: 700;
        color: #CF5AFF
      }

      .card .card-header .card-header__actions {
        display: flex;
        font-size: .8rem;
        color: #adadad
      }

      .card .card-header .card-header__actions .btn {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: .4rem;
        margin-left: .5rem
      }

      .card .card-header .card-header__actions .btn span {
        font-size: .8em;
        font-weight: 500;
        text-transform: uppercase;
        margin-left: .5rem
      }

      .card.card-table .card-body {
        padding: 0
      }

      .card.card-table .card-body header {
        padding: .71rem
      }

     

      .modal {
        z-index: 3000
      }

      @media(max-width:768px) {
        .modal {
          padding: 0 !important
        }
      }

      @media(max-width:768px) {
        .modal.modal-h-full .modal-dialog {
          align-items: stretch;
          margin: 0;
          min-height: 100%;
          min-width: 100%
        }
      }

      .modal .modal-dialog {
        margin: 1rem auto 0
      }

      .modal .modal-content {
        position: relative;
        margin: 0 1rem;
        background-color: var(--background-primary);
        padding: 0;
        border-radius: 5px;
        box-shadow: 0 0 20px rgba(0, 0, 0, .5)
      }

      @media(max-width:768px) {
        .modal .modal-content {
          min-height: 100%;
          height: auto;
          margin: 0;
          border-radius: 0
        }
      }

      @media(min-width:992px) {
        .modal .modal-content {
          margin: 0 1.5rem
        }
      }

      .modal .modal-content .modal-body {
        flex: 0
      }

      @media(min-width:380px) {
        .modal .modal-content .modal-body {
          padding: 1.8rem
        }
      }

      @media(max-width:768px) {
        .modal .modal-content .modal-body {
          display: flex;
          align-items: flex-start;
          justify-content: center
        }
      }

      .modal .modal-content .modal-header {
        border: 0;
        z-index: 10
      }

      @media(min-width:380px) {
        .modal .modal-content .modal-header {
          padding: 1.8rem 1.8rem 0
        }
      }

      .modal .modal-content .modal-header .modal-title {
        color: #CF5AFF;
        width: 100%;
        font-weight: 700;
        font-size: 1.2rem
      }

      .modal .modal-content .modal-header .close {
        position: absolute;
        right: 10px;
        top: 10px;
        background: var(--background-primary);
        color: #CF5AFF;
        padding: .2rem .6rem;
        opacity: 1;
        border-radius: 5px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, .5);
        text-shadow: unset;
        font-size: 2rem;
        font-weight: 500;
        transition: .3s ease-in-out
      }

      @media(max-width:768px) {
        .modal .modal-content .modal-header .close {
          right: 25px;
          top: 25px
        }
      }

      .modal .modal-content .modal-header .close:active,
      .modal .modal-content .modal-header .close:hover {
        box-shadow: none;
        opacity: 1;
        top: 12px;
        right: 12px
      }

      @media(max-width:768px) {

        .modal .modal-content .modal-header .close:active,
        .modal .modal-content .modal-header .close:hover {
          right: 25px;
          top: 25px
        }
      }

      .modal .modal-content .modal-footer {
        border: 0
      }

      .modal .modal-content .modal-footer .btn {
        transition: all .2s
      }

      @media(min-width:380px) {
        .modal .modal-content .modal-footer {
          padding: 1.8rem
        }
      }

      .modal-backdrop {
        background-color: var(--background-primary);
        opacity: .65
      }

      @media(max-width:768px) {
        .modal-backdrop {
          opacity: 1
        }
      }

      .table {
        border-top: 0
      }

      .table thead tr td,
      .table thead tr th {
        border-top: 0 !important;
        border-bottom-color: #CF5AFF
      }

      @media(max-width:768px) {

        .table thead tr td,
        .table thead tr th {
          font-size: .8rem;
          padding: .5rem .7rem;
          white-space: nowrap
        }
      }

     

      .dark-mode .table {
        border-top: 0
      }

      .dark-mode .table td,
      .dark-mode .table th {
        border-top: 1px solid hsla(0, 0%, 100%, .2)
      }

      .progress {
        background: hsla(0, 0%, 100%, .1)
      }

      body * {
        transition: none !important
      }

      body,
      body #__layout,
      html {
        margin: 0
      }

    

      .btn svg {
        width: 1em;
        height: 1em;
        color: currentColor;
        fill: currentColor
      }

      

      .dark-theme hr {
        border-color: var(--color-dark)
      }

      body,
      html {
        font-family: "Montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: px;
        word-spacing: 1px;
        -ms-text-size-adjust: 100%;
        -webkit-text-size-adjust: 100%;
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box
      }

      body,
      body #__layout,
      body #__nuxt,
      html {
        height: 100%
      }

      body {
        background-color: var(--background-primary);
        color: var(--color-primary)
      }

      @media(min-width:992px) {

        body>div .container-fluid .row,
        body>div .container-lg .row,
        body>div .container-md .row,
        body>div .container-sm .row,
        body>div .container-xl .row {
          height: 100%
        }
      }

      *,
      :after,
      :before {
        box-sizing: border-box;
        margin: 0
      }

      .container-fluid,
      .container-lg,
      .container-md,
      .container-sm,
      .container-xl {
        height: 100%
      }

      #layout-wrapper {
        display: flex;
        flex-direction: column;
        position: relative
      }

     

      @media(max-width:991px) {

        body.game-open #layout-wrapper,
       
        body.modal-open #layout-wrapper {
          margin-top: 0 !important
        }
      }

      .toasted-container .toasted {
        padding: 2rem 1rem !important;
        background-color: #0cd463 !important
      }

      .grecaptcha-badge {
        visibility: hidden
      }

      .v-toast {
        z-index: 9999 !important
      }

      .fade-enter-active,
      .fade-leave-active {
        transition: opacity .5s
      }

      .fade-enter,
      .fade-leave-active {
        opacity: 0
      }

      .form-group {
        font-size: .75rem
      }

      .form-group label {
        color: var(--color-primary)
      }

      .form-group .form-control {
        background: rgba(194, 189, 189, .1);
        color: var(--color-primary);
        border: none;
        border-radius: .25rem;
        padding-top: 1.1rem;
        padding-bottom: 1.1rem;
        font-size: .75rem
      }

      .form-group .form-control.focus,
      .form-group .form-control:focus {
        background: rgba(194, 189, 189, .1);
        color: var(--color-primary);
        border-color: #CF5AFF;
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

      .form-group .form-control::-moz-placeholder {
        color: #646464
      }

      .form-group .form-control::placeholder {
        color: #646464
      }

      .form-control {
        border: none;
        border-radius: .25rem;
        padding-top: 1.1rem;
        padding-bottom: 1.1rem;
        font-size: .75rem
      }

      .form-control,
      .form-control.focus,
      .form-control:focus {
        background: rgba(194, 189, 189, .1);
        color: var(--color-primary)
      }

      .form-control.focus,
      .form-control:focus {
        border-color: #CF5AFF;
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

      .form-control::-moz-placeholder {
        color: #646464
      }

      .form-control::placeholder {
        color: #646464
      }

      .form-control.disabled,
      .form-control:disabled,
      .form-control[disabled] {
        filter: opacity(60%);
        cursor: not-allowed
      }

      option {
        background: var(--background-primary)
      }

      .required:after {
        content: "*";
        color: red;
        margin-left: 2px
      }

      .custom-control-input:checked~.custom-control-label:before {
        border-color: #CF5AFF;
        background-color: #CF5AFF
      }

      .input-group-text {
        background-color: hsla(0, 0%, 100%, .1);
        border: 0;
        color: var(--color-primary)
      }

      .custom-control {
        line-height: 1.5rem
      }

      .custom-select {
        background: rgba(194, 189, 189, .1);
        color: var(--color-primary) !important
      }

      .custom-select.focus,
      .custom-select:focus {
        background: rgba(194, 189, 189, .1);
        color: var(--color-primary);
        border-color: #CF5AFF;
        box-shadow: 0 0 0 .14rem rgba(194, 189, 189, .1)
      }

      .custom-select::-moz-placeholder {
        color: #646464
      }

      .custom-select::placeholder {
        color: #646464
      }

      .custom-select.disabled,
      .custom-select:disabled,
      .custom-select[disabled] {
        filter: opacity(60%);
        cursor: not-allowed
      }

      
      @media(max-width:1480px)
      @media(max-width:991px) 

      .bg-primary {
        background-color: #CF5AFF !important
      }

      a.bg-primary:focus,
      a.bg-primary:hover,
      button.bg-primary:focus,
      button.bg-primary:hover {
        opacity: .9
      }

      .badge-primary {
        background-color: #CF5AFF
      }

      .badge-secondary {
        background-color: #82868b
      }

      .badge-warning {
        background-color: #fed52f
      }

      .btn-xs {
        font-size: .7em
      }

      .btn.disabled,
      .btn[disabled] {
        cursor: not-allowed
      }

      .form-group .form-control.b-form-datepicker {
        padding-top: .15rem;
        padding-bottom: .15rem
      }

      .form-group .form-control.b-form-datepicker label.form-control {
        padding-top: 5px;
        padding-bottom: 0
      }

      .form-group .form-control.b-form-datepicker>.btn {
        color: var(--color-primary)
      }

      .b-calendar-grid-help {
        display: none
      }

      .b-calendar .b-calendar-inner {
        min-width: 100%
      }

      #menu-horizontal h1 {
        line-height: 1rem;
        margin-bottom: .2rem
      }

      .navbar-brand {
        display: inline-flex
      }

     

      .text-primary {
        color: #CF5AFF !important
      }

      .opacity-25,
      .opacity-50,
      .opacity-75,
      .opacity-100 {
        opacity: 1%
      }

      .pointer-none {
        pointer-events: none
      }

      @media(max-width:768px) {
        .carousel-indicators {
          margin-bottom: .2rem
        }
      }

      .swiper-container {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center
      }

      .swiper-container .swiper-navigation {
        position: absolute;
        width: 100%
      }

      .swiper-container .swiper-navigation>div {
        top: auto;
        color: var(--color-primary);
        background: var(--background-primary);
        width: 40px;
        height: 40px;
        border-radius: 100px
      }

      .swiper-container .swiper-navigation>div svg {
        width: 1em;
        height: 1em;
        color: var(--color-primary);
        fill: var(--color-primary)
      }

      .swiper-container .swiper-navigation>div:after {
        display: none
      }

      .swiper-container .swiper-navigation .swiper-button-prev {
        left: -20px
      }

      .swiper-container .swiper-navigation .swiper-button-next {
        right: -20px
      }

      .modal-open #betslip-container-element {
        z-index: 10 !important
      }

      

    

      @media  screen and (max-width:991px) 

      @media  screen and (max-width:991px) 

      @media  screen and (max-width:768px) 

      @media  screen and (max-width:991px) 

      @media  screen and (max-width:991px) 
     

     

      @media(max-width:992px) {
        .casino-section {
          margin-top: 1.3rem
        }
      }

      @media(max-width:768px) {
        .casino-section {
          margin-top: .5rem
        }
      }

      .casino-section header {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: .5rem;
        margin-bottom: .5rem
      }

      .casino-section header h3 {
        font-size: 1rem;
        font-weight: 700;
        color: var(--color-light);
        margin: 0
      }

      @media(max-width:780px) {
        .casino-section header h3 {
          font-size: .8rem
        }
      }

      .casino-section header .see_all {
        background: #CF5AFF;
        color: var(--background-primary);
        font-size: .6em;
        font-weight: 700;
        padding: .05em .7em;
        border-radius: 50px;
        text-decoration: none
      }

      .casino-section header .see_all:hover {
        filter: opacity(90%)
      }

      .menu_horizontal {
        min-width: 100%;
        position: relative;
        margin: 2rem -.4rem
      }

      @media(max-width:768px) {
        .menu_horizontal {
          margin: 1rem -.4rem
        }
      }

      @media(max-width:991px) {
        .menu_horizontal:before {
          content: "";
          width: 15%;
          height: 100%;
          position: absolute;
          top: 0;
          right: -15px;
          z-index: 55;
          background: #212425;
          background: none;
          filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#00212425", endColorstr="#212425", GradientType=1)
        }
      }

      @media(max-width:768px) {
        .swp_casino {
          width: 85%;
          position: relative
        }

        .swp_casino:after {
          content: "";
          width: 15%;
          width: calc(15% + 30px);
          height: 102%;
          position: absolute;
          top: -1%;
          left: 101%;
          left: calc(100% + 3px);
          z-index: 5;
          background: #212425;
          background: linear-gradient(90deg, rgba(33, 36, 37, 0) 0, rgba(33, 36, 37, .99) 69%, #212425 70%);
          filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#00212425", endColorstr="#212425", GradientType=1)
        }
      }

      .swp_casino .swiper {
        width: 100%;
        margin: 0;
        overflow: initial;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none
      }

      @media(min-width:568px) {
        .swp_casino .swiper {
          width: 100%;
          overflow: hidden
        }
      }

      .swp_casino .swiper .swiper-wrapper .swiper-slide {
        border-radius: 8px;
        width: 42vw;
        height: auto;
        cursor: pointer
      }

      @media(min-width:991px) {
        .swp_casino .swiper .swiper-wrapper .swiper-slide {
          width: 100%
        }
      }

      .swiper-loading {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: stretch;
        gap: 16px
      }

      @media  screen and (max-width:1199px) {
        .swiper-loading {
          gap: 14px
        }
      }

      @media  screen and (max-width:991px) {
        .swiper-loading {
          gap: 12px
        }
      }

      @media  screen and (max-width:767px) {
        .swiper-loading {
          gap: 10px
        }
      }

      .swiper-loading span {
        width: 100%;
        height: 220px;
        border-radius: 8px;
        background: var(--background-secondary);
        animation: shimmer 1.8s infinite
      }

      @media(min-width:375px) {
        .swiper-loading span {
          mask: linear-gradient(-60deg, #fff 30%, hsla(0, 0%, 100%, .3333333333333333), #fff 70%) right/500% 200%;
          -webkit-mask: linear-gradient(-60deg, #fff 30%, hsla(0, 0%, 100%, .3333333333333333), #fff 70%) right/500% 200%;
          background-repeat: no-repeat;
          animation: shimmer 1.8s infinite
        }
      }

      @media  screen and (max-width:1199px) {

        .swiper-loading span:nth-child(5),
        .swiper-loading span:nth-child(6) {
          display: none
        }
      }

      @media  screen and (max-width:991px) {
        .swiper-loading span:nth-child(4) {
          display: none
        }
      }

      @media  screen and (max-width:767px) {
        .swiper-loading span:nth-child(3) {
          max-width: 12%
        }
      }

      @media  screen and (max-width:400px) {
        .swiper-loading span {
          height: 180px
        }
      }

      .skeleton-loading {
        background: hsla(0, 0%, 100%, .05);
        border-radius: 8px;
        animation: shimmer-pulse 1.8s infinite
      }

      @media(min-width:375px) {
        .skeleton-loading {
          mask: linear-gradient(-60deg, #fff 30%, hsla(0, 0%, 100%, .3333333333333333), #fff 70%) right/500% 200%;
          -webkit-mask: linear-gradient(-60deg, #fff 30%, hsla(0, 0%, 100%, .3333333333333333), #fff 70%) right/500% 200%;
          background-repeat: no-repeat;
          animation: shimmer 1.8s infinite
        }
      }

      @keyframes  shimmer {
        to {
          -webkit-mask-position: left
        }
      }

      @keyframes  shimmer-pulse {
        0% {
          opacity: 1
        }

        50% {
          opacity: .5
        }

        to {
          opacity: 1
        }
      }

      .dark-mode .swp_casino:after {
        background: #212425;
        background: linear-gradient(90deg, rgba(33, 36, 37, 0) 0, rgba(33, 36, 37, .99) 69%, #212425 70%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#00212425", endColorstr="#212425", GradientType=1)
      }

      .light-mode .swp_casino:after {
        background: #f3f2f2;
        background: linear-gradient(90deg, hsla(0, 4%, 95.1%, 0) 0, hsla(0, 4%, 95.1%, .99) 69%, #f3f2f2 70%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#00f3f2f2", endColorstr="#f3f2f2", GradientType=1)
      }

     
    </style>
    <style type="text/css">
      .dark-mode[data-v-53eaa0e8] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-53eaa0e8],
      .light-mode[data-v-53eaa0e8] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-53eaa0e8] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .navbar-nav[data-v-53eaa0e8] {
        position: relative;
        z-index: 50;
        -webkit-overflow-scrolling: touch;
        overflow-x: scroll;
        overflow-y: hidden
      }

      @media(max-width:991px) {
        .navbar-nav[data-v-53eaa0e8] {
          padding-right: 8%
        }
      }

      @media(max-width:768px) {
        .navbar-nav[data-v-53eaa0e8] {
          padding-right: 12%
        }
      }

      .navbar-nav .nav-link[data-v-53eaa0e8] {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-size: .85rem;
        font-weight: 600;
        gap: .4rem;
        margin: 0 .2rem;
        border-radius: .25rem;
        padding: .8rem .4rem;
        white-space: nowrap;
        color: var(--color-primary);
        filter: opacity(95%);
        transition: all .2s;
        line-height: 1
      }

      @media(max-width:992px) {
        .navbar-nav .nav-link[data-v-53eaa0e8] {
          margin: 0;
          font-size: .7rem;
          letter-spacing: -.03rem;
          padding: 0 .35rem
        }
      }

      .navbar-nav .nav-link .icon[data-v-53eaa0e8] {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 62px;
        height: 62px;
        border-radius: 100%;
        overflow: hidden;
        color: rgb(207 90 157);
      }

      .navbar-nav .nav-link .icon[data-v-53eaa0e8]:after {
        border-radius: 100% !important
      }

      @media(max-width:992px) {
        .navbar-nav .nav-link .icon[data-v-53eaa0e8] {
          width: 60px;
          height: 60px
        }
      }

      .navbar-nav .nav-link svg[data-v-53eaa0e8] {
        width: 1.9rem;
        height: 1.9rem
      }

      @media(max-width:992px) {
        .navbar-nav .nav-link svg[data-v-53eaa0e8] {
          width: 1.8rem;
          height: 1.8rem
        }
      }

      .navbar-nav .nav-link[data-v-53eaa0e8]:hover {
        filter: opacity(80%)
      }
    </style>
    <style type="text/css">
      .dark-mode[data-v-b8b7e870] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-b8b7e870],
      .light-mode[data-v-b8b7e870] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-b8b7e870] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .casino-section header .title_h3[data-v-b8b7e870] {
        font-size: 1rem;
        font-weight: 600
      }

      @media(min-width:992px) {
        .casino-section header .title_h3[data-v-b8b7e870] {
          font-size: 1.125rem
        }
      }

      .row__recommended[data-v-b8b7e870] {
        margin: 0 -12px
      }

      @media(max-width:1200px) {
        .row__recommended[data-v-b8b7e870] {
          margin: 0 -8px
        }
      }

      @media(max-width:992px) {
        .row__recommended[data-v-b8b7e870] {
          margin: 0 -5px
        }
      }

      .row__recommended .item[data-v-b8b7e870] {
        padding: 0 12px
      }

      @media(max-width:1200px) {
        .row__recommended .item[data-v-b8b7e870] {
          padding: 0 8px
        }
      }

      @media(max-width:992px) {
        .row__recommended .item[data-v-b8b7e870] {
          padding: 0 5px
        }
      }

      .row__recommended .item img[data-v-b8b7e870] {
        width: 100%;
        height: auto;
        border-radius: 8px
      }

      .row__recommended .row__recommended-skeleton[data-v-b8b7e870] {
        width: 100%;
        min-height: 80px;
        display: flex;
        flex-direction: row;
        gap: 10px
      }

      .row__recommended .row__recommended-skeleton .skeleton-loading[data-v-b8b7e870] {
        padding-top: 41.705%;
        width: 100%
      }

      @media(min-width:992px) {
        .row__recommended .row__recommended-skeleton .skeleton-loading[data-v-b8b7e870] {
          padding-top: 9.112%
        }
      }
    </style>
    <style type="text/css">
      .dark-mode[data-v-3d6f2aec] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-3d6f2aec],
      .light-mode[data-v-3d6f2aec] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-3d6f2aec] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .games-slider .games-header[data-v-3d6f2aec] {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px
      }

      .games-slider .games-header .games-header__left[data-v-3d6f2aec] {
        display: flex;
        gap: 1rem;
        flex-direction: row;
        align-items: center
      }

      .games-slider .games-header .games-header__left .games-title[data-v-3d6f2aec] {
        font-size: 1rem;
        font-weight: 600
      }

      @media(min-width:992px) {
        .games-slider .games-header .games-header__left .games-title[data-v-3d6f2aec] {
          font-size: 1.125rem
        }
      }

      .games-slider .games-header .games-header__left .slider-navigation[data-v-3d6f2aec] {
        display: flex;
        gap: .5rem
      }

      .games-slider .games-header .games-header__left .slider-navigation .slider-button[data-v-3d6f2aec] {
        cursor: pointer;
        opacity: .4;
        transition: .3s ease-in-out;
        padding: 0 .2rem;
        display: flex;
        align-items: center;
        justify-content: center
      }

      .games-slider .games-header .games-header__left .slider-navigation .slider-button[data-v-3d6f2aec]:hover {
        color: #CF5AFF;
        opacity: 1
      }

      .games-slider .games-header .games-header__left .slider-navigation .slider-button.disabled[data-v-3d6f2aec] {
        opacity: .2;
        cursor: not-allowed
      }

      .games-slider .games-header .btn[data-v-3d6f2aec] {
        color: #CF5AFF;
        font-size: .6em;
        font-weight: 700;
        padding: .05em .7em;
        border-radius: 50px;
        text-decoration: none
      }

      .games-slider .games-header .btn[data-v-3d6f2aec]:hover {
        filter: opacity(90%)
      }

      @media(max-width:576px) {
        .games-slider .slider[data-v-3d6f2aec] {
          overflow: initial;
          margin: 0 -15px
        }

        .games-slider .slider.swiper-free-mode>.swiper-wrapper[data-v-3d6f2aec] {
          overflow-x: scroll;
          overflow-y: hidden;
          transform: translateZ(0) !important
        }

        .games-slider .slider.swiper-free-mode>.swiper-wrapper[data-v-3d6f2aec]::-webkit-scrollbar {
          background: transparent;
          display: none !important;
          width: 0 !important;
          -webkit-appearance: none
        }

        .games-slider .slider[data-v-3d6f2aec]:after {
          content: "";
          display: block;
          width: 80px;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(33, 36, 37, .7) 61%, rgba(33, 36, 37, .98));
          position: absolute;
          right: -1%;
          top: 0;
          z-index: 1;
          transition: .2s ease-in-out;
          pointer-events: none
        }

        .games-slider .slider[data-reach-end=true][data-v-3d6f2aec]:after {
          right: -100%;
          opacity: 0
        }
      }

      .games-slider .slider .slide[data-v-3d6f2aec] {
        width: 130px;
        min-width: 130px;
        display: flex;
        flex-wrap: nowrap;
        height: auto
      }

      @media(max-width:576px) {
        .games-slider .slider .slide[data-v-3d6f2aec]:first-child {
          width: 145px !important;
          padding-left: 15px
        }

        .games-slider .slider .slide[data-v-3d6f2aec]:last-child {
          width: 145px !important;
          padding-right: 15px;
          margin-right: 0 !important
        }
      }

      .games-slider .slider-loading[data-v-3d6f2aec] {
        margin-right: -15px;
        width: 100%;
        display: grid;
        overflow: initial;
        gap: 10px;
        position: relative;
        grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
        grid-auto-flow: column
      }

      .games-slider .slider-loading[data-v-3d6f2aec]:after {
        content: "";
        display: block;
        width: 80px;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(33, 36, 37, .7) 61%, rgba(33, 36, 37, .98));
        position: absolute;
        right: -40px;
        top: 0;
        z-index: 1
      }

      @media(min-width:576px) {
        .games-slider .slider-loading[data-v-3d6f2aec] {
          overflow: hidden;
          margin: 0
        }

        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+4) {
          display: none
        }
      }

      @media(min-width:768px) {
        .games-slider .slider-loading[data-v-3d6f2aec]:after {
          display: none
        }

        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+4) {
          display: flex
        }

        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+5) {
          display: none
        }
      }

      @media(min-width:992px) {
        .games-slider .slider-loading[data-v-3d6f2aec] {
          gap: 24px
        }

        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+5) {
          display: none
        }
      }

      @media(min-width:1100px) {
        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+5) {
          display: flex
        }

        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+6) {
          display: none
        }
      }

      @media(min-width:1200px) {
        .games-slider .slider-loading span[data-v-3d6f2aec]:nth-of-type(n+6) {
          display: flex
        }
      }

      .games-slider .slider-loading span[data-v-3d6f2aec] {
        width: 100%;
        min-width: 130px;
        display: flex;
        padding-top: 134%;
        border-radius: 8px;
        background: var(--background-secondary);
        animation: shimmer 1.8s infinite
      }

      @media(min-width:768px) {
        .games-slider .slider-loading span[data-v-3d6f2aec]:first-child {
          margin-left: 0
        }
      }

      @media(min-width:375px) {
        .games-slider .slider-loading span[data-v-3d6f2aec] {
          mask: linear-gradient(-60deg, #fff 30%, hsla(0, 0%, 100%, .3333333333333333), #fff 70%) right/500% 200%;
          -webkit-mask: linear-gradient(-60deg, #fff 30%, hsla(0, 0%, 100%, .3333333333333333), #fff 70%) right/500% 200%;
          background-repeat: no-repeat;
          animation: shimmer 1.8s infinite
        }
      }
    </style>
    <style type="text/css">
      .dark-mode[data-v-39632cb5] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-39632cb5],
      .light-mode[data-v-39632cb5] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-39632cb5] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .casino-game[data-v-39632cb5] {
        background: var(--background-secondary);
        border-radius: 8px;
        position: relative;
        display: block;
        width: 100%;
        height: auto;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
        max-width: 48%;
        max-width: calc(50% - .5rem)
      }

      @media(min-width:360px) {
        .casino-game[data-v-39632cb5] {
          max-width: 210px;
          max-width: calc(33.33% - .55rem)
        }
      }

      @media(min-width:768px) {
        .casino-game[data-v-39632cb5] {
          max-width: 210px;
          max-width: calc(25% - .85rem)
        }
      }

      @media(min-width:820px) {
        .casino-game[data-v-39632cb5] {
          max-width: 210px;
          max-width: calc(25% - .8rem)
        }
      }

      @media(min-width:1100px) {
        .casino-game[data-v-39632cb5] {
          max-width: 210px;
          max-width: calc(20% - .8rem)
        }
      }

      @media(min-width:1281px) {
        .casino-game[data-v-39632cb5] {
          max-width: 210px;
          max-width: calc(16.66% - .83rem)
        }
      }

      .casino-game img[data-v-39632cb5] {
        width: 100%;
        min-height: 120px;
        height: auto;
        aspect-ratio: 1/1;
        border-radius: 8px 8px 0 0;
        position: relative;
        z-index: 5
      }

      @media(max-width:468px) {
        .casino-game img[data-v-39632cb5] {
          min-height: 80px
        }
      }

      .casino-game footer[data-v-39632cb5] {
        background: var(--background-secondary);
        margin: 0 0 -1px;
        padding: .8rem;
        border-radius: 0 0 8px 8px;
        position: relative;
        z-index: 12
      }

      @media(max-width:768px) {
        .casino-game footer[data-v-39632cb5] {
          padding: .4rem .5rem
        }
      }

      .casino-game footer .title_h4[data-v-39632cb5] {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: 0;
        max-width: 100%;
        font-weight: 700;
        font-size: .8rem;
        line-height: 1.2
      }

      @media(max-width:768px) {
        .casino-game footer .title_h4[data-v-39632cb5] {
          font-size: .72rem
        }
      }

      .casino-game footer .title_h5[data-v-39632cb5] {
        margin: 0;
        font-weight: 400;
        font-size: .7rem;
        line-height: 1.2
      }

      @media(max-width:768px) {
        .casino-game footer .title_h5[data-v-39632cb5] {
          font-size: .62rem
        }
      }

      .casino-game footer .title_h5 svg[data-v-39632cb5] {
        width: .6rem;
        height: .6rem
      }

      .casino-game .button[data-v-39632cb5] {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, .8);
        border-radius: 8px;
        z-index: 10;
        display: flex;
        justify-content: center;
        align-items: center;
        filter: opacity(0);
        visibility: hidden
      }

      .casino-game .button button[data-v-39632cb5] {
        font-size: .75rem;
        background: #CF5AFF;
        color: var(--background-primary);
        text-transform: uppercase;
        font-weight: 700
      }

      .casino-game .button button svg[data-v-39632cb5] {
        width: .6rem;
        height: .6rem;
        vertical-align: middle;
        margin-top: -2px;
        margin-right: 2px;
        color: var(--background-primary);
        fill: var(--background-primary)
      }

      @media(hover:none) {
        .casino-game .button[data-v-39632cb5] {
          display: none
        }
      }

      .casino-game .game-background[data-v-39632cb5] {
        background-position: bottom;
        background-size: 200%;
        position: absolute;
        z-index: 1;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 40%;
        border-radius: 0 0 8px 8px;
        overflow: hidden
      }

      .casino-game a[data-v-39632cb5] {
        text-decoration: none;
        color: var(--color-primary)
      }

      @media(hover:hover) {
        .casino-game a:hover .button[data-v-39632cb5] {
          filter: opacity(100%);
          visibility: visible
        }
      }

      .casino-game.swiper-slide[data-v-39632cb5] {
        max-width: 100%;
        max-width: 220px
      }

      @media(min-width:1200px) {
        .casino-game.swiper-slide[data-v-39632cb5] {
          max-width: 180px
        }
      }
    </style>
    <style type="text/css">
      .dark-mode[data-v-de41b76c] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-de41b76c],
      .light-mode[data-v-de41b76c] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-de41b76c] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      #games-section-sliders[data-v-de41b76c] {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
        margin-top: .25rem
      }

      @media(min-width:992px) {
        #games-section-sliders[data-v-de41b76c] {
          gap: 2rem;
          margin-top: 2rem
        }
      }
    </style>
    <style type="text/css">
      .dark-mode[data-v-5e2d0f4d] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-5e2d0f4d],
      .light-mode[data-v-5e2d0f4d] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-5e2d0f4d] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .provider-game[data-v-5e2d0f4d] {
        background: hsla(0, 0%, 100%, .1);
        transition: all .2s;
        border: 2px solid transparent;
        border-radius: .5rem;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
        width: 100%;
        position: relative;
        aspect-ratio: 3/2
      }

      .provider-game a[data-v-5e2d0f4d] {
        padding: .5rem;
        width: 100%;
        display: flex;
        height: -moz-fit-content;
        height: fit-content;
        justify-content: center;
        align-items: center
      }

      .provider-game a>div[data-v-5e2d0f4d] {
        height: 100%
      }

      .provider-game a>div img[data-v-5e2d0f4d] {
        height: auto
      }

      .provider-game .badge[data-v-5e2d0f4d] {
        position: absolute;
        top: 8px;
        right: 8px
      }

      .provider-game img[data-v-5e2d0f4d] {
        width: 100%;
        border-radius: .5rem;
        filter: brightness(100%);
        transition: all .2s
      }

      .provider-game[data-v-5e2d0f4d]:hover {
        background: hsla(0, 0%, 100%, .15)
      }

      .provider-game:hover img[data-v-5e2d0f4d] {
        filter: brightness(110%)
      }

      .provider-game.active[data-v-5e2d0f4d] {
        background: hsla(0, 0%, 100%, .1);
        border: 2px solid #CF5AFF
      }

      .provider-game.active img[data-v-5e2d0f4d] {
        filter: brightness(520%)
      }
    </style>
    <style type="text/css">
      .dark-mode {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode,
      .light-mode {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      #top-matches-container iframe {
        height: 274px
      }
    </style>
    
    
    <style type="text/css">
      .dark-mode {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode,
      .light-mode {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      body {
        margin: 0 !important;
        padding: 0 !important
      }
    </style>
    <style type="text/css">
      .dark-mode {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode,
      .light-mode {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .game-loader {
        font-size: 2rem;
        color: #CF5AFF;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%)
      }

      #casino {
        gap: 1rem;
        display: flex;
        flex-direction: column
      }

      #casino #game-wrapper {
        height: 100%
      }

      #casino #game-wrapper iframe {
        height: 100% !important;
        width: 100% !important;
        border: 0
      }

      #casino .game-launcher {
        border: 1px solid hsla(0, 0%, 100%, .1);
        border-radius: 8px;
        padding: 20px 25px;
        background: var(--background-secondary)
      }

      @media(min-width:768px) {
        #casino .game-launcher {
          display: none
        }
      }

      #casino .game-launcher .casino-votes {
        margin-top: 1rem;
        gap: .8rem
      }

      @media(min-width:768px) {
        #casino .game-launcher .casino-votes {
          margin: 0
        }
      }

      #casino .game-launcher .game-launcher__info {
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: .8rem
      }

      #casino .game-launcher .game-launcher__info img {
        max-width: 110px;
        border-radius: 10px;
        aspect-ratio: 1
      }

      #casino .game-launcher .game-launcher__info h2 {
        font-size: 1rem
      }

      #casino .game-launcher .game-launcher__info h4 {
        font-size: .75rem;
        color: var(--color-primary);
        opacity: .4
      }

      #casino .game-launcher .game-launcher__mode {
        display: flex;
        justify-content: flex-start;
        gap: .8rem;
        margin-top: 1.25rem
      }

      #casino .game-launcher .game-launcher__mode a {
        flex: 1;
        justify-content: stretch;
        display: flex
      }

      #casino .game-launcher .game-launcher__mode a:hover {
        text-decoration: none
      }

      #casino .game-launcher .game-launcher__mode .btn {
        flex: 1;
        font-size: .75rem;
        white-space: nowrap
      }

      @media(min-width:375px) {
        #casino .game-launcher .game-launcher__mode .btn {
          font-size: .875rem
        }
      }

      #casino .game-launcher .game-launcher__mode .btn.btn-default {
        border: 1px solid hsla(0, 0%, 100%, .4)
      }

      #casino .game-launcher .game-launcher__mode .btn svg {
        fill: currentColor;
        color: currentColor;
        margin-top: -2px
      }

      #casino .casino-buttons {
        display: flex;
        gap: .5rem
      }

      #casino .casino-buttons .casino-buttons__fullscreen {
        display: flex;
        justify-content: center;
        align-items: center
      }

      #casino #frame_game {
        width: 100%;
        height: 70vh;
        background: var(--background-primary);
        border: 1px solid hsla(0, 0%, 100%, .1);
        border-radius: 8px 8px 0 0;
        overflow: hidden;
        position: relative;
        display: flex;
        flex-direction: column
      }

      @media(max-width:768px) {
        #casino #frame_game:not(.fullScreen) {
          display: none
        }
      }

      #casino #frame_game iframe {
        width: 100%;
        height: 100%;
        position: relative;
        z-index: 5;
        overflow: hidden
      }

      @media(max-width:980px) {
        #casino #frame_game {
          height: 44vh
        }
      }

      #casino #frame_game.fullScreen .game-header {
        display: flex
      }

      #casino #frame_game .game-header {
        background: var(--background-secondary);
        padding: 0 0 0 .625rem;
        display: none;
        flex-direction: row;
        align-items: center;
        justify-content: space-between
      }

      @media(max-width:768px) {
        #casino #frame_game .game-header {
          display: flex
        }
      }

      #casino #frame_game .game-header h6 {
        font-size: .6875rem;
        margin: 0
      }

      #casino #frame_game .game-header .close_full {
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999;
        background: #000;
        color: #fff;
        border: 0;
        font-size: .6875rem;
        transition: all .2s
      }

      #casino #frame_game.fullScreen {
        width: 100%;
        height: 100%;
        position: fixed;
        border-radius: 0;
        top: 0;
        left: 0;
        z-index: 99999999
      }

      #casino #frame_game.fullScreen button {
        display: flex;
        justify-content: center;
        align-items: center
      }

      #casino #frame_game.fullScreen button svg {
        margin: 0;
        width: 1.2em;
        height: 1.2em;
        color: #adadad;
        fill: #adadad
      }

      #casino #frame_game .loading {
        width: 100%;
        height: 100%;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        z-index: 5
      }

      #casino #frame_game .loading svg {
        width: 3rem;
        height: 3rem;
        filter: opacity(20%)
      }

      #casino #frame_game .error {
        width: 100%;
        height: 100%;
        text-align: center;
        color: #e75c5c;
        font-size: 1.2rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        z-index: 15
      }

      @media(max-width:800px) {
        #casino #frame_game .error {
          font-size: .9rem
        }
      }

      #casino #frame_game .error.login {
        color: #fff
      }

      #casino #frame_game .error svg {
        margin: 0;
        width: 1em;
        height: 1em;
        color: var(--color-primary);
        fill: var(--color-primary)
      }

      #casino #frame_game .error .btn {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 6px;
        padding: .6rem 1.4rem;
        font-size: 1rem;
        font-weight: 700
      }

      @media(max-width:800px) {
        #casino #frame_game .error .btn {
          padding: .4rem 1rem
        }
      }

      #casino #frame_game .error .btn svg {
        color: var(--background-primary);
        fill: var(--background-primary)
      }

      #casino #frame_game .error .col {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px
      }

      #casino #frame_game .error .col>svg {
        width: 3rem;
        height: 3rem
      }

      #casino #frame_game .bg {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: 50%;
        filter: blur(10px) opacity(20%);
        transform: scale(1.2)
      }

      #casino #game_details {
        width: 100%;
        background: rgba(0, 0, 0, .2);
        border: 1px solid hsla(0, 0%, 100%, .1);
        border-top: 0;
        border-radius: 0 0 8px 8px;
        overflow: hidden;
        padding: 20px 25px
      }

      @media(max-width:980px) {
        #casino #game_details {
          padding: 12px 15px
        }
      }

      @media(max-width:768px) {
        #casino #game_details {
          display: none
        }
      }

      #casino #game_details h1 {
        font-size: .8rem;
        font-weight: 700;
        margin: 0 0 5px
      }

      @media(max-width:980px) {
        #casino #game_details h1 .skeleton-loading {
          width: 60%;
          padding-top: 1rem
        }
      }

      @media(min-width:992px) {
        #casino #game_details h1 {
          font-size: 1rem
        }
      }

      #casino #game_details h1 .skeleton-loading {
        width: 80%;
        padding-top: 1.2rem
      }

      #casino #game_details h2 {
        font-size: .8rem;
        font-weight: 400;
        margin: 0
      }

      #casino #game_details h2 .skeleton-loading {
        width: 60%;
        padding-top: .8rem
      }

      @media(max-width:980px) {
        #casino #game_details h2 {
          font-size: .7rem
        }

        #casino #game_details h2 .skeleton-loading {
          width: 40%;
          padding-top: .7rem
        }
      }

      #casino #game_details button {
        padding: 10px;
        margin: 0;
        border: 0;
        background: transparent;
        color: var(--color-primary);
        font-size: 1.2rem;
        transition: all .2s
      }

      #casino #game_details button:hover {
        filter: opacity(80%)
      }

      #casino #game_details button svg {
        width: 1em;
        height: 1em;
        color: var(--color-primary);
        fill: var(--color-primary)
      }

      #casino .game-open #layout-wrapper {
        margin-top: 0 !important
      }

      .casino-related-items {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
        margin: 1.25rem 0 .5rem
      }

      @media(min-width:992px) {
        .casino-related-items {
          gap: 2rem;
          margin-top: 2rem
        }
      }
    </style>
    
   

      
    <style type="text/css">
      .dark-mode[data-v-b38fe5fa] {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode[data-v-b38fe5fa],
      .light-mode[data-v-b38fe5fa] {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode[data-v-b38fe5fa] {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      #casino[data-v-b38fe5fa] {
        gap: 1rem;
        display: flex;
        flex-direction: column
      }

      #casino .casino-search[data-v-b38fe5fa] {
        font-size: 1rem;
        height: 3rem;
        padding: 0 1.3rem
      }

      @media  screen and (max-width:991px) {
        #casino .casino-search[data-v-b38fe5fa] {
          font-size: .8rem;
          height: 2.1rem;
          padding: 0 .9rem
        }
      }

      #casino .categories[data-v-b38fe5fa] {
        display: flex;
        -webkit-overflow-scrolling: touch;
        overflow-x: scroll;
        flex-wrap: wrap
      }

      @media  screen and (max-width:991px) {
        #casino .categories[data-v-b38fe5fa] {
          flex-wrap: nowrap
        }
      }

      #casino .categories button[data-v-b38fe5fa] {
        white-space: nowrap;
        border: 0;
        font-size: .95rem
      }

      #casino .categories button[class*=secondary][data-v-b38fe5fa] {
        background: rgba(194, 189, 189, .2);
        color: var(--color-primary)
      }

      #casino .casino-games-list[data-v-b38fe5fa] {
        list-style: none;
        margin: 0;
        padding: 0;
        font-size: 0;
        display: flex;
        justify-content: flex-start;
        align-items: stretch;
        flex-wrap: wrap;
        gap: 1rem
      }

      @media(max-width:768px) {
        #casino .casino-games-list[data-v-b38fe5fa] {
          gap: .8rem
        }
      }
    </style>
    
    
   
    
    <style type="text/css">
      @font-face {
        font-family: swiper-icons;
        src: url("data:application/font-woff;charset=utf-8;base64, d09GRgABAAAAAAZgABAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAGRAAAABoAAAAci6qHkUdERUYAAAWgAAAAIwAAACQAYABXR1BPUwAABhQAAAAuAAAANuAY7+xHU1VCAAAFxAAAAFAAAABm2fPczU9TLzIAAAHcAAAASgAAAGBP9V5RY21hcAAAAkQAAACIAAABYt6F0cBjdnQgAAACzAAAAAQAAAAEABEBRGdhc3AAAAWYAAAACAAAAAj//wADZ2x5ZgAAAywAAADMAAAD2MHtryVoZWFkAAABbAAAADAAAAA2E2+eoWhoZWEAAAGcAAAAHwAAACQC9gDzaG10eAAAAigAAAAZAAAArgJkABFsb2NhAAAC0AAAAFoAAABaFQAUGG1heHAAAAG8AAAAHwAAACAAcABAbmFtZQAAA/gAAAE5AAACXvFdBwlwb3N0AAAFNAAAAGIAAACE5s74hXjaY2BkYGAAYpf5Hu/j+W2+MnAzMYDAzaX6QjD6/4//Bxj5GA8AuRwMYGkAPywL13jaY2BkYGA88P8Agx4j+/8fQDYfA1AEBWgDAIB2BOoAeNpjYGRgYNBh4GdgYgABEMnIABJzYNADCQAACWgAsQB42mNgYfzCOIGBlYGB0YcxjYGBwR1Kf2WQZGhhYGBiYGVmgAFGBiQQkOaawtDAoMBQxXjg/wEGPcYDDA4wNUA2CCgwsAAAO4EL6gAAeNpj2M0gyAACqxgGNWBkZ2D4/wMA+xkDdgAAAHjaY2BgYGaAYBkGRgYQiAHyGMF8FgYHIM3DwMHABGQrMOgyWDLEM1T9/w8UBfEMgLzE////P/5//f/V/xv+r4eaAAeMbAxwIUYmIMHEgKYAYjUcsDAwsLKxc3BycfPw8jEQA/gZBASFhEVExcQlJKWkZWTl5BUUlZRVVNXUNTQZBgMAAMR+E+gAEQFEAAAAKgAqACoANAA+AEgAUgBcAGYAcAB6AIQAjgCYAKIArAC2AMAAygDUAN4A6ADyAPwBBgEQARoBJAEuATgBQgFMAVYBYAFqAXQBfgGIAZIBnAGmAbIBzgHsAAB42u2NMQ6CUAyGW568x9AneYYgm4MJbhKFaExIOAVX8ApewSt4Bic4AfeAid3VOBixDxfPYEza5O+Xfi04YADggiUIULCuEJK8VhO4bSvpdnktHI5QCYtdi2sl8ZnXaHlqUrNKzdKcT8cjlq+rwZSvIVczNiezsfnP/uznmfPFBNODM2K7MTQ45YEAZqGP81AmGGcF3iPqOop0r1SPTaTbVkfUe4HXj97wYE+yNwWYxwWu4v1ugWHgo3S1XdZEVqWM7ET0cfnLGxWfkgR42o2PvWrDMBSFj/IHLaF0zKjRgdiVMwScNRAoWUoH78Y2icB/yIY09An6AH2Bdu/UB+yxopYshQiEvnvu0dURgDt8QeC8PDw7Fpji3fEA4z/PEJ6YOB5hKh4dj3EvXhxPqH/SKUY3rJ7srZ4FZnh1PMAtPhwP6fl2PMJMPDgeQ4rY8YT6Gzao0eAEA409DuggmTnFnOcSCiEiLMgxCiTI6Cq5DZUd3Qmp10vO0LaLTd2cjN4fOumlc7lUYbSQcZFkutRG7g6JKZKy0RmdLY680CDnEJ+UMkpFFe1RN7nxdVpXrC4aTtnaurOnYercZg2YVmLN/d/gczfEimrE/fs/bOuq29Zmn8tloORaXgZgGa78yO9/cnXm2BpaGvq25Dv9S4E9+5SIc9PqupJKhYFSSl47+Qcr1mYNAAAAeNptw0cKwkAAAMDZJA8Q7OUJvkLsPfZ6zFVERPy8qHh2YER+3i/BP83vIBLLySsoKimrqKqpa2hp6+jq6RsYGhmbmJqZSy0sraxtbO3sHRydnEMU4uR6yx7JJXveP7WrDycAAAAAAAH//wACeNpjYGRgYOABYhkgZgJCZgZNBkYGLQZtIJsFLMYAAAw3ALgAeNolizEKgDAQBCchRbC2sFER0YD6qVQiBCv/H9ezGI6Z5XBAw8CBK/m5iQQVauVbXLnOrMZv2oLdKFa8Pjuru2hJzGabmOSLzNMzvutpB3N42mNgZGBg4GKQYzBhYMxJLMlj4GBgAYow/P/PAJJhLM6sSoWKfWCAAwDAjgbRAAB42mNgYGBkAIIbCZo5IPrmUn0hGA0AO8EFTQAA");
        font-weight: 400;
        font-style: normal
      }

      :root {
        --swiper-theme-color: #007aff
      }

      .swiper,
      swiper-container {
        margin-left: auto;
        margin-right: auto;
        position: relative;
        overflow: hidden;
        list-style: none;
        padding: 0;
        z-index: 1;
        display: block
      }

      .swiper-vertical>.swiper-wrapper {
        flex-direction: column
      }

      .swiper-wrapper {
        position: relative;
        width: 100%;
        height: 100%;
        z-index: 1;
        display: flex;
        transition-property: transform;
        transition-timing-function: var(--swiper-wrapper-transition-timing-function, initial);
        box-sizing: content-box
      }

      .swiper-android .swiper-slide,
      .swiper-wrapper {
        transform: translateZ(0)
      }

      .swiper-horizontal {
        touch-action: pan-y
      }

      .swiper-vertical {
        touch-action: pan-x
      }

      .swiper-slide,
      swiper-slide {
        flex-shrink: 0;
        width: 100%;
        height: 100%;
        position: relative;
        transition-property: transform;
        display: block
      }

      .swiper-slide-invisible-blank {
        visibility: hidden
      }

      .swiper-autoheight,
      .swiper-autoheight .swiper-slide {
        height: auto
      }

      .swiper-autoheight .swiper-wrapper {
        align-items: flex-start;
        transition-property: transform, height
      }

      .swiper-backface-hidden .swiper-slide {
        transform: translateZ(0);
        backface-visibility: hidden
      }

      .swiper-3d.swiper-css-mode .swiper-wrapper {
        perspective: 1200px
      }

      .swiper-3d .swiper-wrapper {
        transform-style: preserve-3d
      }

      .swiper-3d {
        perspective: 1200px
      }

      .swiper-3d .swiper-cube-shadow,
      .swiper-3d .swiper-slide,
      .swiper-3d .swiper-slide-shadow,
      .swiper-3d .swiper-slide-shadow-bottom,
      .swiper-3d .swiper-slide-shadow-left,
      .swiper-3d .swiper-slide-shadow-right,
      .swiper-3d .swiper-slide-shadow-top {
        transform-style: preserve-3d
      }

      .swiper-3d .swiper-slide-shadow,
      .swiper-3d .swiper-slide-shadow-bottom,
      .swiper-3d .swiper-slide-shadow-left,
      .swiper-3d .swiper-slide-shadow-right,
      .swiper-3d .swiper-slide-shadow-top {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 10
      }

      .swiper-3d .swiper-slide-shadow {
        background: rgba(0, 0, 0, .15)
      }

      .swiper-3d .swiper-slide-shadow-left {
        background-image: linear-gradient(270deg, rgba(0, 0, 0, .5), transparent)
      }

      .swiper-3d .swiper-slide-shadow-right {
        background-image: linear-gradient(90deg, rgba(0, 0, 0, .5), transparent)
      }

      .swiper-3d .swiper-slide-shadow-top {
        background-image: linear-gradient(0deg, rgba(0, 0, 0, .5), transparent)
      }

      .swiper-3d .swiper-slide-shadow-bottom {
        background-image: linear-gradient(180deg, rgba(0, 0, 0, .5), transparent)
      }

      .swiper-css-mode>.swiper-wrapper {
        overflow: auto;
        scrollbar-width: none;
        -ms-overflow-style: none
      }

      .swiper-css-mode>.swiper-wrapper::-webkit-scrollbar {
        display: none
      }

      .swiper-css-mode>.swiper-wrapper>.swiper-slide {
        scroll-snap-align: start start
      }

      .swiper-horizontal.swiper-css-mode>.swiper-wrapper {
        scroll-snap-type: x mandatory
      }

      .swiper-vertical.swiper-css-mode>.swiper-wrapper {
        scroll-snap-type: y mandatory
      }

      .swiper-css-mode.swiper-free-mode>.swiper-wrapper {
        scroll-snap-type: none
      }

      .swiper-css-mode.swiper-free-mode>.swiper-wrapper>.swiper-slide {
        scroll-snap-align: none
      }

      .swiper-centered>.swiper-wrapper:before {
        content: "";
        flex-shrink: 0;
        order: 9999
      }

      .swiper-centered>.swiper-wrapper>.swiper-slide {
        scroll-snap-align: center center;
        scroll-snap-stop: always
      }

      .swiper-centered.swiper-horizontal>.swiper-wrapper>.swiper-slide:first-child {
        margin-inline-start: var(--swiper-centered-offset-before)
      }

      .swiper-centered.swiper-horizontal>.swiper-wrapper:before {
        height: 100%;
        min-height: 1px;
        width: var(--swiper-centered-offset-after)
      }

      .swiper-centered.swiper-vertical>.swiper-wrapper>.swiper-slide:first-child {
        margin-block-start: var(--swiper-centered-offset-before)
      }

      .swiper-centered.swiper-vertical>.swiper-wrapper:before {
        width: 100%;
        min-width: 1px;
        height: var(--swiper-centered-offset-after)
      }

      .swiper-lazy-preloader {
        width: 42px;
        height: 42px;
        position: absolute;
        left: 50%;
        top: 50%;
        margin-left: -21px;
        margin-top: -21px;
        z-index: 10;
        transform-origin: 50%;
        box-sizing: border-box;
        border-radius: 50%;
        border: 4px solid var(--swiper-preloader-color, var(--swiper-theme-color));
        border-top: 4px solid transparent
      }

      .swiper-watch-progress .swiper-slide-visible .swiper-lazy-preloader,
      .swiper:not(.swiper-watch-progress) .swiper-lazy-preloader,
      swiper-container:not(.swiper-watch-progress) .swiper-lazy-preloader {
        animation: swiper-preloader-spin 1s linear infinite
      }

      .swiper-lazy-preloader-white {
        --swiper-preloader-color: #fff
      }

      .swiper-lazy-preloader-black {
        --swiper-preloader-color: #000
      }

      @keyframes  swiper-preloader-spin {
        0% {
          transform: rotate(0deg)
        }

        to {
          transform: rotate(1turn)
        }
      }

      .swiper-virtual .swiper-slide {
        -webkit-backface-visibility: hidden;
        transform: translateZ(0)
      }

      .swiper-virtual.swiper-css-mode .swiper-wrapper:after {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        pointer-events: none
      }

      .swiper-virtual.swiper-css-mode.swiper-horizontal .swiper-wrapper:after {
        height: 1px;
        width: var(--swiper-virtual-size)
      }

      .swiper-virtual.swiper-css-mode.swiper-vertical .swiper-wrapper:after {
        width: 1px;
        height: var(--swiper-virtual-size)
      }

      :root {
        --swiper-navigation-size: 44px
      }

      .swiper-button-next,
      .swiper-button-prev {
        position: absolute;
        top: var(--swiper-navigation-top-offset, 50%);
        width: calc(var(--swiper-navigation-size)/44*27);
        height: var(--swiper-navigation-size);
        margin-top: calc(0px - var(--swiper-navigation-size)/2);
        z-index: 10;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--swiper-navigation-color, var(--swiper-theme-color))
      }

      .swiper-button-next.swiper-button-disabled,
      .swiper-button-prev.swiper-button-disabled {
        opacity: .35;
        cursor: auto;
        pointer-events: none
      }

      .swiper-button-next.swiper-button-hidden,
      .swiper-button-prev.swiper-button-hidden {
        opacity: 0;
        cursor: auto;
        pointer-events: none
      }

      .swiper-navigation-disabled .swiper-button-next,
      .swiper-navigation-disabled .swiper-button-prev {
        display: none !important
      }

      .swiper-button-next:after,
      .swiper-button-prev:after {
        font-family: swiper-icons;
        font-size: var(--swiper-navigation-size);
        text-transform: none !important;
        letter-spacing: 0;
        font-variant: normal;
        line-height: 1
      }

      .swiper-button-prev,
      .swiper-rtl .swiper-button-next {
        left: var(--swiper-navigation-sides-offset, 10px);
        right: auto
      }

      .swiper-button-prev:after,
      .swiper-rtl .swiper-button-next:after {
        content: "prev"
      }

      .swiper-button-next,
      .swiper-rtl .swiper-button-prev {
        right: var(--swiper-navigation-sides-offset, 10px);
        left: auto
      }

      .swiper-button-next:after,
      .swiper-rtl .swiper-button-prev:after {
        content: "next"
      }

      .swiper-button-lock {
        display: none
      }

      .swiper-pagination {
        position: absolute;
        text-align: center;
        transition: opacity .3s;
        transform: translateZ(0);
        z-index: 10
      }

      .swiper-pagination.swiper-pagination-hidden {
        opacity: 0
      }

      .swiper-pagination-disabled>.swiper-pagination,
      .swiper-pagination.swiper-pagination-disabled {
        display: none !important
      }

      .swiper-horizontal>.swiper-pagination-bullets,
      .swiper-pagination-bullets.swiper-pagination-horizontal,
      .swiper-pagination-custom,
      .swiper-pagination-fraction {
        bottom: var(--swiper-pagination-bottom, 8px);
        top: var(--swiper-pagination-top, auto);
        left: 0;
        width: 100%
      }

      .swiper-pagination-bullets-dynamic {
        overflow: hidden;
        font-size: 0
      }

      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet {
        transform: scale(.33);
        position: relative
      }

      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active,
      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-main {
        transform: scale(1)
      }

      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev {
        transform: scale(.66)
      }

      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-prev-prev {
        transform: scale(.33)
      }

      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next {
        transform: scale(.66)
      }

      .swiper-pagination-bullets-dynamic .swiper-pagination-bullet-active-next-next {
        transform: scale(.33)
      }

      .swiper-pagination-bullet {
        width: var(--swiper-pagination-bullet-width, var(--swiper-pagination-bullet-size, 8px));
        height: var(--swiper-pagination-bullet-height, var(--swiper-pagination-bullet-size, 8px));
        display: inline-block;
        border-radius: var(--swiper-pagination-bullet-border-radius, 50%);
        background: var(--swiper-pagination-bullet-inactive-color, #000);
        opacity: var(--swiper-pagination-bullet-inactive-opacity, .2)
      }

      button.swiper-pagination-bullet {
        border: none;
        margin: 0;
        padding: 0;
        box-shadow: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none
      }

      .swiper-pagination-clickable .swiper-pagination-bullet {
        cursor: pointer
      }

      .swiper-pagination-bullet:only-child {
        display: none !important
      }

      .swiper-pagination-bullet-active {
        opacity: var(--swiper-pagination-bullet-opacity, 1);
        background: var(--swiper-pagination-color, var(--swiper-theme-color))
      }

      .swiper-pagination-vertical.swiper-pagination-bullets,
      .swiper-vertical>.swiper-pagination-bullets {
        right: var(--swiper-pagination-right, 8px);
        left: var(--swiper-pagination-left, auto);
        top: 50%;
        transform: translate3d(0, -50%, 0)
      }

      .swiper-pagination-vertical.swiper-pagination-bullets .swiper-pagination-bullet,
      .swiper-vertical>.swiper-pagination-bullets .swiper-pagination-bullet {
        margin: var(--swiper-pagination-bullet-vertical-gap, 6px) 0;
        display: block
      }

      .swiper-pagination-vertical.swiper-pagination-bullets.swiper-pagination-bullets-dynamic,
      .swiper-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic {
        top: 50%;
        transform: translateY(-50%);
        width: 8px
      }

      .swiper-pagination-vertical.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet,
      .swiper-vertical>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet {
        display: inline-block;
        transition: transform .2s, top .2s
      }

      .swiper-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet,
      .swiper-pagination-horizontal.swiper-pagination-bullets .swiper-pagination-bullet {
        margin: 0 var(--swiper-pagination-bullet-horizontal-gap, 4px)
      }

      .swiper-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic,
      .swiper-pagination-horizontal.swiper-pagination-bullets.swiper-pagination-bullets-dynamic {
        left: 50%;
        transform: translateX(-50%);
        white-space: nowrap
      }

      .swiper-horizontal>.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet,
      .swiper-pagination-horizontal.swiper-pagination-bullets.swiper-pagination-bullets-dynamic .swiper-pagination-bullet {
        transition: transform .2s, left .2s
      }

      .swiper-horizontal.swiper-rtl>.swiper-pagination-bullets-dynamic .swiper-pagination-bullet,
      :host(.swiper-horizontal.swiper-rtl) .swiper-pagination-bullets-dynamic .swiper-pagination-bullet {
        transition: transform .2s, right .2s
      }

      .swiper-pagination-fraction {
        color: var(--swiper-pagination-fraction-color, inherit)
      }

      .swiper-pagination-progressbar {
        background: var(--swiper-pagination-progressbar-bg-color, rgba(0, 0, 0, .25));
        position: absolute
      }

      .swiper-pagination-progressbar .swiper-pagination-progressbar-fill {
        background: var(--swiper-pagination-color, var(--swiper-theme-color));
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        transform: scale(0);
        transform-origin: left top
      }

      .swiper-rtl .swiper-pagination-progressbar .swiper-pagination-progressbar-fill {
        transform-origin: right top
      }

      .swiper-horizontal>.swiper-pagination-progressbar,
      .swiper-pagination-progressbar.swiper-pagination-horizontal,
      .swiper-pagination-progressbar.swiper-pagination-vertical.swiper-pagination-progressbar-opposite,
      .swiper-vertical>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite {
        width: 100%;
        height: var(--swiper-pagination-progressbar-size, 4px);
        left: 0;
        top: 0
      }

      .swiper-horizontal>.swiper-pagination-progressbar.swiper-pagination-progressbar-opposite,
      .swiper-pagination-progressbar.swiper-pagination-horizontal.swiper-pagination-progressbar-opposite,
      .swiper-pagination-progressbar.swiper-pagination-vertical,
      .swiper-vertical>.swiper-pagination-progressbar {
        width: var(--swiper-pagination-progressbar-size, 4px);
        height: 100%;
        left: 0;
        top: 0
      }

      .swiper-pagination-lock {
        display: none
      }

      .swiper-scrollbar {
        border-radius: var(--swiper-scrollbar-border-radius, 10px);
        position: relative;
        -ms-touch-action: none;
        background: var(--swiper-scrollbar-bg-color, rgba(0, 0, 0, .1))
      }

      .swiper-scrollbar-disabled>.swiper-scrollbar,
      .swiper-scrollbar.swiper-scrollbar-disabled {
        display: none !important
      }

      .swiper-horizontal>.swiper-scrollbar,
      .swiper-scrollbar.swiper-scrollbar-horizontal {
        position: absolute;
        left: var(--swiper-scrollbar-sides-offset, 1%);
        bottom: var(--swiper-scrollbar-bottom, 4px);
        top: var(--swiper-scrollbar-top, auto);
        z-index: 50;
        height: var(--swiper-scrollbar-size, 4px);
        width: calc(100% - var(--swiper-scrollbar-sides-offset, 1%)*2)
      }

      .swiper-scrollbar.swiper-scrollbar-vertical,
      .swiper-vertical>.swiper-scrollbar {
        position: absolute;
        left: var(--swiper-scrollbar-left, auto);
        right: var(--swiper-scrollbar-right, 4px);
        top: var(--swiper-scrollbar-sides-offset, 1%);
        z-index: 50;
        width: var(--swiper-scrollbar-size, 4px);
        height: calc(100% - var(--swiper-scrollbar-sides-offset, 1%)*2)
      }

      .swiper-scrollbar-drag {
        height: 100%;
        width: 100%;
        position: relative;
        background: var(--swiper-scrollbar-drag-bg-color, rgba(0, 0, 0, .5));
        border-radius: var(--swiper-scrollbar-border-radius, 10px);
        left: 0;
        top: 0
      }

      .swiper-scrollbar-cursor-drag {
        cursor: move
      }

      .swiper-scrollbar-lock {
        display: none
      }

      .swiper-zoom-container {
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center
      }

      .swiper-zoom-container>canvas,
      .swiper-zoom-container>img,
      .swiper-zoom-container>svg {
        max-width: 100%;
        max-height: 100%;
        -o-object-fit: contain;
        object-fit: contain
      }

      .swiper-slide-zoomed {
        cursor: move;
        touch-action: none
      }

      .swiper .swiper-notification,
      swiper-container .swiper-notification {
        position: absolute;
        left: 0;
        top: 0;
        pointer-events: none;
        opacity: 0;
        z-index: -1000
      }

      .swiper-free-mode>.swiper-wrapper {
        transition-timing-function: ease-out;
        margin: 0 auto
      }

      .swiper-grid>.swiper-wrapper {
        flex-wrap: wrap
      }

      .swiper-grid-column>.swiper-wrapper {
        flex-wrap: wrap;
        flex-direction: column
      }

      .swiper-fade.swiper-free-mode .swiper-slide {
        transition-timing-function: ease-out
      }

      .swiper-fade .swiper-slide {
        pointer-events: none;
        transition-property: opacity
      }

      .swiper-fade .swiper-slide .swiper-slide {
        pointer-events: none
      }

      .swiper-fade .swiper-slide-active,
      .swiper-fade .swiper-slide-active .swiper-slide-active {
        pointer-events: auto
      }

      .swiper-cube {
        overflow: visible
      }

      .swiper-cube .swiper-slide {
        pointer-events: none;
        backface-visibility: hidden;
        z-index: 1;
        visibility: hidden;
        transform-origin: 0 0;
        width: 100%;
        height: 100%
      }

      .swiper-cube .swiper-slide .swiper-slide {
        pointer-events: none
      }

      .swiper-cube.swiper-rtl .swiper-slide {
        transform-origin: 100% 0
      }

      .swiper-cube .swiper-slide-active,
      .swiper-cube .swiper-slide-active .swiper-slide-active {
        pointer-events: auto
      }

      .swiper-cube .swiper-slide-active,
      .swiper-cube .swiper-slide-next,
      .swiper-cube .swiper-slide-next+.swiper-slide,
      .swiper-cube .swiper-slide-prev {
        pointer-events: auto;
        visibility: visible
      }

      .swiper-cube .swiper-slide-shadow-bottom,
      .swiper-cube .swiper-slide-shadow-left,
      .swiper-cube .swiper-slide-shadow-right,
      .swiper-cube .swiper-slide-shadow-top {
        z-index: 0;
        backface-visibility: hidden
      }

      .swiper-cube .swiper-cube-shadow {
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
        opacity: .6;
        z-index: 0
      }

      .swiper-cube .swiper-cube-shadow:before {
        content: "";
        background: #000;
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        right: 0;
        filter: blur(50px)
      }

      .swiper-flip {
        overflow: visible
      }

      .swiper-flip .swiper-slide {
        pointer-events: none;
        backface-visibility: hidden;
        z-index: 1
      }

      .swiper-flip .swiper-slide .swiper-slide {
        pointer-events: none
      }

      .swiper-flip .swiper-slide-active,
      .swiper-flip .swiper-slide-active .swiper-slide-active {
        pointer-events: auto
      }

      .swiper-flip .swiper-slide-shadow-bottom,
      .swiper-flip .swiper-slide-shadow-left,
      .swiper-flip .swiper-slide-shadow-right,
      .swiper-flip .swiper-slide-shadow-top {
        z-index: 0;
        backface-visibility: hidden
      }

      .swiper-creative .swiper-slide {
        backface-visibility: hidden;
        overflow: hidden;
        transition-property: transform, opacity, height
      }

      .swiper-cards {
        overflow: visible
      }

      .swiper-cards .swiper-slide {
        transform-origin: center bottom;
        backface-visibility: hidden;
        overflow: hidden
      }
    </style>
	
	<style type="text/css">
      .dark-mode {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode,
      .light-mode {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }





/* Estilo para o footer */
#footer {
    background: #10171D;
    border-top: 1px solid hsla(0, 0%, 100%, .1);
    padding: 3rem 1rem;
    width: 100%;
    position: absolute;
    left: 0;
    bottom: -2250;
}




      @media(min-width:992px) 

      @media(min-width:992px)

      @media(max-width:990px) {
        #footer {
          margin-top: 1rem;
          padding: 2rem 0 calc(1.5rem + 60px)
        }
      }

      @media(max-width:768px) {
        #footer {
          padding: 1rem 0 calc(1rem + 60px)
        }

        #footer .container-fluid {
          padding: 0 .8rem
        }
      }

      @media(min-width:992px) {
        #footer {
          margin-left: 15px
		  
        }
      }

      @media(min-width:992px) {
        #footer.menu-open {
          margin-left: 280px
        }
      }

      @media(max-width:990px) {
        #footer .columns {
          gap: 1.4rem
        }
      }

      @media(max-width:630px) {

        #footer .columns .app-logo,
        #footer .columns .footer-support {
          float: left
        }
      }

      #footer hr {
        border-top-color: var(--color-light);
        opacity: .2;
        margin: 1.5rem 0;
        width: 100%
      }

      @media(max-width:768px) {
        #footer hr {
          margin: 1.2rem 0
        }
      }

      #footer .app-logo,
      #footer .logo {
        width: 100%;
        margin-bottom: 1rem;
        max-width: 100px
      }

      @media(max-width:768px) {

        #footer .app-logo,
        #footer .logo {
          max-height: 40px;
          margin-bottom: .1rem
        }
      }

      #footer .app-logo .app-logo,
      #footer .logo .app-logo {
        width: auto !important
      }

      #footer h2 {
        font-weight: 500;
        font-size: .875em;
        line-height: 1.5;
        margin-bottom: 1.8rem
      }

      #footer .title_h5 {
        margin-bottom: .4rem;
        font-weight: 700;
        font-size: 1rem
      }

      @media  screen and (max-width:990px) {
        #footer .title_h5 {
          font-size: .85rem
        }
      }

      #footer .footer-links {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 18px
      }

      @media  screen and (max-width:1080px) {
        #footer .footer-links {
          gap: 5px 10px
        }

        #footer .footer-links:not(.footer-links__social) {
          flex-direction: column;
          align-items: flex-start
        }
      }

      #footer .footer-links a {
        display: inline-flex;
        justify-content: center;
        align-items: center;
        font-size: .84rem;
        gap: 3px;
        color: #adadad
      }

      @media  screen and (max-width:768px) {
        #footer .footer-links a {
          font-size: .8rem
        }
      }

      @media(max-width:768px) {
        #footer .footer-links a {
          font-size: .75rem
        }
      }

      #footer .footer-links a svg {
        width: .8em;
        height: .8em;
        color: #adadad;
        fill: #adadad
      }

      @media  screen and (max-width:990px) {
        #footer .footer-links a {
          width: 100%;
          justify-content: flex-start
        }
      }

      #footer .footer-links.footer-links__social {
        gap: 2px
      }

      #footer .footer-links.footer-links__social a {
        font-size: 1rem;
        width: 30px;
        height: 30px;
        background-color: var(--background-primary);
        border-radius: 100%
      }

      @media  screen and (max-width:990px) {
        #footer .footer-links.footer-links__social a {
          justify-content: center
        }
      }

      #footer .footer-links.footer-links__social a:hover {
        color: var(--background-primary);
        background-color: #CF5AFF
      }

      #footer .footer-links.footer-links__social a:hover svg {
        color: var(--background-primary)
      }

      #footer .logo-bs2-bet {
        width: 100%;
        max-width: 70px
      }

      #footer .logo-pix {
        max-height: 24px
      }

      #footer .footer_text {
        max-height: 150px;
        overflow: hidden;
        position: relative;
        padding: 0 0 2rem;
        margin: 0 0 2rem;
        font-size: .75rem;
        text-align: center
      }

      #footer .footer_text:after {
        content: "";
        width: 100%;
        height: 1px;
        position: absolute;
        bottom: 0;
        left: 0;
        z-index: 3;
        border-bottom: 1px solid var(--color-light);
        opacity: .2
      }

      
      #footer .footer_text h2,
      #footer .footer_text p {
        margin-bottom: 1rem
      }

      #footer .footer_text.opened {
        max-height: 2000px
      }

      #footer .footer_text.opened:before {
        content: "Ver menos...";
        padding: 10px 0 1rem
      }

      #footer .footer_text .curacao {
        padding-right: 2rem
      }

      #footer .footer_text .curacao img {
        filter: opacity(90%)
      }

      @media(max-width:768px) {
        #footer .footer_text {
          font-size: .75rem;
          margin-bottom: 1.8rem
        }

        #footer .footer_text .flex-grow-0 {
          min-width: 100%
        }

        #footer .footer_text .curacao {
          margin-bottom: 1rem;
          padding-right: 0
        }
      }

      #footer .br .title_h6 {
        font-size: .9rem;
        margin: 0
      }

      @media(max-width:768px) {
        #footer .br .title_h6 {
          font-size: .8rem
        }
      }

      #footer .br span {
        color: #ff3a3a;
        font-size: .7rem;
        line-height: .5rem
      }

      #footer .br img {
        border-radius: .4rem;
        max-height: 26px;
        width: auto;
        margin-bottom: .5rem
      }

      @media(max-width:768px) {
        #footer .br img {
          max-height: 22px;
          margin-top: -.4rem;
          margin-bottom: .4rem
        }
      }

      #footer .licenses {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 1.4rem;
        flex-wrap: wrap
      }

      @media(min-width:768px) {
        #footer .licenses {
          justify-content: center
        }
      }

      @media(max-width:768px) {
        #footer .licenses {
          gap: 1rem;
          margin: 0 auto
        }
      }

      #footer .licenses .parent-advisor {
        color: #CF5AFF;
        font-size: 2rem
      }

      @media(min-width:992px) {
        #footer .licenses .parent-advisor {
          font-size: 3rem
        }
      }

      #footer .licenses .secure-site {
        width: auto;
        height: 2rem
      }

      #footer .licenses img {
        max-width: 100%;
        height: 3rem;
        max-height: 4rem !important;
        width: auto
      }

      #footer .licenses img[src*=braza_games] {
        height: 3.2rem
      }

      #footer .licenses img[src*=cactus] {
        height: 2.6rem
      }

      #footer .licenses img.be-gamble-aware {
        max-width: 10rem
      }

      @media(max-width:768px) {
        #footer .licenses img {
          height: 2rem;
          max-height: 2rem !important
        }

        #footer .licenses img[src*=cactus] {
          height: 1.8rem
        }
      }

      #footer .footer-license .curacao {
        float: left;
        margin-bottom: .5rem;
        margin-right: 2rem
      }

      @media(max-width:768px) {
        #footer .footer-license .curacao {
          margin-top: .3rem;
          margin-bottom: .3rem;
          margin-right: 1rem
        }
      }

      #footer .footer-license p {
        line-height: 1;
        text-align: center
      }

      #footer .footer-license p:last-child {
        margin-bottom: 0
      }

      @media(max-width:768px) {
        #footer .footer-license p {
          margin-top: -.3rem
        }
      }

      #footer .footer-license p small {
        font-size: .65625rem
      }

      #footer #go_to_top {
        position: fixed;
        bottom: 20px;
        right: 50%;
        z-index: 90;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: .3rem;
        background: rgba(0, 0, 0, .7);
        font-size: .85rem;
        color: var(--color-primary);
        border: 1px solid rgba(163, 215, 18, .7);
        border-radius: 100px;
        padding: .2rem .7rem .3rem;
        line-height: 1.04rem;
        cursor: pointer;
        filter: opacity(0);
        visibility: hidden;
        transform: translate(50%, 150%);
        transition: all .6s
      }

      #footer #go_to_top.show {
        filter: opacity(100%);
        visibility: visible;
        transform: translate(50%)
      }

      #footer #go_to_top:hover {
        background: rgba(0, 0, 0, .9);
        border: 1px solid rgba(163, 215, 18, .9)
      }

      #footer #go_to_top svg {
        width: .9em;
        height: .9em;
        margin-left: -.1rem
      }

      @media(max-width:991px) {
        #footer #go_to_top {
          font-size: .75rem;
          bottom: 68px
        }

        #footer #go_to_top.fd_active {
          bottom: 120px
        }
      }

      #footer .footer-emails {
        padding: 2rem 0;
        display: flex;
        flex-direction: column;
        gap: .3rem
      }

      @media(min-width:992px) {
        #footer .footer-emails {
          flex-direction: row;
          justify-content: center
        }
      }

      #footer .footer-emails p {
        font-size: .65625rem;
        line-height: 1.2;
        margin: 0;
        text-align: center
		
      }

      #footer .footer-emails p span {
        opacity: .4
      }
	  
	  /* Remover a cor azul padrão dos links e manter a cor do texto normal */
a {
    color: inherit; /* Herda a cor do texto pai (cor normal) */
    text-decoration: none; /* Remove o sublinhado */
}
    </style>
    <style type="text/css">
      .dark-mode {
        --background-primary: #212425;
        --background-secondary: #323637;
        --background-shadow: hsla(0, 0%, 100%, 0.04);
        --color-light: #fdffff;
        --color-primary: #fdffff;
        --color-secondary: #adadad
      }

      .dark-mode,
      .light-mode {
        --background-header: #82868b;
        --color-dark: #3d4242
      }

      .light-mode {
        --background-primary: #f3f2f2;
        --background-secondary: #fff;
        --background-shadow: rgba(0, 0, 0, 0.04);
        --color-light: #fff;
        --color-primary: #111
      }

      .footer-text-dynamic {
        font-weight: 600;
        line-height: 1.6em;
        text-align: center;
        font-size: .65625rem
      }

      .footer-text-dynamic b,
      .footer-text-dynamic strong {
        font-weight: 600
      }

      .footer-text-dynamic hr {
        border-top: 1px solid var(--color-primary);
        opacity: .2
      }
	  
	  
    </style>
	
	
	
      <style type="text/css">
   @media (max-width: 768px) {
	  .hide-mobile {
		display: none;
	  }
	}

 </style>
 
  <body>
   
    
  <!---->
        <div id="wrapper">
        <div id="main-content">
             
                <div class="pb-7 container">
                  
				<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
	 <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
	  <button type="button" data-bs-target="#demo" data-bs-slide-to="4"></button>
	   <button type="button" data-bs-target="#demo" data-bs-slide-to="5"></button>
	      <button type="button" data-bs-target="#demo" data-bs-slide-to="6"></button>
		   <button type="button" data-bs-target="#demo" data-bs-slide-to="7"></button>
		   
  </div>
  
  <!-- The slideshow/carousel -->
  
<div class="hide-mobile" /><br/><br/> </div>
  
  <div class="carousel-inner">
    <div class="carousel-item active" >
      <img  src="img/banner01.png" class="d-block" style="width:100%" >
    </div>
    <div class="carousel-item">
      <img src="../sistemasbet.b-cdn.net/banners%20principais/banner2.png" class="d-block" style="width:100%">
    </div>
	<div class="carousel-item" >
      <img src="../sistemasbet.b-cdn.net/banners%20principais/banner3.png" class="d-block" style="width:100%">
    </div>
	<div class="carousel-item">
      <img src="../sistemasbet.b-cdn.net/banners%20principais/banner4.png" class="d-block" style="width:100%">
    </div>
	<div class="carousel-item">
      <img src="../sistemasbet.b-cdn.net/banners%20principais/banner5.png" class="d-block" style="width:100%">
    </div>
	<div class="carousel-item">
      <img src="../sistemasbet.b-cdn.net/banners%20principais/banner6.png" class="d-block" style="width:100%">
    </div>
	<div class="carousel-item">
      <img src="../sistemasbet.b-cdn.net/banners%20principais/banner7.png" class="d-block" style="width:100%">
    </div>
	
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
				  
                  <div data-v-53eaa0e8="" class="menu_horizontal">
                    <ul data-v-53eaa0e8="" class="navbar-nav d-flex flex-row align-items-start justify-content-between justify-content-center">
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="dice.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                              <path fill="currentColor" d="M177.1 228.6L207.9 320h96.5l29.62-91.38L256 172.1L177.1 228.6zM255.1 0C114.6 0 .0001 114.6 .0001 256S114.6 512 256 512s255.1-114.6 255.1-255.1S397.4 0 255.1 0zM435.2 361.1l-103.9-1.578l-30.67 99.52C286.2 462.2 271.3 464 256 464s-30.19-1.773-44.56-4.93L180.8 359.6L76.83 361.1c-14.93-25.35-24.79-54.01-27.8-84.72L134.3 216.4L100.7 118.1c19.85-22.34 44.32-40.45 72.04-52.62L256 128l83.29-62.47c27.72 12.17 52.19 30.27 72.04 52.62L377.7 216.4l85.23 59.97C459.1 307.1 450.1 335.8 435.2 361.1z"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        Dice
      </span>
                        </a></li>
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="double.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                              <path fill="currentColor" d="M448 32H64C28.65 32 0 60.65 0 96v320c0 35.35 28.65 64 64 64h384c35.35 0 64-28.65 64-64V96C512 60.65 483.3 32 448 32zM254.1 80h67.88l-80 80H174.1L254.1 80zM48 126.1L94.06 80h67.88l-80 80H48V126.1zM464 416c0 8.822-7.178 16-16 16H64c-8.822 0-16-7.178-16-16V208h416V416zM464 97.94L401.9 160h-67.88l80-80H448c8.822 0 16 7.178 16 16V97.94zM218.7 400c1.959 0 3.938-.5605 5.646-1.682l106.7-68.97C334.1 327.3 336 323.8 336 319.1s-1.896-7.34-5.021-9.354l-106.7-68.97C221.1 239.5 216.9 239.5 213.5 241.4C210.1 243.3 208 247 208 251v137.9c0 4.008 2.104 7.705 5.5 9.656C215.1 399.5 216.9 400 218.7 400z"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        Double <br data-v-53eaa0e8=""><small data-v-53eaa0e8=""></small></span>
                        </a></li>
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="crash.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                              <path fill="currentColor" d="M171.4 174.3C174.4 163.2 185.8 156.6 196.1 159.6L299.9 187.1C325.9 194.1 341.3 220.8 334.4 246.8C327.4 272.8 300.7 288.2 274.7 281.2L265.9 278.9C265.5 278.8 265.1 278.7 264.7 278.6L282.5 309.3L294.5 302.4C301.2 298.5 309.7 300.8 313.5 307.4C317.4 314.1 315.1 322.6 308.4 326.5L260.2 354.3C253.6 358.1 245.1 355.9 241.2 349.2C237.4 342.5 239.6 334 246.3 330.2L258.4 323.2L240.6 292.5C240.5 292.9 240.4 293.3 240.3 293.6L237.9 302.5C230.1 328.5 204.3 343.9 178.3 336.9C152.3 329.1 136.9 303.2 143.8 277.3L171.4 174.3zM220.7 7.468C247.3-7.906 281.4 1.218 296.8 27.85L463.8 317.1C479.1 343.8 470 377.8 443.4 393.2L250.5 504.5C223.9 519.9 189.9 510.8 174.5 484.2L7.468 194.9C-7.906 168.2 1.218 134.2 27.85 118.8L220.7 7.468zM244.7 49.04L51.85 160.4C48.18 162.5 46.92 167.2 49.04 170.9L216.1 460.2C218.2 463.8 222.9 465.1 226.5 462.1L419.4 351.6C423.1 349.5 424.3 344.8 422.2 341.1L255.2 51.85C253.1 48.18 248.4 46.92 244.7 49.04H244.7zM324.1 499L459.4 420.9C501.3 396.7 515.7 343.1 491.5 301.1L354.7 64.25C356.5 64.08 358.2 63.1 360 63.1H584C614.9 63.1 640 89.07 640 119.1V456C640 486.9 614.9 512 584 512H360C346.4 512 333.8 507.1 324.1 498.1L324.1 499zM579.8 135.7C565.8 123.9 545.3 126.2 532.9 138.9L528.1 144.2L523.1 138.9C510.6 126.2 489.9 123.9 476.4 135.7C460.7 149.2 459.9 173.1 473.9 187.6L522.4 237.6C525.4 240.8 530.6 240.8 533.9 237.6L582 187.6C596 173.1 595.3 149.2 579.8 135.7H579.8z"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        Crash 
      </span>
                        </a></li>
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="tower.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                              <path fill="currentColor" d="M575.1 192h-102.2c3.551 10.11 5.748 20.73 5.748 31.77c0 25.64-9.984 49.75-28.12 67.89L320 423.2v24.84C320 483.3 348.7 512 383.1 512h191.1c35.35 0 63.1-28.65 63.1-63.1v-191.1C639.1 220.7 611.3 192 575.1 192zM479.1 376c-13.25 0-23.1-10.75-23.1-23.1c0-13.26 10.75-23.1 23.1-23.1s23.1 10.74 23.1 23.1C503.1 365.3 493.3 376 479.1 376zM447.5 223.8c0-16.38-6.249-32.76-18.75-45.26L269 18.73C256.5 6.238 240.3 0 223.1 0S191 6.238 178.5 18.73l-159.8 159.8C6.235 191-.0011 207.6-.0011 223.1s6.236 32.57 18.73 45.06l159.8 159.8c12.5 12.5 28.88 18.74 45.26 18.74s32.76-6.248 45.25-18.74l159.8-159.8C441.3 256.5 447.5 240.1 447.5 223.8zM394.9 235.1l-159.8 159.8c-4.076 4.076-8.838 4.686-11.31 4.686c-2.477 0-7.238-.6094-11.31-4.686L52.67 235.1C48.59 231 47.99 226.2 47.99 223.8s.6074-7.236 4.686-11.31l159.8-159.8c4.082-4.08 8.844-4.689 11.32-4.689s7.234 .6094 11.31 4.687l159.8 159.8c4.078 4.078 4.687 8.84 4.687 11.31S398.9 231 394.9 235.1zM223.8 301.6c-12.79 0-23.1 10.29-23.1 23.1c0 13.76 11.25 23.1 23.1 23.1c13.73 0 24-11.22 24-23.1C247.8 312.8 237.5 301.6 223.8 301.6zM223.8 199.8c-13.76 0-23.1 11.25-23.1 23.1c0 12.84 10.34 23.1 23.1 23.1c13.71 0 24-11.21 24-23.1C247.8 210.1 237.5 199.8 223.8 199.8zM121.9 199.8c-13.76 0-24 11.25-24 23.1c0 12.79 10.29 23.1 24 23.1c13.71 0 23.1-11.2 23.1-23.1C145.9 210.1 135.7 199.8 121.9 199.8zM325.6 199.8c-13.76 0-24 11.25-24 23.1c0 12.79 10.29 23.1 24 23.1c13.71 0 24-11.21 24-23.1C349.6 210.1 339.3 199.8 325.6 199.8zM223.8 97.94c-12.79 0-23.1 10.29-23.1 23.1c0 13.76 11.25 23.1 23.1 23.1c13.73 0 24-11.22 24-23.1C247.8 109.1 237.5 97.94 223.8 97.94z"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        Tower <br data-v-53eaa0e8=""><small data-v-53eaa0e8=""></small></span>
                        </a></li>
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="x-double.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                              <path d="M639.1 357.2c0-6.198-.4631-12.49-1.421-18.83l-27.5-181.3C603.5 107.4 581.8 32 319.1 32C57.05 32 36.44 106.9 28.83 157.1l-27.37 181.3C.4734 344.8 0 351.1 0 357.4C0 423.9 53.35 480 121.2 480c46.12-.125 88.37-26.5 108.6-68L243.6 384h152.7l13.75 28c20.25 41.5 62.25 67.88 108.4 68C586.5 480 639.1 423.8 639.1 357.2zM591.1 357.2c0 17.99-6.413 35.55-18.26 49.46c-13.66 16.14-33.73 25.38-54.82 25.38c-.1417 0-.2834-.0004-.4252-.0013c-27.75 0-52.75-15.75-65.25-41.13l-18.32-37.05C429.5 342.9 418.4 336 406.2 336H233.7c-12.17 0-23.29 6.907-28.69 17.82l-18.32 37.05c-4.671 9.482-23.54 41.13-65.92 41.13c-21.09 0-41.04-9.357-54.58-25.38c-11.85-13.91-18.26-31.47-18.26-49.46c0-3.839 .292-7.697 .8855-11.54l27.5-181.3C81.2 132.5 104.1 107.5 134.8 100.6C195.8 86.88 257.9 80 319.1 80s124.2 6.875 185.1 20.62c30.75 6.875 53.62 31.88 58.5 63.75l27.5 181.3C591.7 349.5 591.1 353.3 591.1 357.2zM399.1 240c-17.62 0-31.1 14.38-31.1 32s14.37 32 31.1 32s31.1-14.38 31.1-32S417.6 240 399.1 240zM247.1 200l-31.96-.011L215.1 168c0-13.2-10.78-24-23.98-24C178.8 144 167.1 154.8 167.1 168l.0367 31.99L135.1 200c-13.2 0-23.98 10.8-23.98 24c0 13.2 10.77 24 23.98 24l32.04-.0098L167.1 280c0 13.2 10.82 24 24.02 24c13.2 0 23.98-10.8 23.98-24l.0368-32.01L247.1 248c13.2 0 24.02-10.8 24.02-24C271.1 210.8 261.2 200 247.1 200zM463.1 144c-17.62 0-31.1 14.38-31.1 32s14.37 32 31.1 32c17.62 0 31.1-14.38 31.1-32S481.6 144 463.1 144z"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        X-Double
      </span>
                        </a></li>
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="index.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" lined="true">
                              <path d="M380.823 108.576L368 121.399L390.602 144L403.425 131.177C409.669 124.934 409.669 114.82 403.425 108.576S387.067 102.333 380.823 108.576ZM509.056 59.169L469.381 42.625L452.837 2.954C452.025 1.321 449.894 0 448.074 0C446.252 0 444.119 1.321 443.307 2.954L426.763 42.625L387.09 59.169C385.469 59.98 384.148 62.113 384.148 63.933C384.148 65.744 385.469 67.888 387.09 68.7L426.763 85.243L443.307 124.913C444.119 126.546 446.252 127.868 448.074 127.868C449.894 127.868 452.025 126.546 452.837 124.913L469.381 85.243L509.056 68.7C510.679 67.888 512 65.744 512 63.933C512 62.113 510.679 59.98 509.056 59.169Z" fill="currentColor" opacity="0.4"></path>
                              <path d="M425.68 179.527L332.646 86.496C324.219 78.068 310.555 78.068 302.127 86.496L279.547 109.076C257.207 100.879 233.182 96.176 208 96.176C93.125 96.176 0 189.301 0 304.176S93.125 512.176 208 512.176S416 419.051 416 304.176C416 278.994 411.297 254.967 403.1 232.627L425.68 210.049C434.107 201.621 434.107 187.957 425.68 179.527ZM208 192.176C146.25 192.176 96 242.426 96 304.176C96 313.019 88.844 320.176 80 320.176S64 313.019 64 304.176C64 224.769 128.594 160.176 208 160.176C216.844 160.176 224 167.332 224 176.176S216.844 192.176 208 192.176Z" fill="currentColor"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        Mines
      </span>
                        </a></li>
                      <li data-v-53eaa0e8="" class="nav-item flex-grow-1 text-center"><a data-v-53eaa0e8="" href="pg/tiger.php" class="nav-link" target="_self">
                          <div data-v-53eaa0e8="" class="btn btn-secondary icon"><svg data-v-53eaa0e8="" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" lined="true">
                              <path d="M193.5 222.625C224.375 214.5 239.875 172.625 228 129.25C221.5 105.375 208 86.25 192 75V0L128 80C113 97.75 107.5 127.75 116 158.75C127.875 202.125 162.5 230.75 193.5 222.625ZM318.5 222.625C349.5 230.75 384.125 202.125 396 158.75C404.5 127.75 399 97.75 384 80L320 0V75C304 86.25 290.5 105.375 284 129.25C272.125 172.625 287.625 214.5 318.5 222.625ZM108.75 243.375C101.5 219.375 83.875 201.5 64 194.875V128L18.5 190.375C6.5 206.875 0 226.75 0 247.125C0 254.001 1.125 261.25 3.25 268.625C13.625 303.25 45.75 325.75 74.875 318.75S119.125 278.001 108.75 243.375ZM493.5 190.375L448 128V195C428.125 201.5 410.5 219.375 403.25 243.375C392.875 278.001 408 311.75 437.125 318.75S498.375 303.25 508.75 268.625C510.875 261.375 512 254.125 512 247.125C512 226.75 505.5 206.875 493.5 190.375Z" fill="currentColor" opacity="0.4"></path>
                              <path d="M256 256C176.625 256 64 378.75 64 456.25C64 491.125 90.75 512 135.75 512C184.625 512 216.875 486.875 256 486.875C295.5 486.875 327.875 512 376.25 512C421.25 512 448 491.125 448 456.25C448 378.75 335.375 256 256 256Z" fill="currentColor"></path>
                            </svg></div> <span data-v-53eaa0e8="">
        Fortune<br data-v-53eaa0e8=""> <small data-v-53eaa0e8="">Tiger</small></span>
                        </a></li>
                      
                        
                     
                   
                      
                    </ul>
                  </div>
                  <section class="casino-section">
                   

                      <div  class="hidedesktop"  class="hide-mobile" data-v-b8b7e870="" class="casino-section casino-popular mb-3">
                      <header  data-v-b8b7e870="">
                        <div  data-v-b8b7e870=""  class="title_h3">Recomendados</div>
                      </header>
                      <!---->
                      <!---->
                      <div  data-v-b8b7e870="" class="row row__recommended">
                        
						<div  data-v-b8b7e870="" class="col item"><a data-v-b8b7e870="" href="" class="" target="_self"><img data-v-b8b7e870="" loading="lazy"  src="../storage.bullsbet.net/bullsbet/images/home/buttons/1694094848_mobile_btn0.jpg" alt="Banner3" width="264" height="416" class="desktop-action-btn img-fluid rounded"></a></div>
                        <div data-v-b8b7e870="" class="col item"><a data-v-b8b7e870="" href="" class="" target="_self"><img data-v-b8b7e870="" loading="lazy"   src="../storage.goldage.bet/goldage/images/home/buttons/1685402523_mobile_btn1.png" alt="Banner4" width="264" height="416" class="desktop-action-btn img-fluid rounded"></a></div>
                        <div data-v-b8b7e870="" class="col item"><a data-v-b8b7e870="" href="" class="" target="_self"><img data-v-b8b7e870="" loading="lazy"  src="../sistemasbet.b-cdn.net/banners%20principais/FORTUNE%20MOUSE.png" alt="Banner5" width="264" height="416" class="desktop-action-btn img-fluid rounded"></a></div>
                      </div>
                    </div>


				   <div   class="hide-mobile" data-v-b8b7e870="" class="casino-section casino-popular mb-3">
                      <header  data-v-b8b7e870="">
                        <div  data-v-b8b7e870=""  class="title_h3">Recomendados</div>
                      </header>
                      <!---->
                      <!---->
                      <div  data-v-b8b7e870="" class="row row__recommended">
                        
						<div  data-v-b8b7e870="" class="col item"><a data-v-b8b7e870="" href="index.php" class="" target="_self"><img data-v-b8b7e870="" loading="lazy"  src="img/dragon.png" alt="Banner3" width="264" height="416" class="desktop-action-btn img-fluid rounded"></a></div>
                        <div data-v-b8b7e870="" class="col item"><a data-v-b8b7e870="" href="index.php" class="" target="_self"><img data-v-b8b7e870="" loading="lazy"   src="img/mines.png" alt="Banner4" width="264" height="416" class="desktop-action-btn img-fluid rounded"></a></div>
                        <div data-v-b8b7e870="" class="col item"><a data-v-b8b7e870="" href="index.php" class="" target="_self"><img data-v-b8b7e870="" loading="lazy"  src="img/tiger.png" alt="Banner5" width="264" height="416" class="desktop-action-btn img-fluid rounded"></a></div>
                      </div>
                    </div>
					
					
                    <section data-v-de41b76c="" id="games-section-sliders">
					
					
					
	
				
					
                      <section data-v-3d6f2aec="" data-v-de41b76c="" class="games-slider">
                        <header data-v-3d6f2aec="" class="games-header">
                          <div data-v-3d6f2aec="" class="games-header__left">
                            <div data-v-3d6f2aec="" class="games-title">Pagando Muito</div>
                            <div data-v-3d6f2aec="" class="slider-navigation d-none d-sm-flex">
                              <div data-v-3d6f2aec="" class="slider-button slider-button-prev disabled"><svg data-v-3d6f2aec="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                  <path fill="currentColor" d="M41.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.3 256 246.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"></path>
                                </svg></div>
                              <div data-v-3d6f2aec="" class="slider-button slider-button-next"><svg data-v-3d6f2aec="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                  <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                </svg></div>
                            </div>
                          </div> 
                        </header>
                        <div data-v-3d6f2aec="" class="slider swiper swiper-initialized swiper-horizontal swiper-free-mode swiper-ios" style="">
                          <div data-v-3d6f2aec="" class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                           
                           
                            
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="pg/index.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="https://api-prod.mortalsoft.online/i/FortuneTiger.jpg" alt="Speed Roulette 1" width="165" height="165" class="" title="Speed Roulette 1">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Fortune Tiger</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Pg Soft
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="pg/mouse.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="../sistemasbet.b-cdn.net/imagens%20home/36427.png" alt="Live - BOOM CITY" width="165" height="165" class="" title="Live - BOOM CITY">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Fortune Mouse</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Pg Soft
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="pg/fortuneOX.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="../sistemasbet.b-cdn.net/imagens%20home/36428.png" alt="Auto-Roulette 1" width="165" height="165" class="" title="Auto-Roulette 1">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Fortune Ox</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Pg Soft
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="pg/PhoenixRises.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="../sistemasbet.b-cdn.net/pgsoft/rises.png" alt="Live - Mega Roulette" width="165" height="165" class="" title="Live - Mega Roulette">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Phoenix Rise</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Pg Soft
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="index.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="../sistemasbet.b-cdn.net/pgsoft/panda.jpg" alt="Live - PowerUp Roulette" width="165" height="165" class="" title="Live - PowerUp Roulette">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Fortune Panda</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Pg Soft
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="index.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="../sistemasbet.b-cdn.net/imagens%20home/27873.png" alt="Live - Sweet Bonanza CandyLand" width="165" height="165" class="" title="Live - Sweet Bonanza CandyLand">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">PlinkoX</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Smartsoft
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="index.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="../sistemasbet.b-cdn.net/imagens%20home/36391.jpg" alt="Roulette 2" width="165" height="165" class="" title="Roulette 2">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Penalty Shoot Out</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Evoplay
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                           
                           
                     
                           
                          </div>
                        </div>
                        <!---->
                        <div data-v-3d6f2aec="" class="slider-loading" style="display: none;"><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span></div>
                      </section>
					  
					  
                      <section data-v-3d6f2aec="" data-v-de41b76c="" class="games-slider">
                        <header data-v-3d6f2aec="" class="games-header">
                          <div data-v-3d6f2aec="" class="games-header__left">
                            <div data-v-3d6f2aec="" class="games-title">Exclusivos Clouver Bet™</div>
                            <div data-v-3d6f2aec="" class="slider-navigation d-none d-sm-flex">
                              <div data-v-3d6f2aec="" class="slider-button slider-button-prev disabled"><svg data-v-3d6f2aec="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                  <path fill="currentColor" d="M41.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.3 256 246.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"></path>
                                </svg></div>
                              <div data-v-3d6f2aec="" class="slider-button slider-button-next"><svg data-v-3d6f2aec="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                  <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                </svg></div>
                            </div>
                          </div> 
                        </header>
                        <div data-v-3d6f2aec="" class="slider swiper swiper-initialized swiper-horizontal swiper-free-mode swiper-ios swiper-backface-hidden" style="">
                          <div data-v-3d6f2aec="" class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                            <div data-v-3d6f2aec="" class="swiper-slide slide swiper-slide-active" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="crash.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="img/newGames/Crash.png" alt="Roleta Brasileira" width="165" height="165" class="" title="Roleta Brasileira">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Crash</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Clouver Bet
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide swiper-slide-next" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="dice.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="img/newGames/Dice.png" alt="Aviator" width="165" height="165" class="" title="Aviator">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Dice</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Clouver Bet
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="double.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="img/newGames/Double.png" alt="Mines" width="165" height="165" class="" title="Mines">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Double</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Clouver Bet
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                            
                            <div data-v-3d6f2aec="" class="swiper-slide slide" style="margin-right: 10px;">
                              <div data-v-39632cb5="" data-v-3d6f2aec="" class="swiper-slide casino-game"><a data-v-39632cb5="" href="tower.php" class="">
                                  <div data-v-39632cb5="" class="item-wrapper">
                                    <div data-v-39632cb5="" class="button"><button data-v-39632cb5="" class="btn btn-default"><svg data-v-39632cb5="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
                                          <path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z" fill="currentColor"></path>
                                        </svg>
                                        Jogar
                                      </button></div> <img data-v-39632cb5="" src="img/newGames/Tower.png" alt="Mini Roulette" width="165" height="165" class="" title="Mini Roulette">
                                    <footer data-v-39632cb5="">
                                      <div data-v-39632cb5="" class="title_h4">Tower</div>
                                      <div data-v-39632cb5="" class="title_h5">
                                        Clouver Bet
                                        <!---->
                                        <!---->
                                        <!---->
                                        <!---->
                                      </div>
                                    </footer>
                                  </div>
                                </a></div>
                            </div>
                           
                            
                          </div>
                        </div>
                        <!---->
                        <div data-v-3d6f2aec="" class="slider-loading" style="display: none;"><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span></div>
                      </section>
					  
					  
					  
                      
                      
					  
					
                      <!---->
                      <!---->
                     
                     
                     
					  
					 
					  
					  
                      <section data-v-3d6f2aec="" data-v-de41b76c="" class="games-slider">
                        <header data-v-3d6f2aec="" class="games-header">
                          <div data-v-3d6f2aec="" class="games-header__left">
                            <div data-v-3d6f2aec="" class="games-title">Estúdios</div>
                            <div data-v-3d6f2aec="" class="slider-navigation d-none d-sm-flex">
                              <div data-v-3d6f2aec="" class="slider-button slider-button-prev disabled"><svg data-v-3d6f2aec="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                  <path fill="currentColor" d="M41.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.3 256 246.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"></path>
                                </svg></div>
                              <div data-v-3d6f2aec="" class="slider-button slider-button-next"><svg data-v-3d6f2aec="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512">
                                  <path fill="currentColor" d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z"></path>
                                </svg></div>
                            </div>
                          </div> 
                        </header>
                        <!---->
                        <div data-v-3d6f2aec="" class="slider swiper swiper-initialized swiper-horizontal swiper-free-mode swiper-ios" style="">
                          <div data-v-3d6f2aec="" class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                            <div data-v-3d6f2aec="" class="swiper-slide slide swiper-slide-active" style="margin-right: 10px;">
                              <div data-v-5e2d0f4d="" data-v-de41b76c="" class="provider-game d-flex align-items-center justify-content-center" data-v-3d6f2aec=""><a data-v-5e2d0f4d="" href="casino/providers/pgsoft.php" class="">
                                  <div data-v-5e2d0f4d="" class="item-wrapper d-flex align-items-center justify-content-center"><img data-v-5e2d0f4d="" src="../sistemasbet.b-cdn.net/imagens%20home/PGS.png" alt="PG Soft"> <span data-v-5e2d0f4d="" class="badge badge-secondary">7</span></div>
                                </a></div>
                            </div>
                           
                           
                           
							
							
							

                                                 
                          </div>
                        </div>
                        <div data-v-3d6f2aec="" class="slider-loading" style="display: none;"><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span><span data-v-3d6f2aec=""></span></div>
                      </section>
                    </section>
                    <!---->
                  </section>
				   </div>
				
              </main>
			
     <div id="footer">
   
              <?php include('footer_pag.php'); ?>
	
    
	
  </body>
  

</html>
	
	
	

        </main>
		
	
	</div>

    <div class="popups">
        <div class="popup regras">
            <div class="popup-inner">
                <div class="popup-title">
                    REGRAS
                    <div class="popup-close">x</div>
                </div>
                <div class="content">
                    <p>- Coisas que vão te banir/silenciar:</p>
                    <ul>
                        <li>Spam</li>
                        <li>Implorando</li>
                        <li>Publicação de códigos de anúncio</li>
                        <li>Publicidade de outros sites</li>
                        <li>Usando um idioma diferente do português</li>
                        <li>Uso excessivo de capslock</li>
                        <li>Publicação de links para sites externos</li>
                    </ul>
                    <p>2 - Por favor, encaminhe todos os problemas para: <b style="color: #ffcc00;text-decoration: none !important;text-transform: none !important;"></b></p>
                    <p>3 - Por favor, encaminhe todas as dúvidas comerciais para: <b style="color: #ffcc00;text-decoration: none !important;text-transform: none !important;"></b></p>
                    <p>4 - Este site só atende clientes com 18 anos ou mais, Ao jogar, você concorda que atende ao requisito de idade legal.</p>
                    <p>5 - Mantenha o mínimo de palavrões, não chame outros usuários.</p>
                    <p>6 - BeyondOficial não assume nenhuma responsabilidade por apostas perdidas como resultado de latência de rede ou desconexões. Sempre garanta uma conexão estável antes de fazer apostas. Evite fazer apostas importantes no último segundo.</p>

                    <p><button class="popup-close">ENTENDO</button></p>
                </div>
            </div>
        </div>
        <form action="php/login/register.php" method="post">
          <div class="popup registerModal">
              <div class="popup-inner">
                  <div class="banner"><img src="img/Menu_imagem2.jpg" alt=""></div>
                  <div class="popup-register-double">
                      <div class="popup-title">
                          <h3>CADASTRE-SE</h3>
                          <div class="popup-close-register popup-close">X</div>
                      </div>
                      <div class="content">
            <br>
                          <div style="display:flex;flex-direction: column;margin-top: 30px;align-items:baseline">
                            
                
                <div class="relative" style="width: 100%;">
                                  <input class="inputRegister" style="width: 100%;padding-left: 28px" type="email" id="email" name="email" autocomplete="off" placeholder="Email" type="text" value="">
                                  <div style="font-size: 17px;top: 11px;" class="fa fa-envelope userIcon"></div>
                              </div>
                
                              <div class="relative" style="width: 100%;">
                                  <input class="inputRegister" style="width: 100%;padding-left: 28px" type="password" id="password" name="password" autocomplete="off" placeholder="Senha (6 a 22 caracteres)" type="text"  value="">
                                  <div style="font-size: 17px;top: 11px;" class="fa fa-lock userIcon"></div>
                              </div>
                
                              <div class="relative" style="width: 100%;">
                                  <input class="inputRegister" style="width: 100%;padding-left: 28px" type="password" id="confirmPassword" name="confirmPassword" autocomplete="off" placeholder="Confirmar Senha" type="text" value="">
                                  <div style="font-size: 17px;top: 11px;" class="fa fa-lock userIcon"></div>
                              </div>	
                
                          </div>		
              <br>
                          <div class="buttonBottom">
                <label for="" style="display:block;text-align: center;color: hsla(0, 0%, 100%, 0.5);font-size: 0.75rem;">Ao me cadastrar afirmo que tenho mais de 18 anos e aceito os termos de uso do site.</label>
                              <button class="register-button submit">Cadastrar</button>
                              <div class="flex flex-direction-row">Já tem conta aqui?<a class="login login-modal" style="margin-left:15px;">Fazer Login</a></div>
                          </div>

                          <script async>

                              $('#cpf1').mask('000.000.000-00', {reverse: true});

                              $('#phone1').mask('+55 (00) 00000-0009');
                              $('#phone1').blur(function (event) {
                                  if ($(this).val().length == 15) { // Celular com 9 dígitos + 2 dígitos DDD e 4 da máscara
                                      $(this).mask('+55 (00) 00000-0009');
                                  } else {
                                      $(this).mask('+55 (00) 00000-0009');
                                  }
                              });
                          </script>
                      </div>
                  </div>
              </div>
          </div>
        </form>  
        <form action="php/login/login.php" method="post">
          <div class="popup loginModal">
              <div class="popup-inner">
                  <div class="popup-title">
                      <h3>Login</h3>
                      <div class="popup-close-login popup-close">X</div>
                  </div>
                  <div class="content">
                      <div style="display:flex;flex-direction: column;margin-top: 30px;align-items:baseline;margin-bottom:20px;">
                          <div class="relative">
                              <input class="inputLogin" style="" type="email" id="loginEmail" name="loginEmail" autocomplete="off" placeholder="Email" type="text" value="">
                              <div style="font-size: 15px;top: 11px;" class="fa fa-envelope userIcon"></div>
                          </div>

                          <div class="relative">
                              <input class="inputLogin" style="" type="password" id="loginPassword" name="loginPassword" autocomplete="off" placeholder="Senha" type="text" value="">
                              <div style="font-size: 17px;top: 11px;" class="fa fa-lock userIcon"></div>
                          </div>

                          <div class="bottom-check flex flex-row w100" style="justify-content: space-between">
                              <div style="text-align: left; margin-top: 8px; font-size: 14px;display:flex;align-items:center">
                                  <input type="checkbox" style="margin-top: -2px;" class="check_box " id="i_agree_age"><label class="check_label" for="i_agree_age">Lembrar</label> 
                              </div>
                              <a href="#" class="txt-label forgetPss" style="margin-top: 8px;">Esqueceu a senha?</a>
                          </div>
                      </div>
                      <div class="buttonBottom">
                          <button class="login-button">Entrar</button>
                          <div class="flex flex-direction-row">Não tem login?<a class="register register-modal" style="margin-left:15px;">Cadastre-se</a></div>
                      </div>
                  </div>
              </div>
          </div>
        </form>  
        <div class="popup paymentModal">
            <div class="popup-inner" >
                <div class="popup-title">
                    <h3>Depósito</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
                <div class="content" style="margin-top: 20px;">
                    <div class="methods">
                        <div class="pix">
                            <svg xmlns="http://www.w3.org/2000/svg" width="79" height="80" viewBox="0 0 79 80" fill="none"><script xmlns="" async="false" type="text/javascript" src="#"/><path d="M61.2334 60.8114C58.1529 60.8114 55.2555 59.6119 53.0771 57.4346L41.3004 45.6575C40.4734 44.8284 39.0324 44.8309 38.2058 45.6575L26.386 57.4776C24.2076 59.655 21.3102 60.8544 18.2297 60.8544H15.9089L30.8246 75.7699C35.4827 80.428 43.0354 80.428 47.6938 75.7699L62.6519 60.8114H61.2334Z" fill="#32BCAD"/><path d="M18.2296 19.1545C21.3101 19.1545 24.2075 20.3539 26.3859 22.5313L38.2057 34.3532C39.0569 35.2048 40.4469 35.208 41.3002 34.3522L53.077 22.5744C55.2554 20.397 58.1528 19.1976 61.2332 19.1976H62.6517L47.694 4.23946C43.0352 -0.418972 35.4826 -0.418972 30.8245 4.23946L15.9094 19.1545L18.2296 19.1545Z" fill="#32BCAD"/><path d="M75.0245 31.57L65.9852 22.5307C65.7862 22.6104 65.5707 22.6602 65.3431 22.6602H61.2333C59.1085 22.6602 57.0285 23.522 55.5271 25.0245L43.7507 36.8013C42.6486 37.9034 41.2005 38.4548 39.7537 38.4548C38.3056 38.4548 36.8585 37.9034 35.7568 36.8024L23.9358 24.9815C22.4344 23.4786 20.3544 22.6172 18.2297 22.6172H13.1761C12.9606 22.6172 12.7592 22.5664 12.569 22.4948L3.49382 31.57C-1.16461 36.2284 -1.16461 43.7807 3.49382 48.4391L12.5687 57.5139C12.7592 57.4423 12.9606 57.3915 13.1761 57.3915H18.2297C20.3544 57.3915 22.4344 56.5301 23.9358 55.0276L35.7557 43.2077C37.8921 41.0731 41.6164 41.0724 43.7507 43.2087L55.5271 54.9845C57.0285 56.487 59.1085 57.3488 61.2333 57.3488H65.3431C65.5707 57.3488 65.7862 57.3985 65.9852 57.4783L75.0245 48.439C79.6825 43.7806 79.6825 36.2283 75.0245 31.5699" fill="#32BCAD"/></svg>
                            <div class="info"> 
                                <h3 class="w100">PIX</h3>
                                <div>Rápido e fácil!</div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>

        <form method="post">
          <div class="popup paymentPix">
              <div class="popup-inner" >
                  <div class="popup-title">
                      <h3>Depósito via Pix</h3>
                      <div class="popup-close-pix popup-close">x</div>
                  </div>
                  <div class="content" style="margin-top: 20px;">
                      <div class="methods">
                          <label for="pixvalue" class="txt-label">Informe o valor de depósito</label>
                          <div class="relative">
                              <input class="inputLogin" id="pixvalue" type="number" step="0.01" name="amount" autocomplete="off" placeholder="Mínimo de R$: 25,00" min="25" max="1000000" value="">
                              <div style="font-size: 17px;top: 11px;" class="fa fa-dollar userIcon"></div>
                          </div>
                          <div class="relative">
                              <input class="inputLogin" type="cpf" placeholder="Digite seu CPF" id="pixcpf" type="number" value="">
                              <div style="font-size: 15px;top: 11px;" class="fa fa-user userIcon"></div>
                          </div>
                      
                  </div>
                  <div class="buttonBottom">
                      <button class="deposit-button submit">Continuar</button>
                  </div>
              </div>
          </div>
        </form>

        <div class="popup withdrawPix">
            <div class="popup-inner">
                <div class="popup-title">
                    <h3>Saque via Pix</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
				
							<div class="content" style="margin-top: 20px;">
                    <div class="">
                        <a style="text-size: 22px">Atualização de dados necessária!<a>                        
                    </div>
                </div>
				
                <div class="buttonBottom">
                    <a href="/update" class="btn">Atualizar</a>
                </div>
						
			            </div>
        </div>

        <div class="popup withdrawPix">
            <div class="popup-inner">
                <div class="popup-title">
                    <h3>Saque via Pix</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
				
			                <div class="content" style="margin-top: 20px;">
                    <div class="methods">
                        <label for="withdrawvalue" class="txt-label">Informe o valor de saque e sua chave pix <span style="color: red;font-weight: bold">CPF<span></label>
                        <div class="relative">
                            <input class="inputLogin" id="withdrawvalue" type="number" autocomplete="off" placeholder="Mínimo de R$: 50,00" min="50" max="500" value="">
                            <div style="font-size: 17px;top: 11px;" class="fa fa-dollar userIcon"></div>
                        </div>
                        <div class="relative">
                            <input class="inputLogin" type="text" placeholder="Digite sua cahve pix (CPF)" id="chavepix" value="055.810.900-41" disabled>
                            <div style="font-size: 15px;top: 11px;" class="fa fa-user userIcon"></div>
                        </div>
                    </div>
                </div>
                <div class="buttonBottom">
                    <button id="withdraw-button" class="withdraw-button confirm-button">Sacar</button>
                </div>
			            </div>
        </div>
        
		
                <div class="popup forgetPasswordModal">
            <div class="popup-inner">
                <div class="popup-title">
                    <h3>Recuperar Senha</h3>
                    <div class="popup-close-login popup-close">X</div>
                </div>
				
				<div class="content">
                    <div style="display:flex;flex-direction: column;margin-top: 30px;align-items:baseline;margin-bottom:20px;">
                        <div class="relative" style="display: flex; flex-direction: row">
                            <input class="inputLogin" style="width: 170px;padding-left: 28px" type="email" autocomplete="off" placeholder="Seu email" value=""> <button class="sendCode">Enviar<br>Código</button>
                            <div style="font-size: 15px;top: 11px;" class="fa fa-envelope userIcon"></div>
                        </div>
                        <div class="relative">
                            <input class="inputLogin" style="width: 275px;padding-left: 28px" type="text" autocomplete="off" placeholder="Código recebido no email" value="">
                            <div style="font-size: 15px;top: 11px;" class="fa fa-user-secret userIcon"></div>
                        </div>
                        <div class="relative">
                            <input class="inputLogin" style="width: 275px;padding-left: 28px" type="password" autocomplete="off" placeholder="Senha Nova" value="">
                            <div style="font-size: 15px;top: 11px;" class="fa fa-lock userIcon"></div>
                        </div>
                    </div>
                    <div class="buttonBottom">
                        <button class="forgetButton changePassword">Mudar Senha</button>
                    </div>
                </div>
				
            </div>
        </div>
		        <div class="popup bonusModal">
            <div class="popup-inner" >
                <div class="popup-title">
                    <h3>Bônus</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
                <div class="content" style="margin-top: 20px;">
                    <div class="bonusDetails"> 
                                            </div>
                    <div class="buttonBottom">
                        <button class="removeBonus">REMOVER BÔNUS</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="popup bonusModal">
            <div class="popup-inner" >
                <div class="popup-title">
                    <h3>Ativar Código</h3>
                    <div class="popup-close-pix popup-close">x</div>
                </div>
                <div class="content" style="margin-top: 20px;">
                    <div class="bonusDetails"> 
                        <label for="promotioncode" class="txt-label">Informe o código que deseja ativar (É necessário depositar R$20,00 para ativar).</label>
                        <div class="relative">
                            <input class="inputLogin" id="promotioncode" style="width: 350px;" type="text" autocomplete="off" placeholder="Código promocional" value="">
                        </div>
                    </div>
                    <div class="buttonBottom">
                        <button class="activateBonus">ATIVAR BÔNUS</button>
                    </div>
                </div>
            </div>
        </div>    </div>



        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="js/anijs.js"></script>
<script src="js/helpers/dom/anijs-helper-dom.js"></script>
<script src='js/vendor.js'></script>
<script src="js/lang/en.js"></script>

<script src="js/progress.min.js"></script>
<script src="js/HackTimerWorker.min.js"></script>
<script src="js/HackTimer.silent.min.js"></script>
<script src="js/chat.js"></script>
<script src="js/app.js"></script>

<script>
    function atualizarSaldo() {
        $.ajax({
            url: 'php/login/atualizar_saldo.php',
            type: 'GET',
            success: function(response) {
                // Atualiza os elementos no HTML com os novos valores
                $('#balance').text(response.balance);
                $('#bonus').text(response.bonus);
                $('#total').text(response.total);
            }
        });
    }

    setInterval(atualizarSaldo, 10000); // Atualiza a cada 10 segundos
</script>


<script>
$(document).ready(function(){
    $("#loginForm").submit(function(event){
        event.preventDefault();

        $.ajax({
            type: "POST",
            url: "php/login/login.php",
            data: $(this).serialize(),
            success: function(data){
                // Aqui você pode lidar com a resposta do servidor
                location.reload(); // Recarrega a página para atualizar o estado de login
            }
        });
    });

    $("#registerForm").submit(function(event){
        event.preventDefault();

        $.ajax({
            type: "POST",
            url: "php/login/register.php",
            data: $(this).serialize(),
            success: function(data){
                // Aqui você pode lidar com a resposta do servidor
                location.reload(); // Recarrega a página para atualizar o estado de login
            }
        });
    });
});

</script>

<script>
		$(document).ready( function () {
							
									});
        // Function to request fullscreen on the iframe
        function requestFullscreen() {
            const iframe = document.getElementById('myIframe');
            if (iframe.requestFullscreen) {
                iframe.requestFullscreen();
            } else if (iframe.mozRequestFullScreen) { // Firefox
                iframe.mozRequestFullScreen();
            } else if (iframe.webkitRequestFullscreen) { // Chrome, Safari, and Opera
                iframe.webkitRequestFullscreen();
            } else if (iframe.msRequestFullscreen) { // IE/Edge
                iframe.msRequestFullscreen();
            }
        }

        // Get the button element by its ID
        const fullscreenButton = document.getElementById('fullscreenButton');

        // Add a click event listener to the button
        fullscreenButton.addEventListener('click', function() {
            requestFullscreen(); // Request fullscreen when the button is clicked
        });
    </script>
</body>

</html>
