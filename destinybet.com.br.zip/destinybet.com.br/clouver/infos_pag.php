<?php

$accessToken = 'APP_USR-5811039818886604-081320-9f8d802296d8280e199ef0b9f77583b2-1333160103'; // Substitua pela sua chave de acesso do Mercado Pago
$publicKey = 'APP_USR-b24923a5-2f11-44d9-b254-4723d0084cd0';     // Substitua pela sua chave pública do Mercado Pago
$baseURL = 'http://localhost/cassino2/www.clouverbet.com/index.php'; // Substitua pela URL base do seu projeto

\MercadoPago\SDK::setAccessToken($accessToken);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['amount'])) {
    $amount = floatval($_POST['amount']);
    $userReference = $_SESSION['user_id']; // Substitua pela forma como você identifica o usuário

    // Criar preferência de pagamento
    $preference = new \MercadoPago\Preference();
    
    $item = new \MercadoPago\Item();
    $item->title = 'Adição de Saldo';
    $item->quantity = 1;
    $item->unit_price = $amount;
    
    $preference->items = array($item);
    $preference->back_urls = [
        'success' => $baseURL . '/success.php',
        'failure' => $baseURL . '/failure.php',
        'pending' => $baseURL . '/pending.php'
    ];
    
    $preference->auto_return = 'approved';
    $preference->save();
    
    header('Location: ' . $preference->init_point);
    exit();
}

// Código de tratamento de webhook
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type']) && $_POST['type'] === 'payment') {
    $paymentId = $_POST['id'];

    // Consultar detalhes do pagamento
    $payment = \MercadoPago\Payment::find_by_id($paymentId);

    if ($payment) {
        $userId = $payment->external_reference; // Supondo que você use uma referência externa para identificar o usuário
        $amount = $payment->transaction_amount;
        $status = $payment->status;
        
        // Registrar a transação no banco de dados
        $conn = new mysqli('localhost', 'root', '', 'mercado-pago-api');
        if ($conn->connect_error) {
            die("Erro de conexão: " . $conn->connect_error);
        }

        $sql = "INSERT INTO transactions (user_id, amount, status, payment_id) VALUES ('$userId', '$amount', '$status', '$paymentId')";
        if ($conn->query($sql) === TRUE) {
            if ($status === 'approved') {
                // Atualizar o saldo do usuário no seu sistema
                $updateBalanceSql = "UPDATE users SET saldo = saldo + '$amount' WHERE id = '$userId'";
                if ($conn->query($updateBalanceSql) !== TRUE) {
                    echo "Erro ao atualizar saldo do usuário: " . $conn->error;
                }
            }
            http_response_code(200); // Responder ao Mercado Pago para confirmar o recebimento da notificação
        } else {
            echo "Erro ao registrar transação: " . $conn->error;
        }

        $conn->close();
    }
}

$balance = 0;

if(isset($_SESSION['id']) && isset($_SESSION['balance'])) {
    $sth = mysqli_query($conn, "SELECT balance FROM users WHERE id = '$_SESSION[id]'");
    while($st1=mysqli_fetch_assoc($sth)){
        $_SESSION['balance'] = $st1['balance'];
    }
} else {
    $_SESSION['balance'] = 0; // Define um valor padrão se o saldo não estiver definido na sessão
}

$bonus = 0;

if(isset($_SESSION['id']) && isset($_SESSION['bonus'])) {
    $sth = mysqli_query($conn, "SELECT bonus FROM users WHERE id = '$_SESSION[id]'");
    while($st1=mysqli_fetch_assoc($sth)){
        $_SESSION['bonus'] = $st1['bonus'];
    }
} else {
    $_SESSION['bonus'] = 0; // Define um valor padrão se o saldo não estiver definido na sessão
}


$total = $_SESSION['balance'] + $_SESSION['bonus'];
?>