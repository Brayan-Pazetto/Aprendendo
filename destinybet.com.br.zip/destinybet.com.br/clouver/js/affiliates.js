$(function () {
    "use strict";


    var dTip = {
        _tip: null,
        init: function() {
            this._tip = $('<div id="tip"> <div class="arrow"></div> <div class="tip-label"></div> <div class="content"></div> </div>').appendTo('body');

            var self = this;
            $('*[data-tip]')
                .hover(function(){
                    if($(this).data('ltip')) {
                        self._tip
                            .find('.tip-label')
                            .text($(this).data('ltip'));
                    }
                    self._tip
                        .find('.content')
                        .html($(this).data('tip'));
                    self._tip.fadeIn('fast');
                }, function() {
                    self._tip.hide();
                })
                .mousemove(function(e) {
                    self._tip.css({
                        'top': (e.pageY-self._tip.height()-20) + 'px',
                        'left': (e.pageX-125) + 'px'
                    });
                });
        } 
    };
    dTip.init();

    $('button#set-code-button').click(function() {
        socket.emit('update ref', $('input#set-code').val());
        location.reload();
    });
    
    $('#withdraw-refs-button').on('click', function () {
        $.ajax({
            url: '/api/affiliates-collect',
            type: 'POST',
            data: {
               targetSID: $('meta[name="email"]').attr('content')
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            dataType: 'json',
            success: function (data) {
                if (!data.success) return notify('error', locale[data.reason]);
                notify('success', 'Ganhos de afiliados retirados!');
                return location.reload();
            }
        });
    });
    $(function(){
        function secondsTimeSpanToHMS(s) {
            var h = Math.floor(s/3600);
            s -= h*3600;
            var m = Math.floor(s/60);
            s -= m*60;
            return (h < 10 ? '0'+h : h)+":"+(m < 10 ? '0'+m : m)+":"+(s < 10 ? '0'+s : s);
        }
        function reload($div) {
            var left = parseInt($div.attr('data-timeleft'));

            if (left <= 0) {
                $div
                    .addClass("lime")
                    .removeClass("reload-time")
                    .text("CHECK NICK");
            } else {
                $div
                    .text(secondsTimeSpanToHMS(left))
                    .attr('data-timeleft', left-1);
                setTimeout(function () {
                    reload($div)
                }, 1000);
            }
        }
        var $freeCoinsTimer = $("button.reload-time");
        if ($freeCoinsTimer.length)
            reload($freeCoinsTimer);
    });
})