var csrftoken = $('meta[name="csrf-token"]').attr('content');
var websocket = $('meta[name="websocket"]').attr('content');
var lang = $('meta[name="language"]').attr('content');
var themecolor = $('meta[name="themecolor"]').attr('content');
var logged = $('meta[name="logged"]').attr('content') === '1';
var id = $('meta[name="id"]').attr('content');
var email = $('meta[name="email"]').attr('content');
var username = $('meta[name="username"]').attr('content');
var avatar = $('meta[name="avatar"]').attr('content');
var token = $('meta[name="token"]').attr('content');
var time = $('meta[name="time"]').attr('content');
var game = $('meta[name="game"]').attr('content');

$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': csrftoken } });

var socket = io(':8443', { transports: ['websocket'] });

let forgetingPassword = false;

socket.on('connect', function () {
  socket.emit('init', {
    lang: lang,
    game: game,
    logged: logged,
    email: email,
    username: username,
    avatar: avatar,
    token: token,
    time: time
  });

  setTimeout(function () {
    $('.loader').css('display', 'none')
  }, 400);
});

function validadeCpf(cpf) {
  cpf = cpf.replace(/\D/g, '');
  if (cpf.toString().length != 11 || /^(\d)\1{10}$/.test(cpf)) return false;
  var result = true;
  [9, 10].forEach(function (j) {
    var soma = 0, r;
    cpf.split(/(?=)/).splice(0, j).forEach(function (e, i) {
      soma += parseInt(e) * ((j + 2) - (i + 1));
    });
    r = soma % 11;
    r = (r < 2) ? 0 : 11 - r;
    if (r != cpf.substring(j, j + 1)) result = false;
  });
  return result;
}

function telefone_validation(telefone) {
  //retira todos os caracteres menos os numeros
  telefone = telefone.replace(/\D/g, '');

  //verifica se tem a qtde de numero correto
  if (!(telefone.length >= 10 && telefone.length <= 11)) return false;

  //Se tiver 11 caracteres, verificar se começa com 9 o celular
  if (telefone.length == 11 && parseInt(telefone.substring(2, 3)) != 9) return false;

  //verifica se não é nenhum numero digitado errado (propositalmente)
  for (var n = 0; n < 10; n++) {
    //um for de 0 a 9.
    //estou utilizando o metodo Array(q+1).join(n) onde "q" é a quantidade e n é o
    //caractere a ser repetido
    if (telefone == new Array(11).join(n) || telefone == new Array(12).join(n)) return false;
  }
  //DDDs validos
  var codigosDDD = [11, 12, 13, 14, 15, 16, 17, 18, 19,
    21, 22, 24, 27, 28, 31, 32, 33, 34,
    35, 37, 38, 41, 42, 43, 44, 45, 46,
    47, 48, 49, 51, 53, 54, 55, 61, 62,
    64, 63, 65, 66, 67, 68, 69, 71, 73,
    74, 75, 77, 79, 81, 82, 83, 84, 85,
    86, 87, 88, 89, 91, 92, 93, 94, 95,
    96, 97, 98, 99];
  //verifica se o DDD é valido (sim, da pra verificar rsrsrs)
  if (codigosDDD.indexOf(parseInt(telefone.substring(0, 2))) == -1) return false;

  //  E por ultimo verificar se o numero é realmente válido. Até 2016 um celular pode
  //ter 8 caracteres, após isso somente numeros de telefone e radios (ex. Nextel)
  //vão poder ter numeros de 8 digitos (fora o DDD), então esta função ficará inativa
  //até o fim de 2016, e se a ANATEL realmente cumprir o combinado, os numeros serão
  //validados corretamente após esse período.
  //NÃO ADICIONEI A VALIDAÇÂO DE QUAIS ESTADOS TEM NONO DIGITO, PQ DEPOIS DE 2016 ISSO NÃO FARÁ DIFERENÇA
  //Não se preocupe, o código irá ativar e desativar esta opção automaticamente.
  //Caso queira, em 2017, é só tirar o if.
  if (new Date().getFullYear() < 2017) return true;
  if (telefone.length == 10 && [2, 3, 4, 5, 7].indexOf(parseInt(telefone.substring(2, 3))) == -1) return false;

  //se passar por todas as validações acima, então está tudo certo
  return true;
}

function notify(type, message) {
  var color = '#545454';
  if (type === 'error') {
    color = '#de2a2a';
  } else if (type === 'success') {
    color = '#35ae35';
  }

  $.amaran({
    content: {
      color: '#fff',
      message: message
    },
    theme: 'colorful',
    position: 'bottom middle',
    inEffect: 'slideBottom',
    outEffect: 'slideBottom',
    delay: 7500
  })
  $('.amaran').last().css('border-left', '2px solid ' + color);
}

function copyToClipboard(text) {
  var sampleTextarea = document.createElement("textarea");
  document.body.appendChild(sampleTextarea);
  sampleTextarea.value = text; //save main text in it
  sampleTextarea.select(); //select textarea contenrs
  document.execCommand("copy");
  document.body.removeChild(sampleTextarea);
}

function validateEmail(email) {
  return email.match(
    /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  );
}

var _soundOn = true;
var $el = $(".sidespan");

$("#menuClick").click(function () {
  if ($('.nav-dropdown').hasClass('hidden') == false) {
    $('.nav-dropdown').addClass('hidden');
  } else {
    $('.nav-dropdown').removeClass('hidden');
  }
});

$("#menuClick-mobile").click(function () {
  if ($('.nav-dropdown').hasClass('hidden') == false) {
    $('.nav-dropdown').addClass('hidden');
  } else {
    $('.nav-dropdown').removeClass('hidden');
  }
});

$(".click-open-menu").click(function () {
  //console.log("Menu");
  if ($('.right').hasClass('mobile-show') == false) {
    $('.right').addClass('mobile-show');
    //console.log("Add");
  } else {
    $('.right').removeClass('mobile-show');
    //console.log("Removeu");
  }
});

$(function () {
  
  var siteToggle = {
    $nav: $(".navbar2"),
    $snav: $(".sidebar-nav"),
    $spanside: $(".sidespan"),
    $so: $(".online"),
    $wc: $(".welcome1"),
    $chat: $(".chat"),
    $chatfooter: $(".footer"),
    $sendarea: $(".send-area"),
    $onesignal: $(".onesignal-bell-launcher-button"),
    $legalarea: $(".legal"),
    $chatmessages: $(".chat-messages"),
    $chatheader0: $(".chatheader0"),
    $copyright0: $(".copyright0"),
    $chatheader1: $(".chatheader1"),
    $copyright1: $(".copyright1"),
    $container: $(".main-wrapper"),
    $freeCoinsArea: $("nav .free-coins-area"),
    $giveawayArea: $("nav .giveaway-area"),
    $loginArea: $('nav .navbar-player'),
    $chatToggle: $(".chat-toggle-icon"),
    $chatToggleShow: $(".chat-toggle-button-green"),
    $menuToggle: $(".navbarOpen"),
    $soundToggle: $(".sound-toggle-button"),
    $main: $("main"),
    _animateDuration: 600,
    _depositProgress: false,
    $balance: $(".balance"),
    $balanceValue: $(".userDetails .value"),
    changeMenuSize: function () {
      this.resize();
    },
    menuToggle: function () {
      if (this.$snav.hasClass("sidebarshow")) {
        this.$snav.removeClass("sidebarshow");
        this.$spanside.addClass("sidespaninvisible");
        this.$wc.addClass("welcome1hide");
        this.$so.removeClass("sidebarshow1");
        this.$menuToggle.find('i').attr('class', 'fa fa-bars');

        if (!this.$chat.hasClass('hidden')) {
          this.$container.addClass("menu-part-hide");
        }
        this.$container.removeClass("menu-part-hide-navbar");
        this.$container.removeClass("menu-part-hide-all");
        localStorage.setItem("toggleMenu", "hide");
      } else {
        this.$snav.addClass("sidebarshow");
        setTimeout(function () {
          $el.removeClass("sidespaninvisible");
          $el.addClass("sidespanvisible");
        }, 290);
        this.$wc.removeClass("welcome1hide");
        this.$so.addClass("sidebarshow1");
        this.$menuToggle.find('i').attr('class', 'fa fa-bars');
        if (this.$container.hasClass('menu-part-hide')) {
          this.$container.removeClass("menu-part-hide");
          this.$container.addClass("menu-part-hide-navbar");
        } else {
          this.$container.addClass("menu-part-hide-all");
        }
        localStorage.setItem("toggleMenu", "show");
      }
      this.changeMenuSize();
      this.balance();
      this.crash();
    },
    chatToggle: function () {
      if (this.$container.hasClass('menu-part-hide-all')) {
        this.$container.removeClass('menu-part-hide-all');
        this.$container.addClass('menu-part-hide-navbar');
      } else if (this.$container.hasClass('menu-part-hide-navbar')) {
        this.$container.addClass('menu-part-hide-all');
        this.$container.removeClass('menu-part-hide-navbar');
      } else {
        this.$container.addClass('menu-part-hide');
      }

      $('.chat').removeClass('hidden');
      $('.openChat').addClass('hidden');
    },
    chatDisable: function () {
      if (this.$container.hasClass('menu-part-hide-all')) {
        this.$container.removeClass('menu-part-hide-all');
        this.$container.addClass('menu-part-hide-navbar');
      } else if (this.$container.hasClass('menu-part-hide-navbar')) {
        this.$container.addClass('menu-part-hide-all');
        this.$container.removeClass('menu-part-hide-navbar');
      } else {
        this.$container.removeClass('menu-part-hide');
      }

      $('.chat').addClass('hidden');
      $('.openChat').removeClass('hidden');
    },
    crash: function () {
      if (typeof crash != "undefined") {
        $("<div />")
          .css("step", 1)
          .animate({
            step: siteToggle._animateDuration
          }, {
            duration: siteToggle._animateDuration,
            step: function () {
              crash.resize();
            }
          });
      }
    },
    soundToggle: function () {
      if (_soundOn) {
        this.$soundToggle.find('i').attr('class', 'fa fa-volume-off');
        localStorage.setItem("toggleSound", "hide");
        _soundOn = false;
      } else {
        this.$soundToggle.find('i').attr('class', 'fa fa-volume-up');
        localStorage.setItem("toggleSound", "show");
        _soundOn = true;
      }
    },
    resize: function () {
      this.$nav.css('left', -1 * $(window).scrollLeft());
      this.$nav.scrollTop(this.$main.scrollTop() + this.$container.scrollTop() + $("body").scrollTop());
      this.$main.css('min-height', $(this.$nav)[0].scrollHeight - 92);
    },
    init: function () {
      $(window).resize(this.resize.bind(this));
      $(window).scroll(this.resize.bind(this));
      this.$main.scroll(this.resize.bind(this));
      this.$container.scroll(this.resize.bind(this));
      siteToggle.resize();

      var body = $("body");
      body.addClass("offToggleTransition");
      this.$menuToggle.click(this.menuToggle.bind(this));
      this.$soundToggle.click(this.soundToggle.bind(this));
      //if (localStorage.getItem("toggleMenu")=="hide") this.menuToggle();
      if (localStorage.getItem("toggleSound") == "hide") this.soundToggle();
      setTimeout(function () {
        body.removeClass("offToggleTransition");
      }, 1);
      this.changeMenuSize();
    },
    balance: function () {

    }
  };
  siteToggle.init();


  function validateEmail(email) {
    return email.match(
      /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
  }
  
  function validatePassword(password) {
    return password.match(
	
      /^[a-zA-Z0-9!@$^&*]{2,22}$/
	  
    );
  }
  
  function popup() {
    popupClose();
    var $div = $(".popup:eq(0)");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  function popupLogin() {
    popupClose();
    var $div = $(".popup:eq(2)");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  function popupForget() {
    popupClose();
    var $div = $(".popup:eq(4)");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  function popupRegister() {
    popupClose();
    var $div = $(".popup:eq(1)");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  function depositModal() {
    popupClose();
    console.log("Teste")
    var $div = $(".popup:eq(3)");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  function withdrawModal() {
    popupClose();
    var $div = $(".withdrawPix");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  function popupPix() {
    popupClose();
    var $div = $(".pixCode");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  }

  $(".login-button").click(function () {
    let email = $(".popup:eq(2) input:eq(0)").val();
    let password = $(".popup:eq(2) input:eq(1)").val();

    if (validateEmail(email) != null) {

      socket.emit('login user', {
        email: email,
        password: password
      })

    } else {
      notify('error', 'Erro! Formato de Email Inválido.');
    }

  });

  $(".icon-menu").click(function () {
    if ($('.navbar').hasClass('nav-mobile')) {
      $('.navbar').removeClass('nav-mobile');
    } else {
      $('.navbar').addClass('nav-mobile');
    }
  })

  $('.changePassword').click(function () {
    let email = $('.forgetPasswordModal .inputLogin:eq(0)').val();
    let code = $('.forgetPasswordModal .inputLogin:eq(1)').val();
    let password = $('.forgetPasswordModal .inputLogin:eq(2)').val();
    if (validateEmail(email) != null) {
      socket.emit('change password', { email: email, code: code, password: password })
      popupClose();
    } else {
      notify('error', 'Erro! Formato de Email Inválido.');
    }
  });

  $('.removeBonus').click(function () {
    socket.emit('remove bonus')
  });

  $('.bonus-modal').click(function () {
    popupClose();
    var $div = $(".popup:eq(8)");
    if ($div.css("display") == "flex") {
      $div.css('display', 'none');
    } else {
      $div.css('display', 'flex');
    }
  });
  $('.sendCode').click(function () {
    let email = $('.forgetPasswordModal .inputLogin:eq(0)').val();
    if (forgetingPassword) {
      notify('error', 'Você já solicitou o código, espere um momento.');
      return;
    }
    if (validateEmail(email) != null) {
      forgetingPassword = true;
      socket.emit('forget code', { email: email })
      notify('success', 'E-mail enviado com sucesso.');
    } else {
      notify('error', 'Erro! Formato de Email Inválido.');
    }
  });

  $(".register-button").click(function () {    
    let email = $(".popup:eq(1) input:eq(0)").val();
    let password = $(".popup:eq(1) input:eq(1)").val();
    let passwordRepeat = $(".popup:eq(1) input:eq(2)").val();    

    if (!validateEmail(email)) {
      return notify('error', 'Erro! Formato de Email Inválido.');
    }
	
	if (!validatePassword(password)) {
      return notify('error', 'Esse caractere expecial no campo senha não é permitido. Tente usar algum desses !@$^&*');
    }
		
	if (password.length < 6) {
      return notify('error', 'Sua senha precisa ter no mínimo 6 caracteres.');
    }
	
	if (password.length > 22) {
      return notify('error', 'Sua senha precisa ter no máximo 22 caracteres.');
    }

    if (!password || !passwordRepeat) {
      return notify('error', 'Erro! Por favor insira a senha e a confirme.');
    }

    if (password !== passwordRepeat) {
      return notify('error', 'Erro! As senhas não coincidem, tente escrever novamente.');
    }

    if (email && password) {
      socket.emit('register user', {
        username: email,
        email: email,
        password: password,
      })

      notify('success', 'Cadastrado com sucesso... Divirta-se!');
    }
  });

  function popupClose() {
    $('.popup:eq(0)').fadeOut(300);
    $('.popup:eq(1)').fadeOut(300);
    $('.popup:eq(2)').fadeOut(300);
    $('.popup:eq(3)').fadeOut(300);
    $('.popup:eq(4)').fadeOut(300);
    $('.popup:eq(5)').fadeOut(300);
    $('.popup:eq(6)').fadeOut(300);
    $('.popup:eq(7)').fadeOut(300);
    $('.popup:eq(8)').fadeOut(300);
    $('.popup:eq(9)').fadeOut(300);
  }

  $(".chat-info").click(popup);
  $(".popup-close").click(popupClose);
  $(".login-modal").click(popupLogin);
  $(".forgetPss").click(popupForget);
  $(".register-modal").click(popupRegister);
  $(".deposit-modal").click(depositModal)
  $(".withdraw-modal").click(withdrawModal)


  $(".closeChat").click(function () {
    siteToggle.chatDisable();
  });

  $(".paymentModal .pix").click(function () {
    popupClose();

    $('.popup:eq(4)').css('display', 'flex');
  })

  $("#claimRewardCode").click(function () {
    $('.popup:eq(9)').css('display', 'flex');
  });

  $(".openChat").click(function () {
    siteToggle.chatToggle();
  });

  $(".chat-toggle-icon").click(function () {
    siteToggle.chatDisable();
  })

  $(".icon-chat").click(function () {
    siteToggle.chatToggle();
  });

  var balance = $('.balance');
  var balanceValue = $(".userDetails .value");

  $('.deposit-button').on('click', function () {
    if (siteToggle._depositProgress) return;
    let pix = $('#pixvalue').val();
    let cpf = $('#pixcpf').val();
    if (cpf.length >= 11) {
      if (parseFloat(pix) >= 25) {
        if (parseFloat(pix) >= 1) {
          if (validadeCpf(cpf)) {
            socket.emit('deposit pix', { amount: parseFloat(pix), cpf: cpf, bonus: $('#i_agree_bonus').prop('checked') });

            notify('success', "Depósito solicitado, aguarde alguns segundos para aparecer seu código QR.");
            $(this).addClass('disabled');
            siteToggle._depositProgress = true;
          } else {
            notify('info', "CPF Inválido, tente novamente com um válido.");
          }
        }
      } else {
        notify('info', "Mínimo de depósito -> R$: 25");
      }
    } else {
      notify('info', "CPF Inválido, tente novamente com um válido.");
    }
  });

  $('.activateBonus').on('click', function () {
    let bonuscode = $('#promotioncode').val();
    if (bonuscode.length > 0) {
      socket.emit('activate bonus', { code: bonuscode });
    }
  });

  $('.pixCode .copy').on('click', function () {
    copyToClipboard($('#pixtext').val());
  });

  $('.confirm-button').on('click', function () {
    $('.confirm-button').attr('disabled', true);
    let pixamount = parseFloat(parseFloat($('#withdrawvalue').val()).toFixed(2));
    let pix = $('#chavepix').val();
    if (pixamount > 49 && pixamount <= 500) {
      pix = pix.replace(/[^0-9]/g, '');

      if (pix.length == 11) {
        popupClose();
        socket.emit('withdraw', { pix: pix, pixamount: pixamount });
        $('.confirm-button').attr('disabled', false);
      } else {
        notify('info', "A chave pix precisa ser remetente ao seu CPF.");
      }
    } else {
      notify('info', "Mínimo de saque: R$ 50 e máximo de: R$ 500");
    }
  });

  socket.on('deposit success', function (tradeID) {

  });

  socket.on('deposit error', function () {

  });

  socket.on('users online', function (count) { $('.players-online').text(count); });

  socket.on('register success', function (details) {
    window.location.replace('/auth/login/' + details.email + '/' + details.username + '/' + details.password + '/' + details.name + '/' + details.last_name + '/' + details.cpf + '/' + details.phone)
  })

  socket.on('login success', function (details) {
    window.location.replace('/auth/login/' + details.email + '/null/' + details.password + '/null/null/null/null')
  });

  socket.on('notify', function (type, message, data) {
    if (locale[message]) message = locale[message];
    data = data || [];
    notify(type, vsprintf(message, data));
  });

  socket.on('payment pix', function (info) {
    let code = info.code;
    let value = info.value;
    let text = info.text;

    $('#pixtext').val(text);
    $('#pix').attr("src", code);
    $('#valuepix').text(parseFloat(value).toFixed(2));
    popupClose();
    popupPix();
  })

  socket.on('balance change', function (value) {
    balance.data('balance', parseFloat(balance.data('balance') + value));
    balance.html(parseFloat(balance.data('balance')).toFixed(2));
    siteToggle.balance();
  });

  socket.on('xp change', function (details) {
    $('.level-bar .progress').css('width', ((details.newXP / (8000 + (600 * details.level))) * 100) + '%')
    $('.level span:eq(1)').html(details.level);
  });

  window.bal = function (value) {
    balance.data('balance', parseFloat(balance.data('balance') + value));
    balance.html(parseFloat(balance.data('balance')).toFixed(2));
    siteToggle.balance();
  }

});


Number.prototype.parseValue = function () {
  return this.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
};
