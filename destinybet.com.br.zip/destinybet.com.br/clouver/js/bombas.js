document.addEventListener('DOMContentLoaded', () => {
    let saldo = parseInt(document.getElementById('balance').dataset.balance);
    let minas = 0;
    let squares = [];
    let bombLocations = [];
    let gameStarted = false;
    let betAmount = 0;

    function createBoard() {
        const minesweeper = document.querySelector('.minesweeper');
        for (let i = 0; i < 20; i++) {
            const square = document.createElement('div');
            square.classList.add('square');
            square.dataset.index = i;
            square.addEventListener('click', handleClick);
            squares.push(square);
            minesweeper.appendChild(square);
        }
    }

    function generateBombs() {
        bombLocations = [];
        for (let i = 0; i < minas; i++) {
            let randomIndex;
            do {
                randomIndex = Math.floor(Math.random() * squares.length);
            } while (bombLocations.includes(randomIndex));
            bombLocations.push(randomIndex);
        }
    }

    function handleClick() {
        if (!gameStarted) return;

        const index = this.dataset.index;
        if (bombLocations.includes(Number(index))) {
            this.textContent = '💣';
            this.style.backgroundColor = '#f00';
            setTimeout(() => {
                resetGame();
            }, 300);
        } else {
            this.textContent = '💎';
            betAmount += 2;
            saldo += 0;
            document.getElementById('result').textContent = ``;
            document.getElementById('balance').textContent = `${saldo},00`;
        }

        this.removeEventListener('click', handleClick);
    }

    function resetGame() {
        const minesweeper = document.querySelector('.minesweeper');
        minesweeper.innerHTML = '';
        squares = [];
        bombLocations = [];
        gameStarted = false;
        document.getElementById('result').textContent = ``;
        document.getElementById('action').textContent = 'Iniciar Jogo';
    }

    function startGame() {
        betAmount = parseInt(document.getElementById('bet').value);

        if (betAmount > saldo) {
            alert('Você não possui saldo suficiente para essa aposta.');
            return;
        }

        saldo -= betAmount;
        document.getElementById('balance').textContent = `${saldo},00`;

        minas = parseInt(document.getElementById('mines').value);

        gameStarted = true;
        document.getElementById('result').textContent = ``;
        createBoard();
        generateBombs();
        document.getElementById('action').textContent = 'Resgatar';
    }

    function checkbalance() {
        const betAmount = parseInt(document.getElementById('bet').value);

        if (saldo >= betAmount) {
            saldo -= betAmount;
            document.getElementById('balance').textContent = '' + saldo;
            return true;
        } else {
            alert('Você não possui saldo suficiente para essa aposta.');
            return false;
        }
    }

    function resgatarSaldo() {
        saldo += betAmount;
        document.getElementById('balance').textContent = `${saldo},00`;
        resetGame();
    }

    function handleActionClick() {
        if (gameStarted) {
            resgatarSaldo();
        } else {
            startGame();
        }
    }

    document.getElementById('action').addEventListener('click', () => {
        handleActionClick();
    });
});