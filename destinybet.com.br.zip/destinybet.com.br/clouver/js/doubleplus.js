
$(function() {
    "use strict";
	var iiCrown = 0;
	var iCrown;
    window.roulette = ({
        _rolling: false,
        _timeLeft: 0,
        _maxTime: 30 * 100,
        _order: [0, 11, 5, 10, 6, 9, 7, 8, 1, 14, 2, 13, 3, 12, 4],
        _position: 0,
        _bets: {
            red: [],
            green: [],
            black: []
        },
        sounds: {
            roll: new buzz.sound('/sounds/rolling.wav', {preload: true}),
            tone: new buzz.sound('/sounds/tone.wav', {preload: true})
        },
        set timeLeft(x) {
            this._timeLeft = x;
            this.updateTimer();
        },
        get timeLeft() {
            return this._timeLeft;
        },
        _numberToColor: function(num) {
            if (num === 0) { return 'green'; }
            else if (num < 8) { return 'red'; }
            else { return 'black'; }
        },
        _tileWidth: 132,
        _wheel: $('.roulette-wheel'),
        rotateAnimation: function(res) {
            console.log(res)
            $('.animation .item:eq(499)').html(`
            <div class="number" style="display: flex; align-items: center; justify-content: center;">
                x ` + res.number + `
            </div>`)
            $('.animation').css('transition', 'height 250ms ease 0s, transform 5000ms cubic-bezier(0.15, 0.8, 0.2, 0.95)');
            $('.animation').css('transform', 'translateX(calc(-' + res.random + 'px))');
      
            setTimeout(function() {
      
              $('.progress .text').text('ESPERANDO PRÓXIMA RODADA')
              $('.scroll').css('background-image', '');
              $('.scroll').css('background-size', '');
              $('.scroll').css('animation', '');
              $('.scroll').css('background-color', '#3c4041');
              $('.scroll').css('position', 'relative');
              $('.scroll').css('width', '100%');
      
              $('.animation .item').css('opacity', '0.4');
              $('.animation .item:eq(499)').css('opacity', '1');
    
      
              setTimeout(function() {
                $('.animation').css('transition', 'height 250ms ease 0s, transform 50ms cubic-bezier(0.15, 0.8, 0.2, 0.95)');
      
                $('.animation .item').css('opacity', '1');
                $('.animation .item:eq(499)').css('opacity', '1');
      
                $('.scroll').css('background-image', '');
                $('.scroll').css('background-size', '');
                $('.scroll').css('animation', '');
                $('.scroll').css('background-color', 'rgba(255, 174, 0)');
                $('.scroll').css('position', 'relative');
                $('.scroll').css('width', '100%');
      
                setTimeout(function() {
                  $('.animation').css('transform', 'translateX(calc(-55400px))');
    
                }, 600);
              }, 4500);
            }, 6000);
        },
        positionFix: function() {
            if (this._rolling) return;
            this._wheel.css({'background-position-x': -1 * (this._position - (this._wheel.width() - this._tileWidth*15) / 2)});
			
        },
        updateHistory: function(numbers) {
            let quantity = 0;
            let history = '';
            numbers.reverse();
            numbers.forEach(function(number) {
                if(quantity > 25) return;
                history += `<div class="item" style="color: ` + (number >= 2 ? 'rgb(255, 174, 0)' : '#8d8ea0') + `"> x ` + number + ` </div>`
                quantity++;
            })
            $('.history-items').empty();
            $('.history-items').html(history);
        },
        newRound: function(number) {
            $('.users .bet').each(function(index, value) {
                let multiplier = $(value).data('multiplier');
                if(parseFloat(number) >= parseFloat(multiplier)) {
                    $(value).children('.user').css('background', 'rgba(48, 77, 53, 0.8)')
                }
            });

            let multiplier = $('.bet-high .bet').data('multiplier');
            if(parseFloat(number) >= parseFloat(multiplier)) {
                $('.bet-high .bet .user').css('background', 'rgba(48, 77, 53, 0.8)')
            }
        },
        startCountDown: function(time) {
            clearInterval(this.countDownInterval);
            var self = this;
            this.timeLeft = time * 100;
            if (time === 0) return;

            this.countDownInterval = setInterval(function() {
                self.timeLeft -= 1;
                if (self.timeLeft === 0) {
                    clearInterval(self.countDownInterval);
                }
            }, 10);
        },
        _addBet: function(data) {
            let bets = '';
            data.sort(function(a, b) {
                return b.amount - a.amount;
            });
            data.forEach(function(bet) {
                bets += `<div class="bet" data-multiplier="`+ bet.multiplier +`">
                    <div class="user" style="background: rgba(60,64,65,255)">
                        <div class="info"> <div class="avatar" ><img src="../img/level-icons/`+ bet.user.avatar + `.png" width="26px" height="26px"/></div> <div class="name">` + bet.user.username + `</div> </div>  <div class="values"> <div class="multiplier">x `+ parseFloat(bet.multiplier).toFixed(2) +`</div> <div class="amount" style="display: flex; justify-content: center; align-items: center;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" class="nav-a__link-icon mr-2"><path d="M21.7 7v-.2c0-1.7-4.4-3.1-9.9-3.1S1.9 5.1 1.9 6.8v2.7c0 .6.6 1.1 1.7 1.7 0 0 2.6 1.6 8.3 1.6 2.4 0 4.7-.3 7-1.1 1.8-.6 2.9-1.5 2.9-2.2L21.7 7zM4.4 6.3c.7-1 3.8-1.7 7.4-1.7s6.8.8 7.5 1.7c.1.1.1.3.1.4v.4c-.1-.1-.3-.2-.4-.3-1.1-.8-3.9-1.2-7.2-1.2s-6 .4-7.1 1.2c-.2.1-.3.2-.5.4v-.5c0-.1.1-.3.2-.4zm15.5 6.5v2.6c0 .7-1.1 1.5-2.9 2.2-2.3.8-4.6 1.1-7 1.1-5.7-.2-8.3-1.7-8.3-1.7C.6 16.4 0 15.8 0 15.3v-2.5-.1-.2c0-.5.6-1.1 1.5-1.6v.1c0 .6.7 1.2 1.9 1.8 0 0 2.6 1.4 8.1 1.6 2.4.1 4.8-.3 7-1.1.5-.2.9-.4 1.4-.5-.1 0-.1.1-.1.2 0-.1 0-.2.1-.2z"></path></svg>  `+parseFloat(bet.amount).toFixed(2)+`</div> </div> 
                    </div>
                </div>`;
            });
            $('.all .users').html(bets);
            $('.bet-high').html(`<div class="bet" data-multiplier="`+ data[0].multiplier +`">
                <div class="user" style="background: rgba(60,64,65,255)">
                    <div class="info"> <div class="avatar" ><img src="../img/level-icons/`+ bet.user.avatar + `.png" width="26px" height="26px"/></div> <div class="name">` + data[0].user.username + `</div> </div>  <div class="values"> <div class="multiplier">x `+ parseFloat(data[0].multiplier).toFixed(2) +`</div> <div class="amount" style="display: flex; justify-content: center; align-items: center;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" class="nav-a__link-icon mr-2"><path d="M21.7 7v-.2c0-1.7-4.4-3.1-9.9-3.1S1.9 5.1 1.9 6.8v2.7c0 .6.6 1.1 1.7 1.7 0 0 2.6 1.6 8.3 1.6 2.4 0 4.7-.3 7-1.1 1.8-.6 2.9-1.5 2.9-2.2L21.7 7zM4.4 6.3c.7-1 3.8-1.7 7.4-1.7s6.8.8 7.5 1.7c.1.1.1.3.1.4v.4c-.1-.1-.3-.2-.4-.3-1.1-.8-3.9-1.2-7.2-1.2s-6 .4-7.1 1.2c-.2.1-.3.2-.5.4v-.5c0-.1.1-.3.2-.4zm15.5 6.5v2.6c0 .7-1.1 1.5-2.9 2.2-2.3.8-4.6 1.1-7 1.1-5.7-.2-8.3-1.7-8.3-1.7C.6 16.4 0 15.8 0 15.3v-2.5-.1-.2c0-.5.6-1.1 1.5-1.6v.1c0 .6.7 1.2 1.9 1.8 0 0 2.6 1.4 8.1 1.6 2.4.1 4.8-.3 7-1.1.5-.2.9-.4 1.4-.5-.1 0-.1.1-.1.2 0-.1 0-.2.1-.2z"></path></svg>  `+parseFloat(data[0].amount).toFixed(2)+`</div> </div> 
                </div>
            </div>`)

        },
        _displayBet: function(data, color) {
            if (typeof steamid !== 'undefined' && data.player.steamid === steamid) {
                var myBet = $('.your-bet.bet-on-' + color);
                myBet.data('value', (parseFloat(myBet.data('value')) + parseFloat(data.amount)).toFixed(2)).text(myBet.data('value'));
            }

            var totalBet = $('.total-bet-amount.' + color + '-total');
            totalBet.data('value', (parseFloat(totalBet.data('value')) + parseFloat(data.amount)).toFixed(2)).text(totalBet.data('value'));

            $(this._generateBetFromData(data)).hide().prependTo('.' + color + '-bet .player-bets').fadeIn(500);

            this.sortColor(color);
        },
        sortColor: function(color) {
            var $wrapper = $('.'+color+'-bet .player-bets');
            $wrapper.find('.player-bet').sort(function (a, b) {
                return +b.dataset.sort - +a.dataset.sort;
            })
                .appendTo( $wrapper );
        },
        updateTimer: function(data) {
            if(data.status == 1) {
                $('.progress .text').text('GIRANDO EM ' + parseFloat(data.timer).toFixed(2) + 's')
                $('.scroll').css('width', (data.timer*10 + '%'));
            } else if(data.status == 2) {
                $('.progress .text').text('GIRANDO....')
                $('.scroll').css('width', '100000px');
            } else if(data.status == 3) {
                $('.progress .text').text('ESPERANDO PRÓXIMA RODADA')
            }
        },
        updateAnimationNumbers: function(numbers) {
            let frames = '';
            numbers.forEach(function(number) {
                frames += `<div class="item"> 
                    <div class="number" style="display: flex; align-items: center; justify-content: center;">
                        x ` + number + `
                    </div> 
                </div>`;
            });

            $('.items .animation').empty();
            $('.items .animation').html(frames);

            $('.bet-high').html(`                
            <div class="bet">
                <div class="user" style="background: rgba(60,64,65,255)">
                    
                </div>
            </div>`)

            $('.all .users').html(`                
            <div class="bet">
                <div class="user" style="background: rgba(60,64,65,255)">
                    
                </div>
            </div>`)
        },
        _generateBetFromData: function(data) {
            return '<div class="player-bet" data-sort="'+data.amount+'"><div class="user"><div class="fa fa-user"></div>' + data.player.username + '</div><div class="amount">' + data.amount + '</div></div>'
        },
        _color: "red",
        _settings: {
            min: 1, max: 1000000
        },
        bindButtons: function() {
            var self = this;

            var value = $('.wager input:eq(0)');
            var crashpoint = $('.wager input:eq(1)');
            var multi = $('.btn-multi');

            multi.click(function(){
                multi.removeClass('active');
                $(this).addClass('active');
                self._color = $(this).data('value');
            });

            $('.inputs-area .button').click(function(){
                var val = parseFloat(value.val());
                var balance = parseFloat($($('.balance')[0]).data('balance'));
                if (isNaN(val)) val = 0;

                switch($(this).data('action')) {
                    case "clear": val = 0; break;
                    case "last": val = parseFloat(localStorage.getItem("lastBetRoulette")); break;
                    case "min": val = self._settings.min; break;
                    case "max": val = self._settings.max; break;
                    case "10+": val += 10; break;
                    case "50+": val += 50; break;
                    case "150+": val += 150; break;
                    case "200+": val += 200; break;
                    case "500+": val += 500; break;
                    case "10000-": val -= 10000; break;
                    case "1/2": val *= 0.5; break;
                    case "x2": val *= 2; break;
                    case "x3": val *= 3; break;
                }
                val = parseFloat(val);
                if (val > balance) val = balance;
                if (val < 0 || isNaN(val)) val = 0;
                localStorage.setItem("lastBetRoulette", val);
                value.val(val);
            });
            $('.doubleplusBet').click(function(){
                var val = parseFloat((parseFloat(value.val())).toFixed(2));
                if (!isNaN(val) && val > 0) {
                    socket.emit('doubleplus play', {value: val, multiplier: parseFloat((parseFloat(crashpoint.val())).toFixed(2))});
                } else {
                    value.val('0');
                }
            });
        }
    });
    roulette.bindButtons();


    socket.on('doubleplus finish', function (data) {
        roulette.newRound(data.number);
    });

    socket.on('doubleplus roll', function(res) {
        roulette.rotateAnimation(res);
    })

    socket.on('new doubleplus bet', function(data) {
        roulette._addBet(data)
    });

    socket.on('roulette ends', function(data) {
        roulette.rotateTo(data.winningNumber, data.shift);
    });

    socket.on('roulette round', function(time, bets, hash) {
        roulette.newRound(time, bets);
        $('.roulette-info').html('Round hash: ' + hash);
    });

    socket.on('doubleplus timer', function(data) {
        roulette.updateTimer(data);
    });

    socket.on('doubleplus numbers', function(res) {
        roulette.updateAnimationNumbers(res.results);
        roulette.updateHistory(res.history);
    })

    $(window).resize(roulette.positionFix.bind(roulette));
    $(document).ready(function(){roulette.positionFix();})
});