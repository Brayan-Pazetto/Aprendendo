var locale = {
    // Short, common use
    view: 'view',
    profile: 'profile',
    winChance: 'win chance',
    win: 'win',
    lose: 'lose',

    // Unknown server error
    serverError: 'Unexpected server error!',

    // Fair check
    hashCheckSuccess: 'Hashes match!',
    hashCheckFailed: 'Hashes doesn\'t match!',

    // Trade token
    tradeTokenFailed: 'Failed to update trade token!',
    tradeTokenSuccess: 'Updated trade token! New token: %s',

    // Common sentences, used everywhere
    notLoggedIn: 'Not logged in!',
    notEnoughCoins: 'Not enough coins!',
    cannotParseValue: 'Cannot parse value!',

    // Common inventory sentences
    escrowError: 'Non zero escrow duration, mobile authenticator needed!',
    pendingOffer: 'Pending offer! Accept or decline before requesting another!',
    offerStateChange: 'Your offer #%s changed state from "%s" to "%s"',
    noTradeToken: 'Request failed, no trade token supplied! Go to account section to set trade URL!',

    // User inventory
    loadInventoryError: 'Cannot load user inventory, please try again later!',
    loadInventorySuccess: 'User inventory loaded!',
    loadInventoryCached: 'User inventory loaded from cache!',

    // Site inventory
    loadSiteInventoryError: 'Cannot load site inventory, please try again later!',
    loadSiteInventorySuccess: 'Site inventory loaded!',

    // Deposit
    depositOfferSent: 'Deposit offer sent, offer #%s',
    depositFailed: 'Deposit offer failed for unknown reason, please try again later...',
    depositOfferAccepted: 'Deposit offer #%s accepted! Coins added: %i!',
    depositRequestSent: 'Deposit request has been sent, please wait for confirmation!',
    depositNoItemsRequested: 'No item requested to deposit!',
	depositBanned: 'You are banned from depositing!',
	
    // Withdraw
    withdrawOfferSent: 'Withdraw offer sent, offer #%s, please wait for the bots to confirm the offer!',
    withdrawFailed: 'Withdraw offer failed for unknown reason, please try again later...',
    withdrawOfferAccepted: 'Withdraw offer #%s accepted!',
    withdrawRequestSent: 'Withdraw request has been sent, please wait for confirmation!',
    withdrawMultipleBots: 'Requested withdrawal from multiple bots!',
    withdrawNoItemsRequested: 'No item requested to withdraw!',
    withdrawItemsUnavailable: 'Items unavailable! Try refreshing the page!',
    cannotWithdraw: 'Withdraw offer failed for unknown reason, please try again later...',
    withdrawItemsAlreadyInTrade: 'One or more of selected items already in trade, please refresh the page!',
    withdrawSendError2: 'Offer failed for unknown reason!',
    withdrawSendError20: 'Offer failed, Steam service unavailable!',
    withdrawSendError25: 'Offer failed, limit exceeded!',
    withdrawSendError26: 'Offer failed, revoked! Please try again later!',
    withdrawSendError15: 'Offer failed, access denied!',
    withdrawSendError16: 'Offer failed, timeout!',
    withdrawDeposit: 'You need to deposit for %i coins AND play %i%% of the deposited coins before withdrawing!',
    withdrawBets: 'You need to bet at lease %i times before withdrawing!',
    withdrawNotEnoughDeposit: 'You need to deposit at least 2500 coins to withdraw items of the value over 1000 coins!',
	withdrawNotEnoughPlayed: 'You need to play 50%% of what you deposited to withdraw!',
	withdrawNotEnoughWagered: 'You did not wager enough to withdraw!',
    withdrawBanned: 'You are banned from withdrawing!',
	
    // Chat
	chatRefillNotReady: 'Você precisa ter 0 moedas para obter um refil!',
	chatRefillFailed: 'Alguma coisa deu errado. Por favor tente outra vez!',
	chatRefillSuccess: 'Você tem %i moedas, divirta-se e boa sorte!',
    chatUnknownCommand: 'Comando de bate-papo desconhecido!',
    chatRootAccess: 'Você precisa de acesso root para executar este comando!',
    chatAdminAccess: 'Você precisa de acesso de administrador para executar este comando!',
    chatModAccess: 'Você precisa de acesso de moderador para executar este comando!',
    chatMissingParameters: 'Parâmetros ausentes',
    chatBanSuccess: 'Banido %s!',
    chatBanFail: 'Tempo\'t ban %s!',
    chatMuteSuccess: 'Mutado %s!',
    chatMuteFail: 'Couldn\'t mute %s!',
    chatMuteStaff: 'Não é possível silenciar a equipe!',
    chatUnmuteSuccess: 'Unmuted %s!',
    chatUnmuteFail: 'Couldn\'t unmute %s!',
    chatUnmuteStaff: 'Não é possível desmutar a equipe!',
    chatUnmuteNotMuted: '%s is not muted!',
    chatGiveSuccess: 'Given %i coins to %s!',
    chatGiveFail: 'Falha dar %i moedas para %s!',
    chatSendSuccess: 'Enviou %i moedas para %s!',
    chatSendFail: 'Falha ao enviar %i moedas para %s!',
    chatSendReceived: 'Recebeu %i moedas de %s!',
    chatSendOutOfRange: 'Valor fora do intervalo!',
    chatSendNotEnoughCoins: 'Não há moedas suficientes jogadas para enviar moedas! Você tem que jogar com %i moedas antes de enviá-las para outra pessoa!',
    chatSendNotEnoughDeposit: 'Valor do depósito muito baixo, você precisa depositar itens no valor de %i moedas para usar este comando!',
    chatSendUnavailable: 'Você não pode enviar moedas!',
    chatAccessLevelOutOfRange: 'Nível de acesso fora do alcance! (0 - 128)',
    chatAccessLevelSuccess: 'Nível de acesso %i concedido a %s!',
    registerSucess: 'Conta registrada com sucesso!',
    userAlreadyExist: 'Usuário existente, tente outro email ou usuário.',
    chatAccessLevelFailed: 'Falha ao conceder o nível de acesso %i a %s!',
    chatCoinsBalance: 'Rake total: %i moedas! Valor do inventário: %i moedas! Saldo total: %i moedas!',
    chatVoucherUsed: 'Código já usado',
    chatVoucherUnknown: 'Código desconhecido!',
    chatVoucherFailed: 'Falha ao resgatar o cupom!',
    chatVoucherSuccess: 'Cupom código, moedas foram adicionadas à sua conta!',
    chatVoucherCreationFailed: 'Falha ao criar cupom!',
    chatVoucherCreationSuccess: 'Cupom criado! Verifique o bate-papo para mais detalhes!',
    chatReferralUnknown: 'Código de referência desconhecido!',
    chatReferralAlreadyUsed: 'Você já usou um código!',
    chatReferralFailed: 'Falha ao ativar o código de referência!',
    chatReferralSuccess: 'Código de referência ativado "%s", %i moedas foram adicionadas ao seu saldo!',
    chatReferralNoCSGO: 'Você precisa do CS:GO para ativar o código de referência!',
    chatReferralOwnCode: 'Não é possível usar o próprio código!',
    chatIsMuted: 'O bate-papo está desativado agora!',
    chatMuted: 'O bate-papo foi silenciado!',
    chatUnmuted: 'O bate-papo foi ativado!',
    chatCooldown: 'Slow down! (%.2g sec)',
    chatNoBets: 'Você precisa jogar com %i moedas para conversar!',
    chatNotEnoughBets: 'Para poder conversar no chat, aposte pelo menos: R$(%i/%i)',
    loginDetailsInvalid: 'Dados de login inválidos, tente novamente.',
    chatNotEnoughDeposits: 'Não é suficiente depositado para conversar! (%i/%i)',

    // Misc
    coins: 'Coins',
    junk: 'Junk',
    rolling: 'Rolling...',
    voucherBot: 'Voucher Bot',
    generatedVoucher: 'Generated new voucher for %i coins: %s Use it by typing "/voucher %s" in the chat!',
    sendCoins: 'Enviar dinheiro',
    visitProfile: 'Visitar perfil',
    muteUser: 'Silenciar usuário',
    unmuteUser: 'Desmutar o som do usuário',
    createVoucher: 'Criar cupom',
    giveCoins: 'Dar dinheiro',
    changeAccess: 'Alterar nível de acesso',
    checkCoins: 'Verifique as moedas do site',
    redeemVoucher: 'Resgatar cupom',
    muteChat: 'Silenciar bate-papo',
    unmuteChat: 'Reativar bate-papo',
    removeMessages: 'Remove all user\'s messages',
    removeMessage: 'Remova a mensagem',

    // Affiliates
    affiliatesCollect: 'You\'re about to collect affiliates earnings (%i coins), please insert steamid you will to transfer the coins to',
    affiliatesSuccess: 'Collected the coins!',
    affiliatesNoIDSupplied: 'Failed to collect the coins! No target steamid supplied!',
    affiliatesNoUserFound: 'Failed to collect the coins! Target user not in the database!',
    affiliatesNoCoinsToCollect: 'Failed to collect the coins! No coins to collect!',
    updateRefFail: 'Failed to update referral code!',
    updateRefSuccess: 'New referral code generated!',
    updateRefAlreadyTaken: 'Failed to update referral code! Code already taken!',
    updateRefRefused: 'New referral code refused, must be longer than 4 characters!',
    affiliatesNoReferral: 'You have to create referral code in order to collect coins!',

    // Crash
    crashPlayFailed: 'Falha ao colocar moedas!',
    crashPlaySuccess: 'Apostou R$ %i',
    crashMaxBet: 'Não é possível apostar R$ %i, a aposta máxima é %i!',
    crashMinBet: 'Não é possível apostar R$ %i, a aposta mínima é %i!',

    // Roulette
    roulettePlayFailed: 'Falha ao colocar moedas!',
    roulettePlaySuccess: 'Apostou R$ %i em %s! (%i/%i)',
    rouletteUnknownColor: 'Cor de roleta desconhecida!',
    rouletteMaxBets: 'Não é possível fazer mais de %i apostas!',
    rouletteMaxBet: 'Não é possível apostar R$ %i, a aposta máxima é %i!',
    rouletteMinBet: 'Não é possível apostar R$ %i, a aposta mínima é %i!',
    
    // Coinflip 
    coinflipPlayFailed: 'Failed to place coins!',
    coinflipPlaySuccess: 'Placed %i coins on %s!',
    coinflipUnknownColor: 'Unknown coinflip side!',
    coinflipMaxBet: 'Cannot place %i, maximum bet is %i!',
    coinflipMinBet: 'Cannot place %i, minimum bet is %i!',
    coinflipJoin: 'Joined to the game!',
    coinflipWon: 'You won %i coins on coinflip!',
    coinflipLost: 'You lost %i coins on coinflip!',
    coinflipAlreadyJoined: 'Players are in! Can\'t join!',
    coinflipPending: 'You already have game in proccess!',
    coinflipOwner: 'You are the creator of this lobby. You can\'t join here!',
    coinflipJoined: 'Player joined to your coinflip lobby!',

    // Jackpot
    jackpotPlayFailed: 'Failed to place coins!',
    jackpotPlaySuccess: 'Placed %i coins on jackpot!',
    jackpotTime: 'Betting is not allowed now!',
    jackpotMaxBet: 'Cannot place %i, maximum bet is %i!',
    jackpotMinBet: 'Cannot place %i, minimum bet is %i!',
    jackpotPending: 'You are already in game!',
    jackpotWon: 'You won %i coins on jackpot!',
    jackpotLost: 'You lost %i coins on jackpot!',

    // Mines
    valueOutOfRange: 'Bet out of the range! (Min: %i, Max: %i)',
    
	// Earn.GG
	earnGGFailed: 'Error transferring the coins!',
	earnGGAmountNotValid: 'Invalid amount!',
    earnGGUserNotInDB: 'User is not in the DB!',
    
    //Errors
    withdrawBalanceError: "Você não tem saldo o suficiente para sacar.",
    withdrawErrorDaily: "Limite de 1 saque por dia, volte amanhã.",
    
    //Withdraw
    withdrawSuccess: "Retirada solicitada com sucesso, espere de 1-3 dias para a aprovação.",

	// Giveaway
	giveawayNotEnoughCoins: 'You do not have enough coins to buy %i tickets!',
	giveawayJoined: 'You have successfuly joined the giveaway with %i tickets!',
	giveawayNotInName: 'You need to add csgon1.com to your Steam name to join the giveaway!',
	giveawayTooManyTickets: 'You can only buy up to 1000 tickets/shot!',
    
    //Free coins
    freeSuccess: 'Collected %i coins!',
    freeError: 'Error while getting free coins!',
    freeUsed: 'Already used! Next use in %ih %im %is!',
    freeNoCS: 'CS:GO is required to use that function!',
    freeBadNickname: 'You need to put "%s" in your nickname!',
    freeCooldown: 'Please wait a moment before the next check: %i minutes, %i seconds',
    freeNotInGroup: 'You need to join the group before redeeming the coins!'
};