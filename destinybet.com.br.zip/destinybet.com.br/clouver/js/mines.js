var selectElement = document.querySelector('select');
selectElement.addEventListener('change', function() {
  console.log('Opção selecionada: ' + this.value);
});


