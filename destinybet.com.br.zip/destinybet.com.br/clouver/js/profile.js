$(function() {
    $('.betting-table').DataTable({
        ajax: {
            url: '/api/betting-history',
            dataSrc: ''
        },
        columns: [
            {
                data: 'id',
                width: "15%"
            },
            {
                data: 'reason',
                width: "40%"
            },
            {
                data: 'change',
                width: "15%",
				"render": function (data, type, row) {
                    if (type === 'display') {
                        return parseFloat(data).toFixed(2);
                    }
                    return data;
                }
            },
            {
                data: 'transaction_date',
                width: "30%"
            }
        ],
        order: [[0, 'desc']],
        pagingType: 'simple'
    });

    $('.transaction-table').DataTable({
        ajax: {
            url: '/api/transaction-history',
            dataSrc: ''
        },
        columns: [
            {
                data: 'id',
                width: "15%"
            },
            {
                data: 'type',
                width: "15%"
            },
            {
                data: 'status',
                width: "15%"
            },
            {
                data: 'worth',
                width: "15%"
            },
            {
                data: 'date',
                width: "40%"
            }
        ],
        order: [[4, 'asc']],
        pagingType: 'simple'
    });

    $('.section').click(function() {
        if(!$(this).hasClass('active')) {
            $('.section').removeClass('active');
            $(this).addClass('active')
        
            if($(this).hasClass('section-bets')) {
                $('.profile-content').addClass('hidden');
                $('.profile-content:eq(1)').removeClass('hidden')
            } else if($(this).hasClass('section-profile')) {
                $('.profile-content').addClass('hidden');
                $('.profile-content:eq(0)').removeClass('hidden')
            } else if($(this).hasClass('section-transactions')) {
                $('.profile-content').addClass('hidden');
                $('.profile-content:eq(2)').removeClass('hidden')
            }
        }
    });
});