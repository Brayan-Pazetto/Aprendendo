$(function() {
    var tower = {
        _round: {
            id: null,
            $logs: null,
            $div: $('.tower-game')
        },
        _risk: 1,
        _lastTileClick: null,
        _mineImg: "/img/misc/bomb.png",
        $games: $('.tower'),
        getTiles: function () {
            var tiles = '';
            for (var i = 1; i <= 25; i++) {
                tiles += '<div data-position="'+i+'" id="tile_'+i+'" class="tile"></div>';
            }
            return tiles;
        },
        setbutton: function (txt, classe, click) {
            this._round.$div
                .find('#towerPlay')
                .unbind('click')
                .click(click)
                .attr('class', 'button '+classe)
                .text(txt);
        },
        start: function(data) {
            if(this._round.id != null) this.end();

            this._round.id = data.id;
            console.log(data)

            this._round.$next = $('.multiplier[data-multiplier="' + (data.row+1) + '"]');
            this.setbutton('Retirar (' + parseFloat(data.value).toFixed(2) + ')', 'btn-orange', function() {
                this.setbutton('Novo Jogo', 'btn-green', function() {
                    var value = $('.input-menu .tower-money');
                    $('.room').each(function(tile) {
                        let game = $(this);
                        game.removeClass('win');
                        game.removeAttr("style");
                        game.removeClass('lose');
                    });
                    $('.multiplier').each(function(tile) {
                        let game = $(this);
                        game.removeAttr("style");
                        game.removeClass('win');
                        game.removeClass('lose');
                    });
                    socket.emit('tower start', {
                        risk: this._risk,
                        amount: value.val()
                    });
                }.bind(this));
                socket.emit('tower cashout');
            }.bind(this));
        },
        game: function(data, status){
            this._round.id = data.id;
            if(data.status == 1) {
                if(data.row != 0) {
                    this.setbutton('Retirar ('+parseFloat(data.value * parseFloat($('.multiplier[data-multiplier="' + (data.row) + '"]').children('.odds').text().replace('x', ''))).toFixed(2)+')', 'btn-orange', function() {
                        this.setbutton('Novo Jogo', 'btn-green', function() {
                            var value = $('.input-menu .tower-money');
                            $('.room').each(function(tile) {
                                let game = $(this);
                                game.removeClass('win');
                                game.removeAttr("style");
                                game.removeClass('lose');
                            });
                            $('.multiplier').each(function(tile) {
                                let game = $(this);
                                game.removeAttr("style");
                                game.removeClass('win');
                                game.removeClass('lose');
                            });
                            socket.emit('tower start', {
                                risk: this._risk,
                                amount: value.val()
                            });
                        }.bind(this));
                        socket.emit('tower cashout');
                    }.bind(this));
                } else {
                    this.setbutton('Retirar (' + parseFloat(data.value).toFixed(2) + ')', 'btn-orange', function() {
                        this.setbutton('Novo Jogo', 'btn-green', function() {
                            var value = $('.input-menu .tower-money');
                            $('.room').each(function(tile) {
                                let game = $(this);
                                game.removeClass('win');
                                game.removeAttr("style");
                                game.removeClass('lose');
                            });
                            $('.multiplier').each(function(tile) {
                                let game = $(this);
                                game.removeAttr("style");
                                game.removeClass('win');
                                game.removeClass('lose');
                            });
                            socket.emit('tower start', {
                                risk: this._risk,
                                amount: value.val()
                            });
                        }.bind(this));
                        
                        socket.emit('tower cashout');
                    }.bind(this));
                }
            } else {
                this.setbutton('Apostar', 'btn-green', null);
            }


            if(this._lastTileClick != null) { 
                $('.room[data-id=' + this._lastTileClick + ']').css('background-color', 'rgb(95, 106, 134) !important')
            }

            for(let i = 1; i < data.row; i++) {
                $('.multiplier[data-multiplier='+ i +']').addClass('win');
            }

            $('.multiplier[data-multiplier='+ data.row +']').addClass(status);

            if(status == 'lose') {
                
                this.setbutton('Novo Jogo', 'btn-red', function() {
                    var value = $('.input-menu .tower-money');
                    $('.room').each(function(tile) {
                        let game = $(this);
                        game.removeClass('win');
                        game.removeAttr("style");
                        game.removeClass('lose');
                    });
                    $('.multiplier').each(function(tile) {
                        let game = $(this);
                        game.removeAttr("style");
                        game.removeClass('win');
                        game.removeClass('lose');
                    });
                    socket.emit('tower start', {
                        risk: this._risk,
                        amount: value.val()
                    });
                }.bind(this));
            } else {
                $('.room[data-id=' + this._lastTileClick + ']').html('<img src="/img/tower-click.gif" style="position: absolute;width: 70px; top:-10; left:5">');
                setTimeout(() => {
                    $('.room[data-id=' + this._lastTileClick + ']').html('');
                    $('.room').html('');
                }, 1200);
            }

            let rowAmount = 0;
            console.log(data.bombs)
            $('.room').each(function(tile) {
                let game = $(this);
                rowAmount++;
                if(rowAmount > (data.row*5)) return;
                let tileId = $(this).data('id');
                game.addClass('win');

                data.bombs.forEach(function(id) {

                    if(tileId == id) {
                        
                        console.log(game)
                        console.log('tem')
                        game.removeClass('win');
                        game.addClass('lose');
                    }
                });
            });

            /*var tile = data.position;
            var $tile = this._round.$div.find('.tile#tile_' + data.position);
            
            if (data.value == -1) {
                this.log('You found <b>bomb</b> on '+tile+' tile - you lost '+this._round.$total.text()+'!', 'red');
                this._round.$total.text(0).addClass('red');
                this._round.$next.addClass('red');
                $tile.html('<img src="'+this._mineImg+'">').addClass('red');
                this.setbutton('Defeat! :(', 'btn-red', null);
                if (localStorage.getItem('muteSound') != 'on') new buzz.sound("/sounds/boom.mp3").play();
            } else {
                this._round.$total.text(data.payout);
                this._round.$next.text(data.nextPayout);
                this.log('You found <b>'+data.value+' coins</b> on '+tile+' tile.', 'green');
                $tile
                    .text('+' + (data.value > 10000 ? Math.floor(data.value / 1000) + 'k' : data.value))
                    .addClass('green');
                $tile.unbind('click');
                if (localStorage.getItem('muteSound') != 'on') new buzz.sound("/sounds/click.mp3").play();
            }*/

        },
        getMultipliersByRisk: function(risk, id) {
            console.log(risk, id)
            if(risk == 1) {
                if(id == 1) return 1.18;
                if(id == 2) return 1.48;
                if(id == 3) return 1.85;
                if(id == 4) return 2.31;
                if(id == 5) return 2.89;
                if(id == 6) return 3.62;
                if(id == 7) return 4.52;
                if(id == 8) return 5.66;
                if(id == 9) return 7.07;
                if(id == 10) return 8.84;
            } else if(risk == 2) {
                if(id == 1) return 1.58;
                if(id == 2) return 2.63;
                if(id == 3) return 4.39;
                if(id == 4) return 7.33;
                if(id == 5) return 12.21;
                if(id == 6) return 20.36;
                if(id == 7) return 33.93;
                if(id == 8) return 56.56;
                if(id == 9) return 94.26;
                if(id == 10) return 157.11;
            } else if(risk == 3) {
                if(id == 1) return 2.37;
                if(id == 2) return 5.93;
                if(id == 3) return 14.84;
                if(id == 4) return 37.1;
                if(id == 5) return 92.77;
                if(id == 6) return 231.93;
                if(id == 7) return 579.83;
                if(id == 8) return 1449.58;
                if(id == 9) return 3623.96;
                if(id == 10) return 9059.9;
            } else if(risk == 4) {
                if(id == 1) return 4.75;
                if(id == 2) return 23.75;
                if(id == 3) return 118.75;
                if(id == 4) return 593.75;
                if(id == 5) return 2398.75;
                if(id == 6) return 14843.75;
                if(id == 7) return 74218.75;
                if(id == 8) return 371093.75;
                if(id == 9) return 1855468.75;
                if(id == 10) return 9277343.75;
            }

            return 1.00;
        },
        bindButtons: function () {
            var self = this;

            var value = $('.input-menu .tower-money');

            $('.multiplier').each(function(tile) {
                $(this).children('.odds').html('x'+ parseFloat( parseFloat((self.getMultipliersByRisk(self._risk, parseInt($(this).data('multiplier')))) ).toFixed(2) ) );
            });

            
            $('#towerPlay').click(function(){
                console.log('lets go')
                socket.emit('tower start', {
                    risk: self._risk,
                    amount: value.val()
                });
            });

            $('.actual-risk').click(function() {
                let openBar = $('.open-bar');
                if(openBar.hasClass('hidden')) {
                    openBar.removeClass('hidden');
                    $('.actual-risk i').attr('class', 'fa fa-chevron-up');
                } else {
                    openBar.addClass('hidden');
                    $('.actual-risk i').attr('class', 'fa fa-chevron-down');
                }
            });

            $('.change-risk').click(function() {
                let risk = parseInt($(this).data('risk'));
                if(risk > 0 && risk <= 4) {
                    self._risk = risk;
                    $('.multiplier').each(function(tile) {
                        $(this).children('.odds').html('x'+ parseFloat(parseFloat(( self.getMultipliersByRisk(self._risk, parseInt($(this).data('multiplier'))) )).toFixed(2)) );
                    });
                    let openBar = $('.open-bar');
                    openBar.addClass('hidden');
                    $('.actual-risk i').attr('class', 'fa fa-chevron-down');
                    $('.actual-risk div').html($(this).text())
                }
            });

            $('.room').click(function(){
                let id = $(this).data('id');
                console.log(id)
                socket.emit('tower click', {
                    tile: id
                });

                self._lastTileClick = id;
                
            });

            $('.input-menu .input-item').click(function(){
                var val = parseFloat(value.val());
                var balance = parseFloat($($('.balance')[0]).data('balance'));
                if (isNaN(val)) val = 0;

                switch($(this).data('action')) {
                    case "clear": val = 0; break;
                    case "10%": val *= 1.1; break;
                    case "x1.10": val *= 1.2; break;
                    case "30%": val *= 1.3; break;
                    case "1/2": val *= 0.5; break;
                    case "x2": val *= 2; break;
                }
                val = parseFloat(parseFloat(val).toFixed(2));
                if (val > balance) val = balance;
                if (val < 0 || isNaN(val)) val = 0;
                value.val(val);
            });
        },
        _settings: {
            min: 50,
            max: 100000,
            update: function (data) {
                this.min = data.minBet;
                this.max = data.maxBet;
            }
        },
        end: function(data){
            if( this._round.$div.find('.button').text()=="Cashout" || (typeof data.cashout !='undefined' && data.cashout == true))
                this.setbutton("Cashed out", "btn-green", null);
            $('.tile').unbind('click');
            this._round.$div.addClass('inactive');
            this.log('The game was ended.');
            if (typeof data != 'undefined') {
                this._round.$total.text(data.payout);
                this._round.$div.find('.secret').html('Secret:<input class="value" value="' + data.secret + '" />');
                for (var i in data.bombsPositions)
                    $('#game' + data.id + ' #tile_' + data.bombsPositions[i]).html('<img src="'+this._mineImg+'">');
            }
            this._round.id = null;
        },
        init: function () {
            this.bindButtons();
            socket.on('tower start', function(data){
                this._round.id = null;
                this.start(data);
            }.bind(this));
            socket.on('tower game', function(data){
                if(data.status == 1) {
                    this.game(data, 'win');
                } else {
                    this.game(data, 'lose');
                }
            }.bind(this));
            socket.on('tower play win', function(data){
                this.game(data, 'win');
            }.bind(this));
            socket.on('tower play lose', function(data){
                this.game(data, 'lose');
            }.bind(this));
        }
    };
    tower.init();
});