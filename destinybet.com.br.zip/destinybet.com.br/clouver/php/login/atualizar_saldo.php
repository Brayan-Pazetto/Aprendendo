<?php
session_start();
include('../../conexao.php');

// Inicializa um array para armazenar o balance e o bonus
$response = [
    'balance' => 0,
    'bonus' => 0,
    'total' => 0
];

if(isset($_SESSION['id'])) {
    $userId = $_SESSION['id']; // Pode ser necessário filtrar essa variável para evitar SQL Injection
    $query = "SELECT balance, bonus FROM users WHERE id = '$userId'";
    $result = mysqli_query($conn, $query);

    if($row = mysqli_fetch_assoc($result)){
        // Atualiza os valores na sessão e no array de resposta
        $_SESSION['balance'] = $row['balance'];
        $_SESSION['bonus'] = $row['bonus'];
        
        // Calcula o total
        $total = $row['balance'] + $row['bonus'];
        
        // Atualiza o array de resposta
        $response = [
            'balance' => $row['balance'].',00',
            'bonus' => $row['bonus'].',00',
            'total' => $total.',00'
        ];
    }
}

// Define o cabeçalho para retornar como JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
