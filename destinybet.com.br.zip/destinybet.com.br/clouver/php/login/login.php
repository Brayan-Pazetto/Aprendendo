<?php
session_start();
include('../../conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginEmail = $_POST['loginEmail'];
    $loginPassword = $_POST['loginPassword'];

    $sql = "SELECT * FROM users WHERE email='$loginEmail'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($loginPassword, $row['password'])) {
            $_SESSION['email'] = $loginEmail;

            // Obtenha o balance do usuário
            $usuario_id = $row['id'];
            $query = "SELECT balance FROM users WHERE id = $usuario_id";
            $balance_result = $conn->query($query);

            if ($balance_result->num_rows == 1) {
                $balance_row = $balance_result->fetch_assoc();
                $balance = $balance_row['balance'];
                $_SESSION['id'] = $usuario_id;
                $_SESSION['balance'] = $balance; // Adicione o balance à sessão
            }

            header("Location: ../../index.php");
        } else {
            header("Location: ../../index.php");
       
        }
    } else {
        header("Location: ../../index.php");

    }

    $conn->close();
} else {
    // Não foi uma requisição POST
  
}
?>
