<?php
session_start();
include('../../conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $balance = $_POST['balance']; // Adicionado campo 'balance'

    if ($password !== $confirmPassword) {
        // Senhas não coincidem
        echo "As senhas não coincidem. Por favor, tente novamente.";
        exit();
    }

    // Encripte a senha antes de armazenar no banco de dados
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (email, password, balance) VALUES ('$email', '$hashedPassword', '$balance')"; // Adicionado campo 'balance'

    if ($conn->query($sql) === TRUE) {
        $_SESSION['email'] = $email;
        $_SESSION['id'] = $conn->insert_id; // Obtenha o ID do novo usuário
        $_SESSION['balance'] = $balance; // Adicionado campo 'balance'
        header("Location: ../../index.php");
    } else {
        // Ocorreu um erro na inserção
       
    }

    $conn->close();
} else {
    // Não foi uma requisição POST
  
}
?>
