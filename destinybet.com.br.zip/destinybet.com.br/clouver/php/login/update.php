<?php
session_start();

if(isset($_SESSION['id']) && isset($_SESSION['balance']) && isset($_POST['betAmount'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'cassino365me pas');

    if (!$conn) {
        die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
    }

    $betAmount = $_POST['betAmount'];
    $userID = $_SESSION['id'];

    $newBalance = $_SESSION['balance'] - $betAmount;
    $sql = "UPDATE users SET balance = $newBalance WHERE id = $userID";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['balance'] = $newBalance;
        $response = array('success' => true);
        echo json_encode($response);
    } else {
        $response = array('success' => false);
        echo json_encode($response);
    }

    mysqli_close($conn);
}
?>
